


var blueeye = [
	{
		id: 0, name: '실사제단', series: [
			{ name: '담당자', start: new Date(2019, 00, 01), end: new Date(2019, 00, 03) }
		]
	},
	{
		id: 1, name: '하도매작업', series: [
			{ name: '담당자', start: new Date(2019, 00, 01), end: new Date(2019, 00, 03) }
		]
	},
	{
		id: 13, name: 'CNC 단차가공작업', series: [
			{ name: '담당자', start: new Date(2019, 00, 01), end: new Date(2019, 00, 03) }
		]
	}
	,
];