ClassicEditor
    .create(document.querySelector('#editor'), {



        extraPlugins: [MyCustomUploadAdapterPlugin],
        toolbar: {
            items: [

                'fontfamily', 'fontsize', 'fontColor', 'fontBackgroundColor', '|',

                'bold', 'italic', 'strikethrough', 'underline', '|',
                'alignment',  'link', '|',
                'bulletedList', 'numberedList', 'todoList', '|',
                'insertTable', 'imageUpload',  'mediaEmbed', '|',  'undo', 'redo', '|', 'codeBlock', 'sourceEditing',
            ],
            shouldNotGroupWhenFull: true
        },
        fontFamily: {
            options: [
                'default',
                'Ubuntu, Arial, Helvetica,sans-serif', 'Lucida Sans Unicode, Lucida Grande, sans-serif', 'Times New Roman, Times, serif', 'Trebuchet MS, Helvetica, sans-serif',

                'Ubuntu Mono, Courier New, Courier, monospace', '맑은고딕', '돋움', '궁서', '고딕', '굴림', '바탕', '견고딕', '나눔고딕', '나눔명조', "Trebuchet MS", "Segoe UI Symbol", "Arial"
            ],
            supportAllValues: true
        },
        image: {
            toolbar: ['toggleImageCaption', 'imageTextAlternative', 'imageStyle:alignLeft', 'imageStyle:alignCenter', 'imageStyle:side', 'imageStyle:inline',  'linkImage']
        },

        styles: ['full', 'alignLeft', 'alignRight', 'side'],
        fontSize: {
            options: [
                9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36
            ]

        },
        link: {
            decorators: {
                openInNewTab: {
                    mode: 'manual',
                    label: 'Open in a new tab',
                    defaultValue: true,         // This option will be selected by default.
                    attributes: {
                        target: '_blank',
                        rel: 'noopener noreferrer'
                    }
                }
            }
        },

        table: {
            contentToolbar: [
                'tableColumn',
                'tableRow',
                'mergeTableCells',
                'tableCellProperties',
                'tableProperties'
            ]
        },
      
        //title: {
        //    placeholder: 'My custom placeholder for the title'
        //},
        //placeholder: '',


        codeBlock: {
            languages: [
                { language: 'plaintext', label: 'Plain text' }, // The default language.
                { language: 'css', label: 'CSS' },
                { language: 'html', label: 'HTML' },
                { language: 'javascript', label: 'JavaScript' },
                { language: 'cs', label: 'C#' },

            ]
        },

        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
            ]
        }
    })

    .catch(error => {
        console.log(error);
    });


class UploadAdapter {
    constructor(loader) {

        // 파일로더가 업로드 어댑터를 사용해서 이미지를 서버에 전송하기 때문에

        this.loader = loader;
    }

    // 업로드를 시작한다.
    upload() { return this.loader.file.then(file => new Promise((resolve, reject) => { this._initRequest(); this._initListeners(resolve, reject, file); this._sendRequest(file); })); }



    // 업로드 프로세스 취소
    abort() {

        // upload() 메소드로부터 리턴된 프로미스를 reject해라.
        if (this.xhr) { this.xhr.abort(); }


    }


    _initRequest() {
        const xhr = this.xhr = new XMLHttpRequest();
        //여기서는 POST 요청과 json으로 응답을 받지만 어떤 포맷으로 하든 너의 선택이다.

        xhr.open('post', '/sys/ckeditor_one_fileUp', true);
        xhr.responseType = 'json';
    }
    //XHR 리스너 초기화 하기
    _initListeners(resolve, reject, file) {
        const xhr = this.xhr;
        const loader = this.loader;
        const genericErrorText = '파일을 업로드 할 수 없습니다. ${ file.name }'

        xhr.addEventListener('error', () => { reject(genericErrorText) })
        xhr.addEventListener('abort', () => reject())
        xhr.addEventListener('load', () => {
            const response = xhr.response;

            // 이 예제에서는 XHR서버에서의 response 객체가 error와 함께 올 수 있다고 가정한다. 이 에러는 // 메세지를 가지며 이 메세지는 업로드 프로미스의 매개변수로 넘어갈 수 있다.



            if (!response || response.error) {
                return reject(response && response.error ? response.error.message : genericErrorText);
            }

            // 만약 업로드가 성공했다면, 업로드 프로미스를 적어도 default URL을 담은 객체와 함께 resolve하라. // 이 URL은 서버에 업로드된 이미지를 가리키며, 컨텐츠에 이미지를 표시하기 위해 사용된다.


            resolve({
                default: response.url  //업로드된 파일 주소


            });

        });
        // 파일로더는 uploadTotal과 upload properties라는 속성 두개를 갖는다. // 이 두개의 속성으로 에디터에서 업로드 진행상황을 표시 할 수 있다.
        if (xhr.upload) { xhr.upload.addEventListener('progress', evt => { if (evt.lengthComputable) { loader.uploadTotal = evt.total; loader.uploaded = evt.loaded; } }); }
    }



    //데이터를 준비하고 서버에 전송한다.

    _sendRequest(file) {
        // 폼 데이터 준비
        const data = new FormData();
        data.append('upload', file);
        // 여기가 인증이나 CSRF 방어와 같은 방어 로직을 작성하기 좋은 곳이다. // 예를들어, XHR.setREquestHeader()를 사용해 요청 헤더에 CSRF 토큰을 넣을 수 있다.

        this.xhr.send(data)
    }
}

function MyCustomUploadAdapterPlugin(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
        return new UploadAdapter(loader)
    }
}
