﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SmartFactory.Models;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Headers;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using LazZiya.ImageResize;
using System.IO;
using SmartFactory.Util;
using ReflectionIT.Mvc.Paging;
using Microsoft.AspNetCore.Routing;
using System.Net;
using NPOI.OpenXmlFormats.Dml;
using static SmartFactory.Controllers.SysController;
using System.Web;

namespace SmartFactory.Controllers
{
    public class paymentController : Controller
    {
        // GET: Sys
        private readonly db_e db = new db_e();

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public paymentController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        /// <summary>
        /// / 로그인 정보
        // / </summary>


        //결제내역관리 - 수강권
    
        public async Task<ActionResult> payList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.payment_payapp.Where(a => (a.payGubun == 1 || a.payGubun == 2 || a.payGubun == 3) && a.pay_type != 0 && a.var1 != "4").OrderByDescending(a => a.pay_date).AsNoTracking();
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a).FirstOrDefault();
            ViewBag.userTel = userIdx.userTel;
            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.writer.Contains(search_all) || p.card_name.Contains(search_all)).OrderByDescending(p => p.pay_date);
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");
            return View(model);
        }


        // 결제 취소 
        public ActionResult payapp_request(string cmd, string goodname, int? goodprice, int? price, string recvphone, string rebillCycleType, string rebillCycleMonth, string rebillExpire, int? mul_no, string rebill_no, string var1, string var2)
        {

            #region 기본 변수
            string user_id = User.Identity.Name;
            price = price ?? 0;
            goodprice = goodprice ?? 0;
            string pay_url3 = "";
            string url = "https://api.payapp.kr/oapi/apiLoad.html";
            string responseText = string.Empty;
            StringBuilder dataParams = new StringBuilder();
            #region 종료일 변경
            DateTime endDate = DateTime.Now;
            if (var1 == "2")
            {
                endDate = endDate.AddMonths(1);
            }
            else
            {
                endDate = endDate.AddMonths(36);
            }
            #endregion
            #endregion

            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                #region 기본 정보 저장
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    linkkey = "gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=",
                    linkval = "gOss/MdwFI1k/Qtrly5ZpxxeRLbvrLi1v5VQbFpTZYk=",
                    recvphone = recvphone,
                    var1 = var1,
                    var2 = var2,
                    payGubun = Convert.ToInt32(var1),
                    startDate = DateTime.Now,
                    endDate = endDate,
                    goodname = goodname,
                    price = Convert.ToInt32(price),
                    goodprice = Convert.ToInt32(goodprice)

                };
                db.payment_payapp.Add(_insert);
                db.SaveChanges();
                #endregion
                goodname = System.Web.HttpUtility.UrlEncode(goodname);
                dataParams.Append("cmd=" + cmd + "&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("goodname=" + goodname + "&");
                dataParams.Append("recvphone=" + recvphone + "&");
                dataParams.Append("var1=" + var1 + "&");
                dataParams.Append("var2=" + var2 + "&");
                dataParams.Append("smsuse=n&");
                dataParams.Append("checkretry=y&");
                dataParams.Append("redirectpay=1&");
                dataParams.Append("openpaytype=phone,card,kakaopay,naverpay,zeropay&");
                dataParams.Append("price=" + price + "&");
                dataParams.Append("goodprice=" + goodprice + "&");
                dataParams.Append("rebillCycleType=" + rebillCycleType + "&");
                dataParams.Append("rebillCycleMonth=" + rebillCycleMonth + "&");
                dataParams.Append("rebillExpire=" + rebillExpire + "&");
                dataParams.Append("feedbackurl=https://contactsci.theblueeye.com/mypage/payapp_feedbackurl&");
                dataParams.Append("returnurl=https://contactsci.theblueeye.com/mypage/payapp_success");


            }
            else if (cmd == "rebillCancel" || cmd == "paycancel") //결제취소시
            {
                dataParams.Append("cmd=paycancel&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                dataParams.Append("mul_no=" + mul_no + "&");
            }

            #region 데이터 전송
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";    // 기본값 "GET"
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.ContentLength = dataParams.Length;
            Stream stDataParams = webRequest.GetRequestStream();
            stDataParams.Write(byteDataParams, 0, dataParams.Length); //전송
            #endregion

            #region 데이터 응답
            using (HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse())
            {
                HttpStatusCode status = resp.StatusCode;
                Console.WriteLine(status); // status 가 정상일경우 OK가 입력된다. 

                // 응답과 관련된 stream을 가져온다.
                Stream respStream = resp.GetResponseStream();
                using (StreamReader streamReader = new StreamReader(respStream))
                {
                    responseText = streamReader.ReadToEnd(); //데이터 결과값  
                }
            }

            #endregion

            #region 데이터 후처리
            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                string[] divided = responseText.Split('&');
                var pay_url = divided[4].Split('=');
                pay_url3 = HttpUtility.UrlDecode(pay_url[1]);
                var rebill_param = divided[3].Split('=')[1];
                var result_no = 0;
                //mul_no, rebill_no 구분 저장
                switch (var1)
                {
                    case "2":
                        result_no = 0;
                        break;

                    case "3":
                        result_no = Convert.ToInt32(rebill_param);
                        rebill_no = null;
                        break;
                }

                payment_payapp _update = (from a in db.payment_payapp where a.var2 == var2 select a).OrderByDescending(a => a.writeDate).FirstOrDefault();
                _update.payurl = pay_url3;
                _update.rebill_no = rebill_param;
                _update.mul_no = result_no;

                db.SaveChanges();
                stDataParams.Close();
            }
            else //결제 취소시
            {
                if (cmd == "rebillCancel") //정기결제 해지 후에 결제 취소 진행
                {
                    stDataParams.Close();
                    dataParams = new StringBuilder(); //파라미터 초기화
                    dataParams.Append("cmd=rebillCancel&");
                    dataParams.Append("userid=hellodd5005&");
                    dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                    dataParams.Append("mul_no=" + mul_no + "&");
                    dataParams.Append("rebill_no=" + rebill_no + "&");
                    byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
                    webRequest = (HttpWebRequest)WebRequest.Create(url);
                    webRequest.Method = "POST";    // 기본값 "GET"
                    webRequest.ContentType = "application/x-www-form-urlencoded";
                    webRequest.ContentLength = dataParams.Length;
                    stDataParams = webRequest.GetRequestStream();
                    stDataParams.Write(byteDataParams, 0, dataParams.Length);
                    stDataParams.Close();                
                }
                else
                {
                    stDataParams.Close();
                }

                var sb = new StringBuilder();
                sb.AppendFormat("<script type='text/javascript'>");
                sb.AppendFormat("location.href='/payment/payList?alert=C'");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
                return null;
               
            }
            #endregion

            return Redirect(pay_url3);
        }



        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
        private async Task fileUpload(List<IFormFile> files, string user_id, string file_id)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }
        }
        public void History_write(string user_id, string _page, string _state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }


    }
}