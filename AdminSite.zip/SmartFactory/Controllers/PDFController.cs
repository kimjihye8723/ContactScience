﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DinkToPdf;
using DinkToPdf.Contracts;
using System.IO;

namespace SmartFactory.Controllers
{

  
    public class pdfController : Controller
    {
        private IConverter _converter;

        public pdfController(IConverter converter)
        {
            _converter = converter;
        }

        // GET api/values
        [HttpGet]
        public IActionResult Get(string _type,string h,int i )
        {
            string get_url = Request.Host.ToString();


            h = "http://"+ get_url + h+"&i="+i;

             if (_type == "F")
             {
                // 파일로 저장시

                string file_name = DateTime.Now.ToString("yyyyMMddHHmmss");

               

                var doc = new HtmlToPdfDocument()
                {
                    GlobalSettings = {
                     ColorMode = ColorMode.Color,
                     PaperSize = PaperKind.A4,
                     Orientation = Orientation.Landscape,
                     //Orientation = Orientation.Portrait,
                     //Margins = new MarginSettings { Top = 10 },
                     // DocumentTitle = "PDF Report",
                                       

                      Out = @"D:\SmartFactory_File\common\pdf\"+file_name+".pdf",
                },

                    Objects = {
                    new ObjectSettings()
                    {
                        Page = h,
                        WebSettings = { DefaultEncoding = "utf-8" },
                        PagesCount = true,
                    }

                }

                };
                byte[] pdf = _converter.Convert(doc);
                string Out = @"D:\SmartFactory_File\common\pdf\" + file_name + ".pdf";
                var net = new System.Net.WebClient();
                var data = net.DownloadData(Out);
                var content = new System.IO.MemoryStream(data);
                var contentType = "application/force-download";

                return File(content, contentType, Out);


            }
            else
            {
                //웹에서 직접보기
                var doc = new HtmlToPdfDocument()
                {
                    GlobalSettings = {
                     ColorMode = ColorMode.Color,
                     PaperSize = PaperKind.A4,
                     Orientation = Orientation.Landscape,
                     //Orientation = Orientation.Portrait,
                     //Margins = new MarginSettings { Top = 10 },
                     // DocumentTitle = "PDF Report",
                     // Out = @"D:\Pdf\test2.pdf",
                },

                    Objects = {
                    new ObjectSettings()
                    {
                        Page = h,
                        WebSettings = { DefaultEncoding = "utf-8" },
                        PagesCount = true,
                    }

                }

                };
                byte[] pdf = _converter.Convert(doc);
               
                    return new FileContentResult(pdf, "application/pdf");
               

            }

            
          
        }
    }



}
