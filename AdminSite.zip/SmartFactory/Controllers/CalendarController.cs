﻿using System;
using System.Collections.Generic;

using System.Linq;

using Newtonsoft.Json;
using WebSkill.Util;
using SmartFactory.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using static SmartFactory.Controllers.SysController;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using SmartFactory.Util;
using Microsoft.Extensions.Configuration;
using System.IO;
using Microsoft.AspNetCore.Http;
using LazZiya.ImageResize;
using NPOI.SS.Formula.Functions;
using System.Text;
using System.Net;
using System.Threading;

namespace SmartFactory.Controllers
{
    public class CalendarController : Controller
    {
        // GET: Calendar

        private readonly db_e db = new db_e();
        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public CalendarController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        [Authorize]
        public ActionResult calendar_view(calendar doc, string open, string s_date, string e_date, int? idx, int? state, string gubun_type, string report)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            int company_type = Convert.ToInt32(UserData.user_get(user_id, "company_type"));
            #endregion

            #region 날짜 초기화
            DateTime _s_date = DateTime.Today;
            DateTime _e_date = DateTime.Today.AddDays(1);

            if (!string.IsNullOrEmpty(s_date) && !string.IsNullOrEmpty(e_date))
            {
                try
                {
                    _s_date = Convert.ToDateTime(s_date).Date;
                    _e_date = Convert.ToDateTime(e_date).Date;

                    ViewBag.s_date = _s_date.ToShortDateString();
                    ViewBag.e_date = _e_date.ToShortDateString();
                }
                catch
                {
                    ViewBag.s_date = "";
                    ViewBag.e_date = "";
                }
            }
            else
            {
                ViewBag.s_date = _s_date.ToShortDateString();
                ViewBag.e_date = _e_date.ToShortDateString();

            }
            #endregion

            List<calendar> _list = db.calendar.Where(o => o.use_yn != "N").OrderByDescending(o => o.idx).ToList();

            if (!string.IsNullOrEmpty(open))
            {
                int project_idx = Convert.ToInt32(open);
                _list = _list.OrderByDescending(o => o.write_date).ToList();

            }

            if (gubun_type == "U")
            {
                _list = _list.Where(p => p.gubun_type == "U" && p.user_id == user_id).ToList();
                
                
            }

            if (idx != null)
            {

                doc = db.calendar.Single(x => x.idx == idx);

                ViewBag.s_date = doc.start_date.ToShortDateString();
                ViewBag.e_date = doc.end_date.ToShortDateString();

            }
            ViewBag.리스트 = _list;
            ViewBag.company_type = company_type;
            return View(doc);
        }

        [Authorize]
        public ActionResult AddCalPop(calendar doc, DateTime sdate, string sdatestr, string mode, int? idx, int? p_idx, string idxstr, int? open)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            int company_type = Convert.ToInt32(UserData.user_get(user_id, "company_type"));
            #endregion

            ViewBag.user = db.user.Where(p => p.companyIdx == company_idx && p.useYn != "N").ToList();

            #region 변수

            ViewBag.company_idx = company_idx;
            ViewBag.department_idx = department_idx;
            ViewBag.mode = mode;

            #endregion

            if (mode == "W")
            {
                ViewBag.start_date = sdate.ToString("yyyy-MM-dd");
                ViewBag.end_date = sdate.ToString("yyyy-MM-dd");

                ViewBag.pagetitle = "등록";
                ViewBag.state = 1;
            }

            else if (mode == "M")
            {
                #region 모델 저장

                doc = db.calendar.FirstOrDefault(x => x.idx == idx);

                #endregion


                ViewBag.pagetitle = "수정";
                ViewBag.start_date = doc.start_date.ToShortDateString();
                ViewBag.end_date = doc.end_date.ToShortDateString();

                ViewBag.stimeh = doc.start_date.Hour;
                ViewBag.stimem = doc.start_date.Minute;
                ViewBag.etimeh = doc.end_date.Hour;
                ViewBag.etimem = doc.end_date.Minute;

            }
            ViewBag.company_type = company_type;


            return View(doc);
        }

        /// <summary>
        /// 업무등록
        /// </summary>
        /// <param name="db_content"></param>
        /// <param name="mode"></param>
        /// <param name="stimeh"></param>
        /// <param name="stimem"></param>
        /// <param name="etimem"></param>
        /// <param name="etimeh"></param>
        /// <param name="idx"></param>
        /// <param name="files"></param>
        /// <returns></returns>
        public async Task<IActionResult> SaveCal(calendar db_content, string mode, int stimeh, int stimem, int etimem, int etimeh, int? idx, string state, List<IFormFile> files)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            string user_name = UserData.user_get(user_id, "user_name");

            #endregion

            string file_id = DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

            #region 날짜 시간 

            DateTime sdate = (db_content.start_date).AddHours(stimeh).AddMinutes(stimem);
            DateTime edate = (db_content.end_date).AddHours(etimeh).AddMinutes(etimem);

            #endregion

            TimeSpan ts = edate - sdate;

            int time_si = ts.Hours;
            double time_bun_temp = Convert.ToDouble(ts.Minutes) / 60;
            double time_bun = Math.Round(time_bun_temp, 1);
            double run_time = time_si + time_bun;


            if (idx == null)
            {

                if (mode == "W")
                {
                    string msg = "업무 등록";
                    db_content.use_yn = "Y";
                    db_content.user_id = User.Identity.Name;
                    db_content.start_date = sdate;
                    db_content.end_date = edate;
                    db_content.write_date = DateTime.Now;
                    db_content.gubun_type = "M";

                    db.calendar.Add(db_content);
                    db.SaveChanges(); // 실제로 저장

                    History_write(User.Identity.Name, "addcalpop", "입력", msg);

                }




            }
            else if (mode == "M")
            {
                //수정일경우


             
                    var basic_data = (from a in db.calendar where a.idx == idx select a).FirstOrDefault();

                    string msg = "업무 수정";

                    if (user_id != db_content.user_id)
                    {
                        // 업무일정변경 :: error_type 테이블 / 값은 : 4
                        msg = "업무일정변경 사항 : 사용자 변경됨 기존 " + basic_data.user_id + "에서 " + user_id + "로 변경되었습니다.";
                        //  sms_send_who(msg,"4");                         
                    }

                    if (basic_data.title != db_content.title)
                    {
                        // 업무일정변경 :: error_type 테이블 / 값은 : 4
                        msg = "업무일정변경 사항 : 업무명 변경됨 기존 " + basic_data.title + "에서 " + db_content.title + "로 변경되었습니다.";
                        //  sms_send_who(msg, "4");
                    }

     
                    History_write(User.Identity.Name, "addcalpop?idx=" + idx, "수정", msg);


                    calendar _update = (from a in db.calendar where a.idx == idx select a).Single();

                    //메인 담당자 일정 수정

                    _update.start_date = sdate;
                    _update.end_date = edate;
                    _update.title = db_content.title;
                    _update.memo = db_content.memo;

                    await db.SaveChangesAsync();

                }
                else
                {
                    return Redirect("/Calendar/calendar_view?msg=E");
                }

           

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);


                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

           // return Redirect("/Calendar/calendar_view?open=" + db_content.project_idx);

            return Redirect("/Calendar/calendar_view");

        }

        public ActionResult calendar_del_action(int idx, int open)
        {

            #region 수동 업데이트
            calendar _update = (from a in db.calendar where a.idx == idx select a).Single();

            _update.use_yn = "N";

            db.SaveChanges(); // 실제로 저장 




            string user_id = User.Identity.Name;
            // 업무일정삭제 :: error_type 테이블 / 값은 : 4
            //var basic_data = (from a in db.calendar where a.idx == idx select a).FirstOrDefault();
            string msg = "업무일정 삭제 사항 : " + user_id + "가 " + idx + "번 문서를 삭제하였습니다.";
            // sms_send_who(msg, "4");
            History_write(User.Identity.Name, "업무일정", "삭제", msg);

            #endregion

            return Redirect("/Calendar/calendar_view?open=" + open);

        }

        [Authorize]
        public ActionResult calendar_action(calendar doc, string mode, string _type)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            DateTime sdate = doc.start_date;
            DateTime edate = doc.end_date;
            TimeSpan ts = edate - sdate;

            double run_time = ts.Hours;



            if (mode == "W")
            {
                #region 저장

                doc.user_id = User.Identity.Name;
                doc.write_date = DateTime.Now;
                doc.use_yn = "Y";
                db.calendar.Add(doc);
                db.SaveChanges(); // 실제로 저장 

                History_write(User.Identity.Name, "업무일정", "등록", "등록");

                #endregion

            }
            else if (mode == "D")
            {

                #region 수동 업데이트
                calendar _update = (from a in db.calendar where a.idx == doc.idx select a).Single();
                _update.use_yn = "N";

                db.SaveChanges(); // 실제로 저장  

                History_write(User.Identity.Name, "업무일정", "삭제", "삭제");
                #endregion
            }
            else if (mode == "M")
            {
                //수정일경우

                #region 권한체크

                string user = User.Identity.Name;



                string ok_auth = "N";

                if (doc.user_id == user)
                {
                    ok_auth = "Y";
                }
                if (auth >= 8)
                {
                    ok_auth = "Y";
                }


                #endregion

                if (ok_auth == "Y")
                {
                    #region 기본 수정

                    doc.user_id = User.Identity.Name;
                    doc.write_date = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();



                    #endregion
                    History_write(User.Identity.Name, "업무일정", "수정", "수정");
                }
                else
                {
                    return Unauthorized();
                }


            }

            return Redirect("/Calendar/calendar_view");
        }

        [HttpPost]
        public string cal_update(string start, string end, string w, string d, int idx)
        {
            DateTime _start = Convert.ToDateTime(start.Replace("T", " "));
            DateTime _end = Convert.ToDateTime(end.Replace("T", " "));

            string user = User.Identity.Name;
            string state = "N";
            string user_id = w;
            string department_id = d;
            int idx_it = idx;

            #region 기본 사용자 정보        
            int department_idx = Convert.ToInt32(UserData.user_get(user, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user, "auth"));
            #endregion

            string ok_auth = "N";

            if (user_id == user)
            {
                ok_auth = "Y";
            }
            if (auth >= 8)
            {
                ok_auth = "Y";
            }


            if (ok_auth == "Y")
            {
                #region 칼린더 드래그 수정

                calendar _update =
                    (from a in db.calendar where a.idx == idx_it select a).FirstOrDefault();

                _update.start_date = _start;
                _update.end_date = _end;

                db.SaveChanges(); // 실제로 저장  
                state = "Y";

                History_write(User.Identity.Name, "업무일정", "수정", "수정");
                #endregion
            }
            return state;
        }

        //[Authorize]
        //public ActionResult DelCal(CalPopModel Calp)
        //{
        //    string who = Request["who"] ?? "";
        //    string msg = Util.msg.msg_del;
        //    string open = Request["open"];
        //    int idx = Convert.ToInt32(Request["idx"]);
        //    work_list Cdata = (from a in db.work_list where a.idx == idx select a).First();

        //    #region 권한체크

        //    string user = User.Identity.Name;
        //    int auth = 0;
        //    try
        //    {
        //        auth = Convert.ToInt16(Request.Cookies["check_auth"].Value);
        //    }
        //    catch
        //    {
        //    }

        //    string ok_auth = "N";

        //    if (Cdata.user_id == user)
        //    {
        //        ok_auth = "Y";
        //    }

        //    if (auth >= 8)
        //    {
        //        ok_auth = "Y";
        //    }

        //    #endregion

        //    if (ok_auth == "Y")
        //    {
        //        db.work_list.Remove(Cdata);
        //        db.SaveChanges();

        //        return
        //            Content("<script>alert('" + msg + "'); location.href='/Calendar/workcal?open=" + open +
        //                    "';</script>");
        //    }
        //    else
        //    {
        //        return
        //            Content("<script>alert('"+ Util.msg.msg_no+ "'); location.href='/Calendar/workcal?open=" + open + "';</script>");
        //    }
        //}

        ////캘린더 아이템을 가져온다.
        public string GetCalendarItem(string _type, string open, string who, string state)
        {
            string json = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            int project = 0;


            if (!string.IsNullOrEmpty(open))
            {
                try
                {
                    project = Convert.ToInt32(open);
                }
                catch { }
            }


            var calData = (from a in db.calendar
                           where a.use_yn != "N" 
                           select new
                           {
                               id = a.idx,
                               title= a.title,
                               start = a.start_date,
                               end = a.end_date,
                               who = a.user_id,
                               timeget = a.start_date.ToString("HH:mm") + " ~ " + a.end_date.ToString("HH:mm"),
                           }).ToList();


            json = JsonConvert.SerializeObject(calData);

            //json
            string stop = string.Empty;

            return json;
        }

        #region Nested type: CalPopModel

        public class CalPopModel
        {
            public int idx { get; set; }
            public string sday { get; set; }
            public string stimeh { get; set; }
            public string stimem { get; set; }
            public string eday { get; set; }
            public string etimeh { get; set; }
            public string etimem { get; set; }
            public string title { get; set; }
            public string content { get; set; }
            public string category { get; set; }
        }

        #endregion

        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }

        public void History_write(string user_id, string _page, string state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }


    }

}