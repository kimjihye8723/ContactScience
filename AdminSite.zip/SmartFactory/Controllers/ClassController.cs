﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SmartFactory.Models;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Headers;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using LazZiya.ImageResize;
using System.IO;
using SmartFactory.Util;
using ReflectionIT.Mvc.Paging;
using Microsoft.AspNetCore.Routing;
using System.Net;
using NPOI.OpenXmlFormats.Dml;
using static SmartFactory.Controllers.SysController;

namespace SmartFactory.Controllers
{
    public class ClassController : Controller
    {
        // GET: Sys
        private readonly db_e db = new db_e();

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public ClassController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        /// <summary>
        /// / 로그인 정보
        // / </summary>

        #region 클래스 정보
        [Authorize]
        public ActionResult classSet (classInfo doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //Select Box======================================================================================================================================================
            var category = db.code_classCategory.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.카테고리 = new SelectList(category.AsEnumerable(), "값", "이름");

            var scienceCate = db.code_scienceCategory.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.과학분야 = new SelectList(scienceCate.AsEnumerable(), "값", "이름");

            var place = db.code_classPlace.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.장소 = new SelectList(place.AsEnumerable(), "값", "이름");

            var managerIdx = db.user.Where(p => p.useYn == "Y" && p.userClass == 3).OrderBy(P => P.userName).Select(c => new { 값 = c.idx, 이름 = c.userName });
            ViewBag.과학자 = new SelectList(managerIdx.AsEnumerable(), "값", "이름");

            var state = db.code_state.Where(p => p.useYn == "Y").OrderBy(P => P.codeName).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.상태 = new SelectList(state.AsEnumerable(), "값", "이름");
            //Select Box======================================================================================================================================================


            if (idx != null)
            {
                doc = db.classInfo.Single(x => x.idx == idx);
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;

            }
            // 클래스:1 과학자:2

            int file_menu_id = 0;

            try
            {
                file_menu_id = (from a in db.file_menu where a.gubun == 1 select a.file_menu_id).FirstOrDefault();
            }
            catch
            {

            }

            var file_list = (from a in db.file_management where a.code_doc_idx == file_menu_id && a.use_yn == "Y" select a).ToList();

            ViewBag.파일리스트 = file_list;
            ViewBag.파일리스트카운트 = file_list.Count();

            return View(doc);
        }
        [Authorize]
        public async Task<ActionResult> classList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;



            var _list = db.classInfo.Where(a=>a.useYn!="D").Include(p => p.categoryNavigation).Include(p => p.placeNavigation).Include(p=>p.managerIdxNavigation).Include(p => p.scienceCateNavigation).OrderBy(o => o.className).AsNoTracking();


            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.className.Contains(search_all) || p.categoryNavigation.codeName.Contains(search_all) || p.scienceCateNavigation.codeName.Contains(search_all) || p.placeNavigation.codeName.Contains(search_all) || p.title.Contains(search_all) || p.description.Contains(search_all) && p.useYn != "N").OrderBy(p => p.className);

            }

            var model = await PagingList.CreateAsync(_list, 10, page, sortExpression, "-idx");          

           

            return View(model);
        }

        public IActionResult classView(classInfo doc, string sdate, string mode, int? idx, int? classIdx)
        {

            DateTime _sdate = DateTime.Now;


            if (!string.IsNullOrEmpty(sdate))
            {
                _sdate = Convert.ToDateTime(sdate);
            }

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            ViewBag.companyIdx = company_idx;
            ViewBag.department_idx = department_idx;


            if (idx != null)
            {

                doc = db.classInfo.Where(p => p.useYn != "D").Include(p => p.categoryNavigation).Include(p => p.placeNavigation).Include(p => p.scienceCateNavigation).Single(x => x.idx == idx);


                #region 이미지

                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.user_id = user_id;
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion

                //var classPlan = db.classPlan.Where(p => p.classIdx == doc.idx && p.useYn != "N").OrderBy(p => p.planWeek).ToList();
                //ViewBag.운영계획 = classPlan;
                //ViewBag.운영계획_c = classPlan.Count();

                var classPlan = db.classContents.Where(p => p.classIdx == doc.idx && p.useYn != "N").OrderByDescending(p => p.idx).ToList();
                ViewBag.클래스콘텐츠들 = classPlan;
                ViewBag.클래스콘텐츠들_c = classPlan.Count();

            }

            int file_menu_id = 0;

            try
            {
                file_menu_id = (from a in db.file_menu where a.gubun == 1 select a.file_menu_id).FirstOrDefault();
            }
            catch
            {

            }


            var file_list = (from a in db.file_management where a.code_doc_idx == file_menu_id select a).ToList();

            ViewBag.파일리스트 = file_list;
            ViewBag.파일리스트카우트 = file_list.Count();

            return View(doc);
        }

   
        public async Task<IActionResult> classAction(classInfo doc, int? idx, int? useYn, string mode_type, List<IFormFile> files, string file_count)
        {
        

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";

            // 노출여부
            if (doc.useYn == "N" || doc.useYn == "" || doc.useYn == "Y")
            {
                doc.useYn = "Y";
            }
            else
            {
                doc.useYn = "N";
            }

            if (idx == null)
            {
                
                #region 저장
                fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                msg = "S";

                doc.qBoardCate = 6;
                doc.rBoardCate = 7;
                doc.nBoardCate = 5;
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.delDate = DateTime.Now;
                doc.fileId = fileId;
                doc.useYn = "Y";
                db.classInfo.Add(doc);
                await db.SaveChangesAsync();

                //#region 자동생성      
                ////게시판 생성
                //var _insert1 = new BoardMenu
                //{
                //    title = "공지사항",
                //    BoardType_idx = 8,
                //    open_yn = "Y",
                //    classIdx = doc.idx,

                //};         
                //var _insert2 = new BoardMenu
                //{
                //    title = "Q&A",
                //    BoardType_idx = 7,
                //    open_yn = "Y",
                //    classIdx = doc.idx,

                //};                    
                //var _insert3 = new BoardMenu
                //{
                //    title = "후기",
                //    BoardType_idx = 6,
                //    open_yn = "Y",
                //    classIdx = doc.idx,

                //};
                //db.BoardMenu.AddRange(_insert1, _insert2, _insert3);
                //db.SaveChanges();

                ////게시판 업데이트
                //classInfo _update2 =(from a in db.classInfo where a.idx == doc.idx select a).Single();
                //_update2.nBoardCate = _insert1.idx;
                //_update2.qBoardCate = _insert2.idx;
                //_update2.rBoardCate = _insert3.idx;
                //db.SaveChanges();  

                //#endregion

                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";
                    #region 수동 업데이트
                    classInfo _update2 = (from a in db.classInfo where a.idx == idx select a).Single();
                    _update2.useYn = "D";  // 삭제 
                    _update2.delDate = DateTime.Now;
                    db.SaveChanges();
                  
                    #endregion

                }
                else
                {
                    
                    #region 수정
                    fileId = doc.fileId;
                    if (string.IsNullOrEmpty(fileId))
                    {

                    fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                    doc.fileId = fileId;
                    }


                    doc.qBoardCate = 6;
                    doc.rBoardCate = 7;
                    doc.nBoardCate = 5;

                    msg = "E";
                    doc.searchInfo = doc.scienceCate.ToString();
                    doc.editDate = DateTime.Now;
                    //doc.useYn = "Y";
                    db.Entry(doc).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    db.SaveChanges(); 
                    #endregion

                }
            }

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int ssss = 0;
            foreach (var formFile in files)
            {
                try
                {

                    double file_size = formFile.Length;

                    int index_order_file = Convert.ToInt32(file_count.Split(',')[ssss]); // 0,2

                    if (file_size < _fileSizeLimit && file_size > 0)
                    {

                        var formFileContent =
                            await FileHelpers
                                .ProcessFormFile<IFormFile>(
                                    formFile, ModelState, _permittedExtensions,
                                    _fileSizeLimit);




                        #region 변수
                        // 변수 =========================================================================================================================
                        string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                     

                        string file_ex = ""; // 확장자

                        try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                        catch
                        {

                        }
                        var _fileName = only + "." + file_ex;     // 신규 파일 이름  




                        var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                        var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                        string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                        string ore_fileName = Path.GetFileName(formFile.FileName);
                        #endregion





                        //경로에 폴더가 없으면 만들어준다.=============================================
                        var dInfo = new DirectoryInfo(_local_path);
                        var dInfo_s = new DirectoryInfo(desiredThumbPath);
                        if (!dInfo.Exists)
                        {
                            dInfo.Create();
                        }
                        if (!dInfo_s.Exists)
                        {
                            dInfo_s.Create();
                        }
                        //=================================================================================




                        using (var fileStream = System.IO.File.Create(filePath))
                        {
                            await fileStream.WriteAsync(formFileContent);

                        }

                        if (get_word.img_check(file_ex) == "img")
                        {
                            // 세로 기준
                            ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                        }


                        #region 기존 파일 있으면 사용안함으로 변경

                        int _check_old = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a.id).Count();

                        if (_check_old > 0)
                        {
                            BoardFile _update = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a).FirstOrDefault();

                            _update.use_yn = "N";
                            db.SaveChanges(); // 실제로 저장 
                        }

                        #endregion





                        var _insert = new BoardFile()
                        {
                            Md_id = fileId,
                            ImagePath = Models_photo + company_id + "/" + _fileName,
                            fileName = ore_fileName,
                            use_yn = "Y",
                            file_ex = file_ex,
                            file_size = file_size,
                            r_date = DateTime.Now,
                            write_id = user_id,
                            sImagePath = Models_photo + company_id + "/s/" + _fileName,
                            index_order = index_order_file
                        };

                        db.BoardFile.Add(_insert);
                        db.SaveChanges();

                    }

                }
                catch
                {

                }

                ssss++;
            }


            #endregion

            return Redirect("/class/classList?msg="+msg);

        }

        #region 클래스 신청목록
        [Authorize]
        public async Task<ActionResult> applyLIst(int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.orderClassDetail.Where(p => p.useYn == "Y" && p.state == "Y" && p.classIdx == classIdx).Include(p => p.userIdxNavigation).OrderByDescending(p => p.writeDate).AsNoTracking();

            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.userIdxNavigation.userName.Contains(search_all) || p.userIdxNavigation.userTel.Contains(search_all) || p.userIdxNavigation.userEmail.Contains(search_all)).OrderByDescending(p => p.writeDate);

            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");

         
           
            ViewBag.신청목록_c = _list.Count();
            return View(model);
        }

        public async Task<IActionResult> applyAction(orderClassDetail doc, int? idx, string mode_type, List<IFormFile> files, string file_count, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";

            if (idx == null)
            {

                #region 저장
                msg = "S";

                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.delDate = DateTime.Now;
                doc.useYn = "Y";
                db.orderClassDetail.Add(doc);
                await db.SaveChangesAsync();
                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";
                    #region 수동 업데이트
                    orderClassDetail _update2 = (from a in db.orderClassDetail where a.idx == idx select a).Single();
                    _update2.useYn = "N";
                    _update2.delDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion

                }
                else
                {

                    #region 수정                  
                    msg = "E";
                    doc.editDate = DateTime.Now;
                    doc.useYn = "Y";
                    db.Entry(doc).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    db.SaveChanges();
                    #endregion

                }
            }


            return Redirect("/class/applyList?classIdx="+classIdx);

        }

        #endregion

      
        public ActionResult surveyList(classInfo doc, int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.classInfo.Where(p => p.idx == classIdx && p.useYn != "N").OrderByDescending(p => p.writeDate).AsNoTracking().FirstOrDefault();
            ViewBag.설문조사링크 = _list;
        


            //if (!string.IsNullOrEmpty(search_all))
            //{

            //    _list = _list.Where(p => p..Contains(search_all) || p.userIdxNavigation.userTel.Contains(search_all) || p.userIdxNavigation.userEmail.Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.writeDate);

            //}

            //var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            return View(doc);
        }

        // 클래스 운영계획 등록 페이지
        public ActionResult planSet(classPlan doc, int? idx, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion


            if (idx != null)
            {
                doc = db.classPlan.Single(x => x.idx == idx);

            }


            return View(doc);
        }


        // 클래스 관련 콘텐츠 등록페이지
        public ActionResult planSet2(classContents doc, int? idx, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            if (idx != null)
            {
                doc = db.classContents.Single(x => x.idx == idx);
            }

            return View(doc);
        }

        [HttpPost]
        //public async Task<IActionResult> planAction(classPlan doc, int? idx, string mode_type, int? classIdx, string mainYn, List<IFormFile> file)
        //{
        //    StringBuilder sb = new StringBuilder();

        //    #region 기본 사용자 정보
        //    string user_id = User.Identity.Name;
        //    int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
        //    string company_id = UserData.user_get(user_id, "company_id");
        //    int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
        //    int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
        //    #endregion
        //    string msg = "";

        //    string file_id = "";


        //    if (idx == null)
        //    {

        //        #region 저장
        //        msg = "저장";
        //        doc.writer = user_id;
        //        doc.writeDate = DateTime.Now;
        //        doc.editDate = DateTime.Now;
        //        doc.delDate = DateTime.Now;
        //        doc.useYn = "Y";
        //        db.classPlan.Add(doc);
        //        await db.SaveChangesAsync();
        //        #endregion

        //    }
        //    else
        //    {

        //        if (mode_type == "D")
        //        {
        //            msg = "삭제";

        //            #region 수동 업데이트
        //            classPlan _update2 =
        //                     (from a in db.classPlan where a.idx == idx select a).Single();

        //            _update2.useYn = "N";
        //            _update2.delDate = DateTime.Now;
        //            db.SaveChanges(); 
        //            #endregion
        //        }
        //        else
        //        {

        //            #region 수정
        //            msg = "수정";
        //            doc.editDate = DateTime.Now;
        //            doc.useYn = "Y";
        //            db.Entry(doc).State = EntityState.Modified;
        //            await db.SaveChangesAsync();
        //            db.SaveChanges();
        //            #endregion

        //        }
        //    }

        //    return Redirect("/classSquare/classView?idx=" + classIdx + "&classIdx=" + classIdx);

        //}


        public async Task<IActionResult> planAction(classContents doc, int? idx, string mode_type, int? classIdx, string mainYn, List<IFormFile> files)
        {
            StringBuilder sb = new StringBuilder();

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";

            string file_id = "";


            if (idx == null)
            {
                if (files.Count() > 0)
                {
                    file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    doc.fileId = file_id;
                }

                #region 저장
                msg = "저장";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.useYn = "Y";
                doc.mainYn = mainYn;
                db.classContents.Add(doc);
                await db.SaveChangesAsync();
                #endregion


            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "삭제";

                    #region 수동 업데이트
                    classContents _update2 =
                             (from a in db.classContents where a.idx == idx select a).Single();

                    _update2.useYn = "N";
                    //_update2.delDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion
                }
                else
                {

                    #region 수정
                    msg = "수정";

                    #region 파일 아이디

                    if (files.Count() > 0)
                    {
                        file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        doc.editDate = DateTime.Now;
                        doc.fileId = file_id;
                    }
                    #endregion

                    //#region 업로드 링크
                    //var link = doc.link;

                    //if (link != "")
                    //{
                    //    doc.fileId = "";
                    //    doc.link = link;
                    //}
                    //#endregion



                    // doc.editDate = DateTime.Now;
                    doc.useYn = "Y";

                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();
                    #endregion

                }
            }




            #region 파일 올리기

            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);

                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;    // 신규 파일 이름   
                    var _local_path = _targetFilePath + "/";   // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);    // 전체 경로
                    string desiredThumbPath = _local_path + "s/";   // 작은 이미지 전체 경로
                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion

                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================

                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);
                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }

                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion



            return Redirect("/class/classView?idx=" + classIdx + "&classIdx=" + classIdx);

        }




        #region 게시판

        public async Task<IActionResult> Board_List(int? cate, int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            ViewBag.company_idx = company_idx;
            #endregion

            #region 변수설정
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;
            ViewBag.카테고리 = cate.ToString();

            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }

            if (auth >= 8)
            {
                //게시판 종류 드롭다운==============================================================================================================================================          
                var category =
                    db.BoardMenu.Where(
                        a =>
                        a.company_idx == company_idx && a.open_yn == "Y").Select(
                            a => new { 값 = a.idx, 이름 = a.title });
                ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
                //=====================================================================================================================================================================

            }
            else
            {
                //회사별 데이터 드롭다운==============================================================================================================================================          
                var category =
                    db.BoardMenu.Where(
                        a =>
                        a.company_idx == company_idx && ((a.department_idx == department_idx || a.open_yn == "Y"))).Select(
                             a => new { 값 = a.idx, 이름 = a.title });
                ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
                //=====================================================================================================================================================================
            }

            //======================================================================================================================================================== 
            var company_type =
                db.company.Where(p => (p.useYn == "Y" && p.idx != 4)).OrderBy(
                    o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.요청회사 = new SelectList(company_type.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 

            #endregion

            var query = db.BoardList.AsNoTracking().Where(a => a.useable != "N" && a.BM_idx == cate && a.classIdx == classIdx).Include(a=>a.classIdxNavigation).OrderByDescending(a=>a.writeDate);

            var model = await PagingList.CreateAsync(query, 10, page, sortExpression, "-idx");

            model.RouteValue = new RouteValueDictionary {
                { "search_all", search_all},
                { "search_all_type", search_all_type}
            };

            if (!string.IsNullOrEmpty(search_all))
            {
                if (search_all_type == "1")
                {
                    query = query.Where(p => p.title.Contains(search_all) || p.content.Contains(search_all)).OrderByDescending(a => a.writeDate);
                }
                if (search_all_type == "2")
                {
                    query = query.Where(p => p.title.Contains(search_all)).OrderByDescending(a => a.writeDate);
                }
                if (search_all_type == "3")
                {
                    query = query.Where(p => p.writer.StartsWith(search_all)).OrderByDescending(a => a.writeDate);
                }

                model = await PagingList.CreateAsync(query, 20, page, sortExpression, "-idx");

                model.RouteValue = new RouteValueDictionary {
                { "search_all", search_all},
                { "search_all_type", search_all_type}

            };

            }

            //권한 시작==============================================================================================
            BoardAuth(null, cate);
            //권한 끝================================================================================================

            return View(model);

        }

        public ActionResult BoardView(int idx, int? cate, int? classIdx)
        {
            if (idx == 0)
            {
                //0번 게시글은 임시글로써, DB에 존재하지 않는 글임
                return NotFound();
            }

            //권한 시작==============================================================================================
            BoardAuth(idx, cate);
            //권한 끝================================================================================================

            BoardList data = db.BoardList.Find(idx);

            #region 파일 가져오기
            //파일 가져오기=====================================================================================================================                    

            var _list = (from a in db.BoardFile where a.Md_id == data.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

            ViewBag.이미지리스트 = _list;
            ViewBag.이미지리스트카운트 = _list.Count();

            //파일 끝============================================================================================================================ 
            #endregion

            #region 조회수 증가

            data.hit = data.hit + 1; ;

            db.SaveChanges(); // 실제로 저장 


            #endregion

            #region 읽은 사용자 저장

            int _readCount = (from a in db.BoardRread where a.board_idx == idx && a.user_id == User.Identity.Name select a.idx).Count();

            if (_readCount == 0)
            {

                var _insert = new BoardRread
                {
                    user_id = User.Identity.Name,
                    user_name = (from a in db.user where a.userId == User.Identity.Name select a.userName).FirstOrDefault(),
                    read_date = DateTime.Now,
                    board_idx = idx

                };

                db.BoardRread.Add(_insert);
                db.SaveChanges(); // 실제로 저장 
            }


            var _read = (from a in db.BoardRread where a.board_idx == idx select a).ToList();

            ViewBag.읽은사람 = _read;

            #endregion

            #region 코멘트 가져오기

            IQueryable<BoardComment> _listComent = Enumerable.Empty<BoardComment>().AsQueryable();

            _listComent = db.BoardComment.Where(p => p.BD_idx == idx && p.use_yn == "Y").OrderByDescending(o => o.idx);

            ViewBag.댓글 = _listComent;
            ViewBag.댓글수 = _listComent.Count();
            #endregion

            return View(data);
        }

        private void BoardAuth(int? idx, int? cate)
        {
            #region 권한

            ViewBag.권한 = "";
            ViewBag.부서 = "";
            ViewBag.관리자 = "";
            ViewBag.코멘트 = "N";
            ViewBag.파일 = "N";

            string user_id = "";

            if (cate != null)
            {
                ViewBag.부서 = (from a in db.BoardMenu where a.idx == cate select a.department_idx).FirstOrDefault();
            }
            string board_type = (from a in db.BoardMenu where a.idx == cate select a.BoardType_idxNavigation.gubun).FirstOrDefault();

            foreach (var item in board_type.Split(","))
            {
                if (item == "file")
                {
                    ViewBag.파일 = "Y";
                }
                if (item == "replay")
                {
                    ViewBag.코멘트 = "Y";
                }
            }

            int _auth_department = 0;
            if (User.Identity.IsAuthenticated)
            {
                //로그인 했을 경우

                user_id = User.Identity.Name;

                _auth_department = (from a in db.user where a.userId == user_id select a.checkAuth).FirstOrDefault();

                if (_auth_department >= 8)
                {
                    ViewBag.권한 = "E";
                    ViewBag.관리자 = "Y";

                }

                if (idx != null)
                {
                    string _auth_writer = (from a in db.BoardList where a.idx == idx select a.writer).FirstOrDefault() ?? "";

                    if (user_id == _auth_writer)
                    {
                        ViewBag.권한 = "E";
                    }
                }

                ViewBag.로그인 = "Y";
            }

            else
            {
                ViewBag.타입 = "normal";
                ViewBag.타이틀 = "전체";
                ViewBag.권한 = "";

                if (ViewBag.부서 == "guest")
                {
                    ViewBag.권한 = "G";
                }
            }

            #endregion
        }

        public ActionResult BoardWrite(BoardList doc, int? idx, int? cate, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.company_idx = company_idx;

            //======================================================================================================================================================== 
            var company_type =
                db.company.Where(p => (p.useYn == "Y")).OrderBy(
                    o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.요청회사 = new SelectList(company_type.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 


            if (idx != null)
            {
                //수정모드
                doc = db.BoardList.Find(idx);

                #region 첨부파일 가져오기
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;
            }

            BoardAuth(idx, cate);

            return View(doc);
        }

        [HttpPost]
        public async Task<IActionResult> Board_action(BoardList doc, int? idx, int? typeIdx, int cate, string mode_type, List<IFormFile> files)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            string file_id = "";
            string msg = "";

            if (idx == null)
            {
                msg = "S";
                file_id = DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                #region 저장
                doc.fileId = file_id;
                doc.useable = "Y";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                db.BoardList.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                #endregion
            }
            else
            {
                int _idx = Convert.ToInt32(idx);

                if (mode_type == "D")
                {
                    #region 삭제

                    msg = "D";
                    BoardList _update =
                     (from a in db.BoardList where a.idx == idx select a).Single();

                    _update.useable = "N";
                    _update.delDate = DateTime.Now;

                    db.SaveChanges(); // 실제로 저장 

                    #endregion
                }
                else
                {
                    #region 수정
                    msg = "E";
                    #region 파일 아이디
                    file_id = doc.fileId;

                    if (string.IsNullOrEmpty(file_id))
                    {

                        file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                        doc.fileId = file_id;
                    }
                    #endregion

                    doc.useable = "Y";
                    doc.editDate = DateTime.Now;
                    doc.writeDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;

                    //idx 제외 업데이트=================================
                    db.Entry(doc).Property("idx").IsModified = false;
                    //==================================================
                    db.SaveChanges();



                    #endregion
                }
            }

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            //===============================================================================
            UserData history = new UserData();
            history.History_write(User.Identity.Name, "/board/boardwrite/cate=" + cate, msg);
            //==============================================================================

            string returnUrl = "/class/board_list?cate=" + cate+"&typeIdx=" + typeIdx +"&classIdx="+doc.classIdx +"&msg="+msg;

            return Redirect(returnUrl);

        }

        [HttpPost]
        public async Task<IActionResult> BoardImageUpload(string CKEditorFuncNum, IFormFile upload)
        {

            #region 파일 올리기

            string user_id = User.Identity.Name;
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");




            var formFileContent =
                await FileHelpers
                    .ProcessFormFile<IFormFile>(
                        upload, ModelState, _permittedExtensions,
                        _fileSizeLimit);



            // 변수 =========================================================================================================================
            string only = DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

            var _fileName = only + Path.GetFileName(upload.FileName);     // 신규 파일 이름                    
            var _local_path = _targetFilePath + company_id + "/";            // 신규 파일 경로
            var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로

            string ImagePath = Models_photo + company_id + "/" + _fileName;




            //경로에 폴더가 없으면 만들어준다.=============================================
            var dInfo = new DirectoryInfo(_local_path);

            if (!dInfo.Exists)
            {
                dInfo.Create();
            }

            //=================================================================================



            using (var fileStream = System.IO.File.Create(filePath))
            {
                await fileStream.WriteAsync(formFileContent);

            }



            var sb = new StringBuilder();
            sb.AppendFormat("<script>");
            sb.AppendFormat("window.parent.CKEDITOR.tools.callFunction('" + CKEditorFuncNum + "', '" + ImagePath + "', 'OK'); ");
            sb.AppendFormat("history.go(-1)");
            sb.AppendFormat("</script>");
            await Response.WriteAsync(sb.ToString());


            #endregion

            return null;

        }

        public ActionResult BoardComment_action(BoardComment doc, string BD_idx, string cate, string mode_type, int? c_idx, int? classIdx)
        {
            int idx = 0;

            string msg = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            if (c_idx == null)
            {
                #region 저장

                doc.write_date = DateTime.Now;
                doc.writer = User.Identity.Name;
                doc.edit_date = DateTime.Now;
                doc.use_yn = "Y";
                db.BoardComment.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {

                if (mode_type == "D")
                {
                    #region 삭제

                    BoardComment doc_del = db.BoardComment.Single(x => x.idx == c_idx);
                    db.BoardComment.Remove(doc_del);
                    db.SaveChanges();

                    msg = Util.msg.msg_del;

                    #endregion
                }

                else if (mode_type == "E")
                {
                    #region 임시 삭제 / 상태 변환 업데이트

                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == c_idx select a).Single();
                    _update.edit_date = DateTime.Now;
                    _update.use_yn = "D";
                    _update.writer = User.Identity.Name;

                    db.SaveChanges(); // 실제로 저장 


                    msg = Util.msg.msg_disable;

                    #endregion
                }
                else
                {
                    #region 수정


                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == idx select a).Single();

                    _update.edit_date = DateTime.Now;
                    _update.memo = doc.memo;


                    db.SaveChanges(); // 실제로 저장 



                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }
            string url = "/classSquare/boardview?idx=" + BD_idx + "&cate=" + cate + "%classIdx="+ classIdx;

            return Redirect(url);

        }

        public ActionResult del_set_check(BoardList doc, int file_idx)
        {

            BoardList _updateContent =
                    (from a in db.BoardList where a.idx == doc.idx select a).Single();

            _updateContent.title = doc.title;
            _updateContent.content = doc.content;
            _updateContent.editDate = DateTime.Now;

            db.SaveChanges(); // 실제로 저장 

            #region 삭제

            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();
            _update.use_yn = "N";

            db.SaveChanges(); // 실제로 저장 

            #endregion                       

            return Redirect("/classSquare/BoardWrite?cate=" + doc.BM_idx + "&idx=" + doc.idx);
        } 
        #endregion


        #endregion


        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
        private async Task fileUpload(List<IFormFile> files, string user_id, string file_id)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }
        }
        public void History_write(string user_id, string _page, string _state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }


    }
}