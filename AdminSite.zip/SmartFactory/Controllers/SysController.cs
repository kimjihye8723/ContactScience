﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SmartFactory.Models;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Headers;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using LazZiya.ImageResize;
using System.IO;
using SmartFactory.Util;
using ReflectionIT.Mvc.Paging;
using Microsoft.AspNetCore.Routing;
using System.Net;
using NPOI.OpenXmlFormats.Dml;
using System.Web;

namespace SmartFactory.Controllers
{
    public class SysController : Controller
    {
        // GET: Sys
        private readonly db_e db = new db_e();

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public SysController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        /// <summary>
        /// / 로그인 정보
        // / </summary>
        public class UserData
        {
            public static string user_get(string user_id, string what)
            {

                db_e db = new db_e();

                string company_id = "BlueEye";
                string company_name = "BlueEye";
                string user_name = "";
                int department_idx = 0;
                int company_idx = 0;
                string department_name = "";
                int auth = 0; //초기 :0
                string user_auth = "";
                string position_idx = "0";
                string company_type = "0";

                var _list = (from a in db.user.Include(p => p.companyIdxNavigation).Include(p => p.departmentIdxNavigation) where a.userId == user_id select a).FirstOrDefault();

                if (_list != null)
                {
                    company_id = _list.companyIdxNavigation.companyId;
                    company_name = _list.companyIdxNavigation.companyName;
                    company_idx = _list.companyIdxNavigation.idx;
                    department_name = _list.departmentIdxNavigation.department_name;
                    user_name = _list.userName;
                    department_idx = _list.departmentIdx;
                    auth = _list.checkAuth; //최고 권한 관리자 :9 , 회사별 권한 관리자 : 8 , 부서장 : 7
                    user_auth = _list.userAuth; //페이지 권한 

                }

                string str = "";

                if (what == "user_id")
                {
                    str = user_id;
                }
                else if (what == "user_name")
                {
                    str = user_name;
                }
                else if (what == "company_id")
                {
                    str = company_id;
                }
                else if (what == "company_idx")
                {
                    str = company_idx.ToString();
                }
                else if (what == "company_name")
                {
                    str = company_name;
                }
                else if (what == "department_idx")
                {
                    str = department_idx.ToString();
                }
                else if (what == "department_name")
                {
                    str = department_name;
                }
                else if (what == "auth")
                {
                    str = auth.ToString();
                }
                else if (what == "user_auth")
                {
                    str = user_auth.ToString();
                }

                return str;

            }
           
            public void History_write(string user_id, string _page, string _state)
            {
                db_e db = new db_e();

                string user_name = UserData.user_get(user_id, "user_name");
                string department_id = UserData.user_get(user_id, "department_id");
                string department_name = UserData.user_get(user_id, "department_name");
                string company_id = UserData.user_get(user_id, "company_id");
                string company_name = UserData.user_get(user_id, "company_name");
                string auth = UserData.user_get(user_id, "auth");

                if (_state == "S")
                {
                    _state = "저장";

                }
                else if (_state == "D")
                {
                    _state = "삭제";
                }
                else
                {
                    _state = "수정";
                }


                var _insert = new history
                {
                    user_id = user_id,
                    company_id = company_id,
                    department_id = department_id,
                    user_ip = "",
                    pre_page = "",
                    connect_agent = company_name,
                    connect_host = auth,
                    connect_path = user_name,
                    memo = department_name,
                    connect_date = DateTime.Now,
                    state = _state,
                    page = _page
                };

                db.history.Add(_insert);
                db.SaveChanges(); // 실제로 저장 


            }
        }

        #region 사용자 개인 정보 수정

        public ActionResult user_info(user doc)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            #region Select Box
            //========================================================================================================================================================
            var _code_nationality = db.code_nationality.Where(p => p.use_yn == "Y").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.언어 = new SelectList(_code_nationality.AsEnumerable(), "값", "이름");

            //========================================================================================================================================================

            //========================================================================================================================================================
            var _department = db.department.Where(p => p.company_idx == company_idx && p.use_yn != "N").OrderBy(P => P.index_order).Select(c => new { 값 = c.idx, 이름 = c.department_name });
            ViewBag.부서 = new SelectList(_department.AsEnumerable(), "값", "이름");

            //======================================================================================================================================================== 
            #endregion

            doc = db.user.Single(x => x.userId == user_id);

            #region 이미지 찾기


            var _list = (from a in db.BoardFile where a.Md_id == doc.photoProfile && a.use_yn != "N" select a).OrderBy(p=>p.use_yn).ThenByDescending(p => p.id).ToList();

            ViewBag.이미지리스트 = _list;
            ViewBag.이미지리스트카운트 = _list.Count();
            #endregion

            return View(doc);
        }

        [HttpPost]
        public async Task<ActionResult> userinfo_action(user doc, List<IFormFile> files)
        {

            //==================================================================
            UserData UserData = new UserData();
            //===================================================================

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            #region 파일 아이디
            string file_id = "";


            file_id = doc.photoProfile;

            if (string.IsNullOrEmpty(file_id))
            {

                file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();


            }
            #endregion

            #region 파일 올리기

            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);

                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = doc.userId + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;    // 신규 파일 이름   
                    var _local_path = _targetFilePath + company_id + "/";   // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);    // 전체 경로
                    string desiredThumbPath = _local_path + "s/";   // 작은 이미지 전체 경로
                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion

                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================

                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);
                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }

                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            #region 사용자 정보 수정
            user _update =
                     (from a in db.user where a.userId == User.Identity.Name select a).Single();

            _update.userTel = doc.userTel;
            _update.userName = doc.userName;
            _update.userPassword = doc.userPassword;
            _update.editDate = DateTime.Now;
            _update.userEmail = doc.userEmail;
            _update.photoProfile = file_id;
            _update.main_bg_color = doc.main_bg_color;

            db.SaveChanges(); // 실제로 저장  
            #endregion

            UserData.History_write(User.Identity.Name, "/sys/user_info", "수정");

            return Redirect("/sys/user_info");

        }
        #endregion

        #region 기록 히스토리
        /// <summary>
        /// 
        /// </summary>
        /// <param name="user_id">아이디</param>
        /// <param name="_page">해당 페이지</param>
        /// <param name="_state">처리상태(입력,수정,삭제)</param>
        /// 

        #endregion

        #region 회사 설정

        public ActionResult company_set_check(string doc_it)
        {
            int _doc = (from a in db.company where a.companyId == doc_it select a.companyId).Count();
            var sb = new StringBuilder();
            if (_doc > 0)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#company_id').attr('value' ,'') ; ");
                sb.AppendFormat("demo.showSwal('auto-close');");
                sb.AppendFormat("$('#id_check').attr('value' ,'N') ;");
                sb.AppendFormat("$('#company_id').css('border' ,'solid 1px red') ; ");
                sb.AppendFormat("$('#company_id').focus() ; ");
                sb.AppendFormat("demo.showSwal('alert','0','사용 불가한 아이디입니다.');");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }
            else
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#id_check').attr('value' ,'Y') ;");
                sb.AppendFormat("$('#company_id').css('border' ,'solid 1px green') ; ");
                sb.AppendFormat("demo.showSwal('alert','0','사용 가능한 아이디입니다.');");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }

            return null;
        }

        #region company




        [Authorize]
        public ActionResult company_set(company doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            #region Select Box
            //======================================================================================================================================================== 
            var Code_nation =
                db.code_nationality.Where(p => p.use_yn == "Y").OrderBy(o => o.index_order).Select(
                    c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.국적 = new SelectList(Code_nation.AsEnumerable(), "값", "이름");
            //========================================================================================================================================================
            var code_company = db.code_company.Where(p => p.use_yn == "Y").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.회사구분 = new SelectList(code_company.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 
            #endregion


            #region 리스트 첨부파일
            if (idx != null)
            {

                doc = db.company.Single(x => x.idx == idx);
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;

            }

            #endregion

            return View(doc);
        }

        [Authorize]
        public async Task<ActionResult> company_set_listAsync(string gubun_idx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            #region 회사구분
            //========================================================================================================================================================
            var code_company = db.code_company.Where(p => p.use_yn == "Y").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.회사구분 = new SelectList(code_company.AsEnumerable(), "값", "이름");

            //========================================================================================================================================================
            var _companyIdx = company_idx.ToString();
            var _list = db.company.Where(p => p.useYn != "D" && p.idx != company_idx).Include(p => p.codeCompanyIdxNavigation).OrderBy(o => o.indexOrder).AsNoTracking();

            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.companyName.Contains(search_all) || p.businessNum.Contains(search_all) || p.address.Contains(search_all) || p.tel.Contains(search_all) && p.useYn != "D").OrderBy(p => p.companyName);
                
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");
            ViewBag.본점 = db.company.Where(p => p.useYn != "D" && p.idx == company_idx).Include(p => p.codeCompanyIdxNavigation).FirstOrDefault();
            #endregion


            return View(model);
        }

        public IActionResult company_set_view(company doc, string sdate, string mode, int? idx)
        {

            DateTime _sdate = DateTime.Now;


            if (!string.IsNullOrEmpty(sdate))
            {
                _sdate = Convert.ToDateTime(sdate);
            }

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            ViewBag.companyIdx = company_idx;
            ViewBag.department_idx = department_idx;


            if (idx != null)
            {

                doc = db.company.Where(p => p.useYn == "Y").Single(x => x.idx == idx);


                #region 히스토리 처리

                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();



                ViewBag.user_id = user_id;
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion


            }


            return View(doc);
        }

        public async Task<IActionResult> company_set_action(List<IFormFile> files, company doc, string mode_type, int? idx, string file_count, string url)
        {
            string msg = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            string department_idx = UserData.user_get(user_id, "department_idx");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string auth = UserData.user_get(user_id, "auth");
            string fileId = "";
            string memo = "";
            #endregion

            int _id = 1;

            try
            {
                _id = (from a in db.company select a.idx).Max() + 1;
            }
            catch
            {
            }

            if (doc.useYn == "on")
            {
                doc.useYn = "Y";
            }
            else
            {
                doc.useYn = "N";
            }

            if (idx == null)
            {
                #region 저장

                msg = "S";
                fileId = company_id + department_idx + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                    doc.writeDate = DateTime.Now;
                    doc.editDate = DateTime.Now;
                    doc.indexOrder = _id;
                    doc.fileId = fileId;
                    db.company.Add(doc);
                    db.SaveChanges(); // 실제로 저장 

                    //msg = Util.msg.msg_insert;
                    History_write(User.Identity.Name, "company_set", msg, memo);
             

                #endregion
            }
            else
            {
                if (mode_type == "D")
                {
                    #region 삭제
                    msg = "D";
                    company _update =
                        (from a in db.company where a.idx == idx select a).Single();
                    _update.useYn = "D";
                    _update.editDate = DateTime.Now;

                    db.SaveChanges(); // 실제로 저장 

                    //msg = Util.msg.msg_del;
                    memo = memo + "삭제";
                    History_write(User.Identity.Name, "company_set", msg, memo);
                    return Redirect("/sys/company_set_list");
                    #endregion
                }
                else
                {
                    #region 수정
                    msg = "E";
                    fileId = doc.fileId;

                    if (string.IsNullOrEmpty(fileId))
                    {

                        fileId = company_id + department_idx + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                        doc.fileId = fileId;
                    }
                    doc.editDate = DateTime.Now;
                    doc.writeDate = DateTime.Now;
                    doc.indexOrder = _id;
                    db.Entry(doc).State = EntityState.Modified;
                    memo = memo + "수정";                 

                    db.SaveChanges();

                    //msg = Util.msg.msg_edit;

                    #endregion
                }
            }



            History_write(User.Identity.Name, "company_set", msg, memo);

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int ssss = 0;
            foreach (var formFile in files)
            {
                try
                {

                    double file_size = formFile.Length;

                    int index_order_file = Convert.ToInt32(file_count.Split(',')[ssss]); // 0,2

                    if (file_size < _fileSizeLimit && file_size > 0)
                    {

                        var formFileContent =
                            await FileHelpers
                                .ProcessFormFile<IFormFile>(
                                    formFile, ModelState, _permittedExtensions,
                                    _fileSizeLimit);




                        #region 변수
                        // 변수 =========================================================================================================================
                        string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                     

                        string file_ex = ""; // 확장자

                        try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                        catch
                        {

                        }
                        var _fileName = only + "." + file_ex;     // 신규 파일 이름  




                        var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                        var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                        string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                        string ore_fileName = Path.GetFileName(formFile.FileName);
                        #endregion





                        //경로에 폴더가 없으면 만들어준다.=============================================
                        var dInfo = new DirectoryInfo(_local_path);
                        var dInfo_s = new DirectoryInfo(desiredThumbPath);
                        if (!dInfo.Exists)
                        {
                            dInfo.Create();
                        }
                        if (!dInfo_s.Exists)
                        {
                            dInfo_s.Create();
                        }
                        //=================================================================================




                        using (var fileStream = System.IO.File.Create(filePath))
                        {
                            await fileStream.WriteAsync(formFileContent);

                        }

                        if (get_word.img_check(file_ex) == "img")
                        {
                            // 세로 기준
                            ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                        }


                        #region 기존 파일 있으면 사용안함으로 변경

                        int _check_old = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a.id).Count();

                        if (_check_old > 0)
                        {
                            BoardFile _update = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a).FirstOrDefault();

                            _update.use_yn = "N";
                            db.SaveChanges(); // 실제로 저장 
                        }

                        #endregion





                        var _insert = new BoardFile()
                        {
                            Md_id = fileId,
                            ImagePath = Models_photo + company_id + "/" + _fileName,
                            fileName = ore_fileName,
                            use_yn = "Y",
                            file_ex = file_ex,
                            file_size = file_size,
                            r_date = DateTime.Now,
                            write_id = user_id,
                            sImagePath = Models_photo + company_id + "/s/" + _fileName,
                            index_order = index_order_file
                        };

                        db.BoardFile.Add(_insert);
                        db.SaveChanges();

                    }

                }
                catch
                {

                }

                ssss++;
            }


            #endregion

            if(url != null)
            {
                return Redirect(url);
            }

            //return Redirect("/sys/company_set?idx=" + idx);
            return Redirect("/sys/company_set_list?msg=" +msg);


        }

        #endregion

        #endregion

        #region 부서 설정

        public ActionResult file_set_del(int doc_it) //디자인 담당자 정보 Load 
        {
            var sb = new StringBuilder();




            #region 수동 업데이트
            try
            {
                BoardFile _update = (from a in db.BoardFile where a.id == doc_it select a).Single();

                _update.use_yn = "N";

                db.SaveChanges(); // 실제로 저장  


                sb.AppendFormat("<script>");

                sb.AppendFormat("$('#f_" + doc_it + "').css('display' ,'none');");

                sb.AppendFormat("alert('삭제되었습니다.') ;");

                sb.AppendFormat("</script>");


            }
            catch
            {

                sb.AppendFormat("<script>");

                sb.AppendFormat("alert('다시 시도해주세요.') ;");

                sb.AppendFormat("</script>");
            }
            #endregion






            Response.WriteAsync(sb.ToString());


            return null;
        }

        [Authorize]
        public ActionResult department_set(department doc, int? idx)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            string department_idx = UserData.user_get(user_id, "department_idx");
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            ViewBag.company_idx = company_idx;
            #endregion

            if (auth >= 9)
            {
                //======================================================================================================================================================== 
                var Code_company =
                    db.company.Where(p => p.useYn == "Y").OrderBy(o => o.indexOrder).Select(
                        c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

                //======================================================================================================================================================== 
                var Code_auth =
                    db.CategoryMenus.Where(p => p.company_id == company_id && p.step_dept == 2).OrderBy(o => o.step_auth)
                        .Select(c => new { 값 = c.step_auth, 이름 = c.step_name });
                ViewBag.권한 = new SelectList(Code_auth.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 
            }
            else
            {
                //======================================================================================================================================================== 
                var Code_company =
                    db.company.Where(p => p.idx == company_idx).OrderBy(
                        o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 
            }

            if (idx != null)
            {
                doc = db.department.Single(x => x.idx == idx);
            }

            return View(doc);
        }

        [Authorize]
        public ActionResult department_set_list(string companyidx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            //======================================================================================================================================================== 
            var Code_company = db.company.Where(p => p.useYn == "Y").OrderBy(o => o.indexOrder).Select(
                    c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 

            IOrderedQueryable<department> _list = db.department.Where(p => p.use_yn != "D").Include(p => p.company_idxNavigation).OrderBy(o => o.index_order).ThenBy(o => o.idx);

            if (!string.IsNullOrEmpty(companyidx))
            {
                int _companyIdx_int = 0;

                try
                {
                    _companyIdx_int = Convert.ToInt32(companyidx);
                }
                catch
                {

                }

                _list = _list.Where(p => p.company_idx == _companyIdx_int).Include(p => p.company_idxNavigation).OrderBy(o => o.index_order).ThenBy(
                        o => o.department_name);

            }
            else
            {
                // 기본값 블루아이 :4

                int _companyIdx_int = 4;



                _list = _list.Where(p => p.company_idx == _companyIdx_int).Include(p => p.company_idxNavigation).OrderBy(o => o.index_order).ThenBy(
                        o => o.department_name);

            }

            if (auth < 9)
            {
                //======================================================================================================================================================== 
                Code_company =
                   db.company.Where(p => p.companyId == company_id && p.useYn == "Y").OrderBy(
                       o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

                _list = db.department.Where(p => p.company_idx == company_idx && p.use_yn != "D").OrderBy(o => o.index_order).ThenBy(o => o.idx);
            }

            return View(_list.ToList());
        }

        public Action department_set_add_action(int company_idx, string department_name)
        {

            var sb = new StringBuilder();
            var _list = (from a in db.department where a.company_idx == company_idx && a.department_name == department_name select a.company_idx).Count();

            if (_list > 0)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("alert('같은 이름의 부서명이 있습니다.'); ");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }
            else
            {
                #region 수동 입력

                var _insert = new department
                {
                    company_idx = company_idx,
                    department_name = department_name,
                    write_date = DateTime.Now,
                    use_yn = "Y",
                    index_order = 1

                };

                db.department.Add(_insert);
                db.SaveChanges(); // 실제로 저장 

                //부서 가져오기=========================================================================================================================================
                var _department = db.department.Where(p => p.company_idx == company_idx && p.use_yn != "N").OrderByDescending(P => P.idx).Select(c => new { 값 = c.idx, 이름 = c.department_name });

                #endregion

                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#department_idx').empty(); ");

                foreach (var item in _department)
                {
                    sb.AppendFormat("$('#department_idx').append( '<option value = " + item.값 + ">" + item.이름 + "</option>'); ");
                }
                sb.AppendFormat("$('#department_idx').change(); ");
                sb.AppendFormat("</script>");

                Response.WriteAsync(sb.ToString());

            }

            return null;

        }

        public ActionResult department_set_action(department doc, string mode_type, int? idx)
        {

            string msg = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");

            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            if (doc.use_yn == "on")
            {
                doc.use_yn = "Y";
            }
            else
            {
                doc.use_yn = "N";
            }

            int department_idx = 1;

            try
            {
                department_idx = (from a in db.department select a.idx).Max() + 1;
            }
            catch
            {
            }

            if (idx == null)
            {
                #region 저장

                doc.write_date = DateTime.Now;
                doc.department_auth = "";


                db.department.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {

                if (mode_type == "D")
                {
                    #region 삭제


                    department _update =
                      (from a in db.department where a.idx == idx select a).Single();
                    _update.use_yn = "D";


                    db.SaveChanges(); // 실제로 저장 

                    msg = Util.msg.msg_del;

                    #endregion
                }
                else
                {
                    #region 수정

                    doc.write_date = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();

                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }

            return Redirect("/sys/department_set_list");
        }

        #endregion

        #region 언어등록
        // 리스트
        public async Task<IActionResult> language_list()
        {
            return View(await db.language.ToListAsync());
        }

        public async Task<IActionResult> language_set(language doc, int? idx, string sortExpression = "-idx", int page = 1)
        {

            if (idx != null)
            {
                doc = db.language.Single(x => x.idx == idx);
            }

            var query = db.language.AsNoTracking();
            var model = await PagingList.CreateAsync(query, 100, page, sortExpression, "-idx");

            ViewBag.리스트 = model;

            return View(doc);
        }


        public async Task<IActionResult> language_action(language doc, int? idx, string mode_type)
        {

            if (idx == null)
            {
                #region 저장

                db.language.Add(doc);
                await db.SaveChangesAsync();


                #endregion
            }
            else
            {
                if (mode_type == "D")
                {
                    #region 삭제

                    language doc_del = db.language.Single(x => x.idx == idx);
                    db.language.Remove(doc_del);
                    db.SaveChanges();



                    #endregion
                }
                else
                {
                    #region 수정


                    language _update =
                        (from a in db.language where a.idx == idx select a).Single();

                    _update.korea = doc.korea;
                    _update.english = doc.english;


                    await db.SaveChangesAsync();

                    #endregion
                }
            }

            return Redirect("/sys/language_set");
        }

        #endregion

        #region 사용자 관리 : 추가 ,변경, 삭제

        public ActionResult  user_set(user doc, string idx, string my, int? company_idx_q)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            string user_auth = UserData.user_get(user_id, "user_auth");
            ViewBag.company_idx = company_idx;
            #endregion


            #region 관리자 권한

            if (auth >= 8)
            {
                ViewBag.관리자 = "Y";
            }
            else { ViewBag.관리자 = "N"; }
            #endregion




            // 최고 관리자 권한 
            if (auth > 8)
            {
                //======================================================================================================================================================== 
                var Code_company =
                    db.company.Where(p => (p.useYn == "Y")).OrderBy(o => o.indexOrder).Select(
                        c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

                if (company_idx_q == null)
                {

                    company_idx_q = company_idx;

                }

                //======================================================================================================================================================== 
                var Code_department =
                    db.department.Where(p => (p.company_idx == company_idx_q && p.use_yn == "Y")).OrderBy(
                        o => o.department_name).Select(c => new { 값 = c.idx, 이름 = c.department_name });
                ViewBag.부서 = new SelectList(Code_department.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

            }


            else
            {
                //======================================================================================================================================================== 
                var Code_company =
                    db.company.Where(
                        p =>
                        (p.idx == company_idx)).
                        OrderBy(o => o.companyName).Select(c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

                //======================================================================================================================================================== 
                var Code_department =
                    db.department.Where(p => (p.company_idx == company_idx && p.use_yn == "Y")).OrderBy(
                        o => o.department_name).Select(c => new { 값 = c.idx, 이름 = c.department_name });
                ViewBag.부서 = new SelectList(Code_department.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

            }



            if (!string.IsNullOrEmpty(idx))
            {
                int _idx = Convert.ToInt32(idx);

                doc = db.user.Single(x => x.idx == _idx);
            }
            else if (my == "Y")
            {
                string _user_id = User.Identity.Name;
                doc = db.user.Single(x => x.userId == _user_id);
            }

            return View(doc);
        }


        public ActionResult user_set_list(string search_all, string order_check, string target_check, int? userClass, int page = 1)
        {
            #region 변수


            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            string user_auth = UserData.user_get(user_id, "user_auth");
            #endregion



            #region 관리자 권한

            if (auth >= 8)
            {
                ViewBag.관리자 = "Y";
            }
            else { ViewBag.관리자 = "N"; }

            // 개인 리스트 수정 삭제 권한
            if (user_auth.Contains("user_set_list"))
            {
                ViewBag.관리자 = "Y";
            }

            #endregion
            ViewBag.search_all = search_all;


            #endregion

            #region 검색 리스트


             var _list = db.user.Where(p => p.useYn != "D" && p.userClass== userClass ).OrderBy(o => o.userName).AsNoTracking();

            #region 회원 구분

            if (userClass == 1)
            {
                _list = _list.Where(p => p.userClass == 1);
            }
            else if (userClass == 2)
            {
                _list = _list.Where(p => p.userClass == 2);
            }
            else if (userClass == 3)
            {
                _list = _list.Where(p => p.userClass == 3);
            }

            #endregion


            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.userId.Contains(search_all) || p.userName.Contains(search_all) || p.userEmail.Contains(search_all) || p.userTel.Contains(search_all) || p.companyId.Contains(search_all)).OrderByDescending(p => p.writeDate);
            }
            #endregion

            #region 정렬 변수


            if (string.IsNullOrEmpty(order_check))
            {
                order_check = "asc";
            }

            if (order_check == "asc")
            {
                ViewBag.정렬 = "desc";
            }
            else
            {
                ViewBag.정렬 = "asc";
            }
            ViewBag.대상 = target_check;

            #endregion

            #region 정렬 하기

            if (!string.IsNullOrEmpty(target_check) && order_check == "desc")
            {
                if (target_check == "companyName")
                {
                    _list = _list.OrderByDescending(o => o.companyId);
                }
                if (target_check == "userId")
                {
                    _list = _list.OrderByDescending(o => o.userId);
                }
                if (target_check == "userName")
                {
                    _list = _list.OrderByDescending(o => o.userName);
                }
                if (target_check == "userTel")
                {
                    _list = _list.OrderByDescending(o => o.userTel);
                }
                if (target_check == "userEmail")
                {
                    _list = _list.OrderByDescending(o => o.userEmail);
                }
                if (target_check == "writeDate")
                {
                    _list = _list.OrderByDescending(o => o.writeDate);
                }
                if (target_check == "departmentName")
                {
                    _list = _list.OrderByDescending(o => o.departmentIdxNavigation.department_name);
                }
                if (target_check == "useYn")
                {
                    _list = _list.OrderByDescending(o => o.useYn);
                }

            }
            if (!string.IsNullOrEmpty(target_check) && order_check == "asc")
            {
                if (target_check == "companyName")
                {
                    _list = _list.OrderBy(o => o.companyIdxNavigation.companyName);
                }
                if (target_check == "userId")
                {
                    _list = _list.OrderBy(o => o.userId);
                }
                if (target_check == "userName")
                {
                    _list = _list.OrderBy(o => o.userName);
                }
                if (target_check == "departmentName")
                {
                    _list = _list.OrderBy(o => o.departmentIdxNavigation.department_name);
                }
                if (target_check == "writeDate")
                {
                    _list = _list.OrderBy(o => o.writeDate);
                }
                if (target_check == "userEmail")
                {
                    _list = _list.OrderBy(o => o.userEmail);
                }
                if (target_check == "userTel")
                {
                    _list = _list.OrderBy(o => o.userTel);
                }
                if (target_check == "useYn")
                {
                    _list = _list.OrderBy(o => o.useYn);
                }
            }

            #endregion

            var model = PagingList.Create(_list, 20, page);
            return View(model);
        }

        public ActionResult user_set_check(string doc_it)
        {


            var sb = new StringBuilder();




            int _doc2 = (from a in db.user where a.userId == doc_it && a.useYn == "Y" select a.userId).Count();




            if (_doc2 > 0)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#userId').attr('value' ,'') ; ");
                sb.AppendFormat("demo.showSwal('auto-close');");
                sb.AppendFormat("$('#user_id_check').attr('value' ,'N') ;");
              //  sb.AppendFormat("alert('이미 등록된 아이디입니다')"); ;
                sb.AppendFormat("$('#userId').css('border' ,'solid 1px red') ; ");
                sb.AppendFormat("$('#userId').focus() ; ");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }
            else
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#user_id_check').attr('value' ,'Y') ;");
               // sb.AppendFormat("alert('사용가능한 아이디입니다')"); ;
                sb.AppendFormat("$('#userId').css('border' ,'solid 1px green') ; ");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }


            return null;
        }
        public async Task<ActionResult> user_set_action(user doc, string mode_type, int? idx, int? userClass1)
        {


            string msg = "";
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion



            int new_user_index = 1;
            try
            {
                new_user_index = (from a in db.user select a.idx).Max() + 1;
            }
            catch
            {
            }


            if (doc.useYn == "on")
            {
                doc.useYn = "Y";
            }
            else
            {
                doc.useYn = "N";
            }


            if (idx == null)
            {
                #region 저장

                //if (userClass != 2) // 단체회원
                //{
                //    doc.userPassword = "0000";
                //}
                msg = "S";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.userAuth = "1";
                doc.cStartDate = DateTime.Now;
                doc.cEndDate = DateTime.Now.AddMonths(1);
                doc.month1Free = "Y"; // 무료 1개월 사용 할수 있게 
                doc.classYn = "Y";
                db.user.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                //msg = Util.msg.msg_insert;

                #endregion

                //if (doc.userClass == 3) // 과학자의 경우 
                //{
                //    #region 과학자의 방 - 게시판 자동 생성      
                //    // 공지사항 게시판  
                //    var _insert1 = new BoardMenu
                //    {
                //        title = "공지사항",
                //        BoardType_idx = 8,
                //        open_yn = "Y",
                //        userIdx = doc.idx,

                //    };
                //    //qna게시판 
                //    var _insert2 = new BoardMenu
                //    {
                //        title = "Q&A",
                //        BoardType_idx = 7,
                //        open_yn = "Y",
                //        userIdx = doc.idx,

                //    };
                //    //과학자 자료실
                //    var _insert3 = new BoardMenu
                //    {
                //        title = "과학자 자료실",
                //        BoardType_idx = 10,
                //        open_yn = "Y",
                //        userIdx = doc.idx,

                //    };




                //    db.BoardMenu.AddRange(_insert1, _insert2, _insert3);
                //    db.SaveChanges();

                //    #endregion


                //    #region 수동 업데이트 [과학자방 게시판 정보 user 테이블에 업데이트]
                //    user _update =
                //             (from a in db.user where a.idx == doc.idx && a.userClass == 3 select a).Single();

                //    _update.nBoardCate = _insert1.idx;
                //    _update.qBoardCate = _insert2.idx;
                //    _update.dBoardCate = _insert3.idx;

                //    db.SaveChanges(); // 실제로 저장  
                //    #endregion

                //}

            }
            else
            {
                int _idx = Convert.ToInt32(idx);

                if (mode_type == "D")
                {
                    #region 삭제
                    msg = "D";
                    user _update =
                   (from a in db.user where a.idx == idx select a).Single();

                    _update.editDate = DateTime.Now;
                    _update.useYn = "D";
                    db.SaveChanges(); // 실제로 저장  

                    //msg = Util.msg.msg_del;

                    #endregion
                    return Redirect("/sys/user_set_list?userClass=" + _update.userClass+"&msg=" +msg);
                }
                else
                {
                    #region 수정


                    //user _update =
                    //         (from a in db.user where a.idx == idx select a).Single();
                    //_update.userPassword = doc.userPassword;
                    //_update.userName = doc.userName;
                    //_update.userTel = doc.userTel;
                    //_update.userEmail = doc.userEmail;
                    //_update.editDate = DateTime.Now;
                    //_update.writeDate = DateTime.Now;
                    msg = "E";

                    doc.editDate = DateTime.Now;
                    doc.writeDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;
                    //idx 제외 업데이트=================================
                    db.Entry(doc).Property("idx").IsModified = false;
                    db.Entry(doc).Property("cStartDate").IsModified = false;
                    db.Entry(doc).Property("cEndDate").IsModified = false;
                    db.Entry(doc).Property("month1Free").IsModified = false;
                    db.Entry(doc).Property("userPassword").IsModified = false;
                    db.Entry(doc).Property("classYn").IsModified = false;
                    //==================================================
                    db.SaveChanges();
                    //msg = Util.msg.msg_edit;

                    #endregion
                }
            }

            return Redirect("/sys/user_set_list?userClass="+doc.userClass+"&msg="+msg);

        }

        #endregion



        #region 유저프로필 > 첨부파일 변경 
        public ActionResult del_file(int file_idx, string url)
        {


            #region 파일 상태 변경


            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();

            _update.use_yn = "N";

            db.SaveChanges(); // 수정 

            #endregion

            url = HttpUtility.UrlDecode(url);
            return Redirect(url);
        }

        //유저 프로필 변경
        public ActionResult main_file(int file_idx, string url)
        {


            #region 파일 상태 변경


            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();



            var _find = (from a in db.BoardFile where a.Md_id == _update.Md_id && a.use_yn != "N" select a).ToList();


            foreach (var item in _find)
            {
                if (item.id == file_idx)
                {
                    BoardFile _update2 = (from a in db.BoardFile where a.id == item.id select a).Single();

                    _update2.use_yn = "M";

                    db.SaveChanges(); // 수정 


                }
                else
                {
                    BoardFile _update2 = (from a in db.BoardFile where a.id == item.id select a).Single();
                    _update2.use_yn = "Y";

                    db.SaveChanges(); // 수정 

                }



            }



            #endregion


            return Redirect(url);
        }

        #endregion





        public async Task<JsonResult> ckeditor_one_fileUp(IFormFile upload)
        {


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list"];




            var uploads = Path.Combine(Models_photo, "images/vehicle-key");
            var filePath = Path.Combine(uploads, "rich-text");
            var urls = new List<string>();

            //If folder of new key is not exist, create the folder.
            if (!Directory.Exists(filePath)) Directory.CreateDirectory(filePath);



            var formFileContent =
                await FileHelpers
                    .ProcessFormFile<IFormFile>(
                        upload, ModelState, _permittedExtensions,
                        _fileSizeLimit);





            // 변수 =========================================================================================================================
            string only = DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

            var _fileName = only + Path.GetFileName(upload.FileName);     // 신규 파일 이름                    
            var _local_path = filePath + "/";            // 신규 파일 경로
            var _filePath = Path.Combine(_local_path, _fileName);            // 전체 경로


            using (var fileStream = System.IO.File.Create(_filePath))
            {
                await fileStream.WriteAsync(formFileContent);

            }

            string _url = $"http://contactsci.theblueeye.com/searchFile/images/vehicle-key/rich-text/{_fileName}";

            //  return Json(urls);
            return Json(new { uploaded = "true", url = _url });
        }

        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
        private async Task fileUpload(List<IFormFile> files, string user_id, string file_id)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }
        }
        public void History_write(string user_id, string _page, string _state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }


    }
}