﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using static SmartFactory.Controllers.SysController;
using SmartFactory.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ReflectionIT.Mvc.Paging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using SmartFactory.Util;
using LazZiya.ImageResize;

namespace SmartFactory.Controllers
{
    public class BoardController : Controller
    {
        private readonly db_e db = new db_e();
        private string Comname = "blueeye";
        // GET: Board

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public BoardController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        public async Task<IActionResult> BoardAdmin(int? cate, int? typeIdx, int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            ViewBag.company_idx = company_idx;
            #endregion

            #region 변수설정
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;
            ViewBag.카테고리 = cate.ToString();
            ViewBag.통합구분 = typeIdx.ToString();
            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }

            //게시판 종류 드롭다운==============================================================================================================================================          
            var category =
                db.classInfo.Where(a => a.useYn == "Y").Select(a => new { 값 = a.idx, 이름 = a.className });
            ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
            //==================================================================================================================================================================

            #endregion

            //var _query = db.BoardList.Where(a => a.useable != "N").Include(p => p.BM_idxNavigation.classIdxNavigation).Include(p => p.BM_idxNavigation);
            //var query = _query.OrderByDescending(a => a.writeDate).AsNoTracking();
            //if (typeIdx == 2)
            //{
            //    query = query.Where(a => (a.BM_idxNavigation.BoardType_idx == 6 || a.BM_idxNavigation.BoardType_idx == 7 || a.BM_idxNavigation.BoardType_idx == 8) && a.BM_idxNavigation.classIdx != null);
            //}
            //else
            //{
            //    query = query.Where(a => a.BM_idxNavigation.BoardType_idx == typeIdx);
            //}
            //if (classIdx != null)
            //{
            //    query = query.Where(a => a.BM_idxNavigation.classIdx == classIdx);
            //}

            // 🚩 자료실, 사이언스몰 > 상품 qna , 사이언스몰> 리뷰 게시판 제외
            var query = db.v_class_board.Where(a => a.useable != "N" && a.BM_idx != 8 && a.BM_idx != 9 && a.BM_idx != 3).OrderByDescending(a => a.idx).AsNoTracking(); // 통합게시판


            if (cate != null)
            {
                //if (cate == 5)// 공지사항 
                //{
                //    query = query.Where(a => a.BoardType_idx == 8);
                //}
                //else if (cate == 6) // QNA
                //{
                //    query = query.Where(a => a.BoardType_idx == 7);
                //}
                //else if (cate == 7)// 후기
                //{ 
                //    query = query.Where(a => a.BoardType_idx == 6);
                //}
                if(cate != 4)
                {
                    query = query.Where(a => a.BM_idx == cate);
                }
                
            }
            else
            {
                // 관리자
                query = query.Where(a => a.BM_idx == 1 || a.BM_idx == 2 || a.BM_idx == 3);
            }


            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {

                query = query.Where(p => p.title.Contains(search_all) || p.Expr1.Contains(search_all) || p.content.Contains(search_all) || p.writer.Contains(search_all) || p.userName.Contains(search_all) || p.className.Contains(search_all) ).OrderBy(p => p.idx);

            }
            ViewBag.query_c = query.Count();
            var model = await PagingList.CreateAsync(query, 10, page, sortExpression, "-idx");

            //권한 시작==============================================================================================
            BoardAdminAuth(null, typeIdx);
            //권한 끝================================================================================================

            return View(model);

        }

        private void BoardAdminAuth(int? idx, int? typeIdx)
        {
            #region 권한

            ViewBag.권한 = "";
            ViewBag.관리자 = "";
            ViewBag.코멘트 = "N";
            ViewBag.파일 = "N";
            ViewBag.후기 = "N";

            string user_id = "";


            string board_type = (from a in db.BoardCode where a.code_id == typeIdx select a.gubun).FirstOrDefault();

            foreach (var item in board_type.Split(","))
            {
                if (item == "file")
                {
                    ViewBag.파일 = "Y";
                }
                if (item == "replay")
                {
                    ViewBag.코멘트 = "Y";
                }
                if (item == "review")
                {
                    ViewBag.후기 = "Y";                   

                }
            }

            int _auth_department = 0;
            if (User.Identity.IsAuthenticated)
            {
                //로그인 했을 경우

                user_id = User.Identity.Name;

                _auth_department = (from a in db.user where a.userId == user_id select a.checkAuth).FirstOrDefault();

                if (_auth_department >= 8)
                {
                    ViewBag.권한 = "E";
                    ViewBag.관리자 = "Y";

                }

                if (idx != null)
                {
                    string _auth_writer = (from a in db.BoardList where a.idx == idx select a.writer).FirstOrDefault() ?? "";

                    if (user_id == _auth_writer)
                    {
                        ViewBag.권한 = "E";
                    }
                }

                ViewBag.로그인 = "Y";
            }

            else
            {
                ViewBag.타입 = "normal";
                ViewBag.타이틀 = "전체";
                ViewBag.권한 = "";

                if (ViewBag.부서 == "guest")
                {
                    ViewBag.권한 = "G";
                }
            }

            #endregion
        }

        public ActionResult BoardView(int idx, int? cate, int? typeIdx)
        {         
             if (idx == 0)
            {
                //0번 게시글은 임시글로써, DB에 존재하지 않는 글임
                return NotFound();
            }

            //권한 시작==============================================================================================
            BoardAdminAuth(null, typeIdx);
            //권한 끝================================================================================================

            BoardList data = db.BoardList.Find(idx);

            #region 파일 가져오기
            //파일 가져오기=====================================================================================================================                    

            var _list = (from a in db.BoardFile where a.Md_id == data.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

            ViewBag.이미지리스트 = _list;
            ViewBag.이미지리스트카운트 = _list.Count();

            //파일 끝============================================================================================================================ 
            #endregion

            #region 조회수 증가
          
            data.hit = data.hit + 1; ;

            db.SaveChanges(); // 실제로 저장 


            #endregion

            #region 읽은 사용자 저장

            int _readCount = (from a in db.BoardRread where a.board_idx == idx && a.user_id == User.Identity.Name select a.idx).Count();

            if (_readCount == 0)
            {

                var _insert = new BoardRread
                {
                    user_id = User.Identity.Name,
                    user_name = (from a in db.user where a.userId == User.Identity.Name select a.userName).FirstOrDefault(),
                    read_date = DateTime.Now,
                    board_idx = idx

                };

                db.BoardRread.Add(_insert);
                db.SaveChanges(); // 실제로 저장 
            }


            var _read = (from a in db.BoardRread where a.board_idx == idx  select a).ToList();

            ViewBag.읽은사람 = _read;

            #endregion

            #region 코멘트 가져오기

            IQueryable <BoardComment> _listComent = Enumerable.Empty<BoardComment>().AsQueryable();

            _listComent = db.BoardComment.Where(p => p.BD_idx == idx && p.use_yn == "Y").OrderByDescending(o => o.idx);

            ViewBag.댓글 = _listComent;
            ViewBag.댓글수 = _listComent.Count();
              #endregion

            return View(data);
        }        

        public ActionResult BoardWrite(BoardList doc,int? idx, int? cate, int? typeIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.company_idx = company_idx;
            ViewBag.카테고리 = cate.ToString();

            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }
            if (typeIdx != null)
            {
                var _typeIdx = (from a in db.BoardMenu where a.BoardType_idx == typeIdx select a).FirstOrDefault();
                ViewBag.타입 = _typeIdx.BoardType_idx;
                ViewBag.타이틀 = _typeIdx.title;

            
              if (typeIdx == 1)
                {
                    var board = db.BoardMenu.Where(p => p.BoardType_idx == typeIdx && p.open_yn != "N").Select(c => new { 값 = c.idx, 이름 = c.title });
                    ViewBag.구분 = new SelectList(board.AsEnumerable(), "값", "이름");
                }
                else
                {
                    var notice =
                  db.classInfo.Where(p => p.useYn == "Y").OrderByDescending(o => o.writeDate)
                  .Select(c => new { 값 = c.idx, 이름 = c.className + "(" + c.startDate.ToString("yyyy-MM-dd") + "~" + c.endDate.ToString("yyyy-MM-dd") + ")" });
                    ViewBag.완료클래스 = new SelectList(notice.AsEnumerable(), "값", "이름");
                }


                //if (typeIdx == 6)
                //{
                //    var review =
                //   db.classInfo.Where(p => p.useYn != "N" && p.endDate > DateTime.Now).OrderByDescending(o => o.writeDate)
                //   .Select(c => new { 값 = c.rBoardCate, 이름 = c.className + "(" + c.startDate.ToString("yyyy-MM-dd") + "~" + c.endDate.ToString("yyyy-MM-dd") + ")" });
                //    ViewBag.완료클래스 = new SelectList(review.AsEnumerable(), "값", "이름");
                //}
                //else if (typeIdx == 7)
                //{
                //    var qna =
                //db.classInfo.Where(p => p.useYn != "N").OrderByDescending(o => o.writeDate)
                //.Select(c => new { 값 = c.qBoardCate, 이름 = c.className + "(" + c.startDate.ToString("yyyy-MM-dd") + "~" + c.endDate.ToString("yyyy-MM-dd") + ")" });
                //    ViewBag.완료클래스 = new SelectList(qna.AsEnumerable(), "값", "이름");
                //}
                //else if (typeIdx == 8)
                //{
                //    var notice =
                //   db.classInfo.Where(p => p.useYn != "N").OrderByDescending(o => o.writeDate)
                //   .Select(c => new { 값 = c.nBoardCate, 이름 = c.className + "(" + c.startDate.ToString("yyyy-MM-dd") + "~" + c.endDate.ToString("yyyy-MM-dd") + ")" });
                //    ViewBag.완료클래스 = new SelectList(notice.AsEnumerable(), "값", "이름");
                //}else  (typeIdx == 1)
                //{
                //    var board = db.BoardMenu.Where(p => p.BoardType_idx == typeIdx && p.open_yn !="N").Select(c => new { 값 = c.idx, 이름 = c.title });
                //    ViewBag.구분 = new SelectList(board.AsEnumerable(), "값", "이름");
                //}
            }

            if (idx != null)
            {
                //수정모드
                doc = db.BoardList.Find(idx);

                #region 첨부파일 가져오기
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count(); 
                #endregion

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;
            }

            BoardAdminAuth(null, typeIdx);



            return View(doc);
        }      

 
        public async Task<IActionResult> Board_action(BoardList doc , int? idx, int cate, int? typeIdx, string mode_type, List<IFormFile> files)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            string file_id = "";
            string msg = "";

            if (idx == null)
            {
                msg = "S";
                file_id =  DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                #region 저장
                doc.fileId = file_id;
                doc.useable = "Y";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                db.BoardList.Add(doc);
                db.SaveChanges(); // 실제로 저장 
              

                #endregion
            }
            else
            {
                int _idx = Convert.ToInt32(idx);

                if (mode_type == "D")
                {
                    #region 삭제

                    msg = "D";
                    BoardList _update =
                     (from a in db.BoardList where a.idx == idx select a).Single();

                    _update.useable = "N";
                    _update.delDate = DateTime.Now;
                    
                    db.SaveChanges(); // 실제로 저장 

                    #endregion
                }
                else
                {
                    #region 수정
                    msg = "E";
                    #region 파일 아이디
                    file_id = doc.fileId;

                    if (string.IsNullOrEmpty(file_id))
                    {

                        file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                        doc.fileId = file_id;
                    }
                    #endregion

                    doc.useable = "Y";
                    doc.editDate = DateTime.Now;
                    doc.writeDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;

                    //idx 제외 업데이트=================================
                    db.Entry(doc).Property("idx").IsModified = false;
                    //==================================================
                    db.SaveChanges();

                  

                    #endregion
                }
            }

            #region 파일 올리기

           
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id+ DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName); 
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            //===============================================================================
            UserData history = new UserData();
            history.History_write(User.Identity.Name, "/board/boardwrite/cate=" + cate, msg);
            //==============================================================================

            string returnUrl = "/board/boardAdmin?typeIdx=" + typeIdx + "&cate=" + cate + "&msg="+msg;

            return Redirect(returnUrl);

        }

        [HttpPost]
        public async Task<IActionResult> BoardImageUpload(string CKEditorFuncNum, IFormFile upload)
        {

            #region 파일 올리기

            string user_id = User.Identity.Name;
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");




            var formFileContent =
                await FileHelpers
                    .ProcessFormFile<IFormFile>(
                        upload, ModelState, _permittedExtensions,
                        _fileSizeLimit);



            // 변수 =========================================================================================================================
            string only = DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                           
            var _fileName = only + Path.GetFileName(upload.FileName);     // 신규 파일 이름                    
            var _local_path = _targetFilePath + company_id + "/";            // 신규 파일 경로
            var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로

            string ImagePath = Models_photo + company_id + "/" + _fileName;
          

          

            //경로에 폴더가 없으면 만들어준다.=============================================
            var dInfo = new DirectoryInfo(_local_path);

            if (!dInfo.Exists)
            {
                dInfo.Create();
            }

            //=================================================================================



            using (var fileStream = System.IO.File.Create(filePath))
            {
                await fileStream.WriteAsync(formFileContent);

            }

          

            var sb = new StringBuilder();
            sb.AppendFormat("<script>");
            sb.AppendFormat("window.parent.CKEDITOR.tools.callFunction('" + CKEditorFuncNum +   "', '" + ImagePath +  "', 'OK'); ");
            sb.AppendFormat("history.go(-1)");
            sb.AppendFormat("</script>");
            await  Response.WriteAsync(sb.ToString());


            #endregion

            return null;

         }

        public ActionResult BoardComment_action(BoardComment doc, string BD_idx, string cate, string mode_type, int? c_idx , int? productIdx)
        {
            int idx = 0;

            string msg = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            if (c_idx == null)
            {
                #region 저장

                doc.write_date = DateTime.Now;
                doc.writer = User.Identity.Name;
                doc.edit_date = DateTime.Now;
                doc.use_yn = "Y";
                db.BoardComment.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {

                if (mode_type == "D")
                {
                    #region 삭제

                    BoardComment doc_del = db.BoardComment.Single(x => x.idx == c_idx);
                    db.BoardComment.Remove(doc_del);
                    db.SaveChanges();

                    msg = Util.msg.msg_del;

                    #endregion
                }

                else if (mode_type == "E")
                {
                    #region 임시 삭제 / 상태 변환 업데이트

                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == c_idx select a).Single();
                    _update.edit_date = DateTime.Now;
                    _update.use_yn = "D";
                    _update.writer = User.Identity.Name;

                    db.SaveChanges(); // 실제로 저장 


                    msg = Util.msg.msg_disable;

                    #endregion
                }
                else
                {
                    #region 수정


                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == idx select a).Single();

                    _update.edit_date = DateTime.Now;
                    _update.memo = doc.memo;


                    db.SaveChanges(); // 실제로 저장 



                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }
            string url = "/mall/boardview?idx=" + BD_idx + "&cate=" + cate+"&productIdx=" + productIdx;

            return Redirect(url);

        }


        public ActionResult del_set_check(BoardList doc, int file_idx)
        {

            BoardList _updateContent =
                    (from a in db.BoardList where a.idx == doc.idx select a).Single();

            _updateContent.title = doc.title;
            _updateContent.content = doc.content;
            _updateContent.editDate = DateTime.Now;         

            db.SaveChanges(); // 실제로 저장 

            #region 삭제

            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();
            _update.use_yn = "N";           

            db.SaveChanges(); // 실제로 저장 

            #endregion                       

            return Redirect("/board/BoardWrite?cate="+doc.BM_idx+"&idx="+ doc.idx);
        }

     
        public IActionResult GetDownload(string link, string file_name)
        {
            var net = new System.Net.WebClient();
            var data = net.DownloadData(link);
            var content = new System.IO.MemoryStream(data);
            var contentType = "application/force-download";
           
            return File(content, contentType, file_name);
        }

        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }



        [Authorize]
        public ActionResult board_set(BoardMenu doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            #region Select Box
            //======================================================================================================================================================== 
            var Code_company =
                db.company.Where(p => p.useYn != "N" && p.idx == company_idx).OrderBy(o => o.indexOrder).Select(
                    c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
            //========================================================================================================================================================           

            //========================================================================================================================================================
            var _department = db.department.Where(p => p.company_idx == company_idx && p.use_yn != "N").OrderBy(P => P.index_order).Select(c => new { 값 = c.idx, 이름 = c.department_name });
            ViewBag.부서 = new SelectList(_department.AsEnumerable(), "값", "이름");
            //========================================================================================================================================================

            //========================================================================================================================================================
            var BoardCode = db.BoardCode.Where(p => p.use_yn != "N").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.게시판코드 = new SelectList(BoardCode.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 
            #endregion

            if (idx != null)
            {
              
                doc = db.BoardMenu.Single(x => x.idx == idx);
            }

            return View(doc);
        }

        [Authorize]
        public async Task<ActionResult> board_set_listAsync(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {          

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            IQueryable<BoardMenu> _list = Enumerable.Empty<BoardMenu>().AsQueryable();

            _list = db.BoardMenu.Where(p => p.open_yn =="Y").OrderBy(o => o.idx);
            
            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.title.Contains(search_all) || p.BoardType_idxNavigation.code_name.Contains(search_all) || p.open_yn != "N").OrderBy(p => p.title);

            }
            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");
            return View(model);
        }

        public ActionResult board_set_action(BoardMenu doc, int? idx, string mode_type)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            string msg = "";        

            if (doc.open_yn == "on")
            {
                doc.open_yn = "Y";
            }
            else
            {
                doc.open_yn = "N";
            }

            if (idx == null)
            {
                #region 저장

              

                db.BoardMenu.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {              

                if (mode_type == "D")
                {
                    #region 삭제

                 

                    BoardMenu _update =
                      (from a in db.BoardMenu where a.idx == idx select a).Single();
                    _update.open_yn = "N";
                  

                    db.SaveChanges(); // 실제로 저장 



                    #endregion
                }
                else
                {
                    #region 수정

                   
                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();

                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }

            return Redirect("/board/board_set_list");
         
        }



        public IActionResult mainYn_action(string arr, string state, string cate, string page)
        {
            var sb = new StringBuilder();

            var _list = db.BoardList.Where(p => p.useable != "N").OrderByDescending(a => a.idx).ToList();
            int pageSkip = 0;
            
            if (cate != null) // 클래스qna, 클래스 후기
            {
                 _list = _list.Where(p => p.BM_idx == Convert.ToInt32(cate)).ToList();              
            }
            else // 관리자(:커뮤니티)
            {
                _list = _list.Where(p =>( p.BM_idx == 1 || p.BM_idx == 2 || p.BM_idx == 3)).ToList();
            }

            if (page != null)
            {
                int pageNum = Convert.ToInt32(page);
                pageSkip = (pageNum * 10) -10;
                _list = _list.Skip(pageSkip).Take(10).ToList();
                _list = _list.Where(p => p.mainYn == "Y" || p.commuYn == "Y").Take(10).ToList();
            }
            else
            {
                _list = _list.Where(p => p.mainYn == "Y" || p.commuYn == "Y").Take(10).ToList();
            }

            if (_list.Count() > 0)
            {      
                foreach (var item in _list)
                {
                    var item_idx = item.idx;
                    BoardList _update0 = (from a in db.BoardList where a.idx == item_idx select a).FirstOrDefault();

                    _update0.mainYn = " ";  // 이전 선택 체크 -> 체크 해제 
                    _update0.commuYn = " ";

                    db.SaveChanges();  
                }
            }

            if (arr != null) // 메인선택여부 있을때 
            {
                foreach (var item in arr.Split(","))
                {
                    int idx = Convert.ToInt32(item);
                    #region 수동 업데이트
                    BoardList _update1 = (from a in db.BoardList where a.idx == idx select a).FirstOrDefault();

                    _update1.mainYn = state;
                    _update1.commuYn = state;

                    db.SaveChanges(); // 실제로 저장  
                    #endregion
                }

            }



            sb.AppendFormat("<script>");
            sb.AppendFormat("location.href='/board/BoardAdmin?cate='"+ cate +"';");
            sb.AppendFormat("</script>");


            Response.WriteAsync(sb.ToString());
            return null;

        }




    }
}