﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SmartFactory.Models;
using static SmartFactory.Controllers.SysController;

namespace SmartFactory.Controllers
{
    public class AccountController : Controller
    {
        public class MyLoginModel
        {

            [StringLength(50)]
            public string userName { get; set; }

            [StringLength(50)]
            public string password { get; set; }

            //나중에 필요
            public bool RememberMe { get; set; }

        }
        

     
        private readonly db_e db = new db_e();

        public IActionResult Login()
        {
            string user_id_check2 = "";
            string smartfactory_btn_company = "0";
            //var httpRequestFeature = Request.Url.Host;
            //ViewBag.urlcheck = httpRequestFeature;
            try
            {
                user_id_check2 = Request.Cookies["smartfactory_btn_userid"];
                smartfactory_btn_company = Request.Cookies["smartfactory_btn_company"];

            }
            catch { }
            ViewBag.user_id_check = user_id_check2;
            ViewBag.company_idx = smartfactory_btn_company;
            return View();
        }

        [HttpPost]
        public IActionResult Login(MyLoginModel model, string ReturnUrl)
        {
            var sb = new StringBuilder();
            if (ModelState.IsValid)
            {

                #region 아이디 정보가 없을 경우
                if (!string.IsNullOrEmpty(model.userName) && string.IsNullOrEmpty(model.password))
                {
                    ModelState.AddModelError("", "사용자 이름 또는 암호가 잘못되었습니다.");
                    sb.AppendFormat("<head>");
                    sb.AppendFormat("<meta http-equiv='Content-Type' content='text/html; charset = utf-8'>");
                    sb.AppendFormat("</head>");
                    sb.AppendFormat("<script src = '/Content/assets/js/jquery.min.js' ></script >");
                    sb.AppendFormat("<script>");
                    sb.AppendFormat("alert('사용자 이름 또는 암호가 잘못되었습니다.');");
                    sb.AppendFormat("location.href='/account/login';");
                    sb.AppendFormat("</script>");
                    Response.WriteAsync(sb.ToString());
                }
                #endregion

                #region 데이터베이스 테이블에서 로그인 정보 확인

                ClaimsIdentity identity = null;
                bool isAuthenticated = false;

                int user_check = (from a in db.user where a.userId == model.userName && a.userPassword == model.password && a.useYn == "Y" select a).Count();

                if (user_check == 1)
                {
                    var _user_info = (from a in db.user where a.userId == model.userName && a.userPassword == model.password && a.useYn == "Y" select a).Single();
                   
                        //Create the identity for the user
                        identity = new ClaimsIdentity(new[] {
                    new Claim(ClaimTypes.Name, model.userName),
                    new Claim(ClaimTypes.Role, _user_info.checkAuth.ToString())
                }, CookieAuthenticationDefaults.AuthenticationScheme);

                        isAuthenticated = true;

                        #region 로그인 확인
                        if (isAuthenticated)
                        {

                            var principal = new ClaimsPrincipal(identity);
                            var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);


                            #region 쿠키저장
                            //쿠키저장
                            try
                            {


                                CookieOptions cookieOptions = new CookieOptions();
                                cookieOptions.Expires = DateTime.Now.AddYears(1);
                                cookieOptions.Domain = "btn.theblueeye.com";
                                cookieOptions.Path = "/users/";

                                HttpContext.Response.Cookies.Append("smartfactory_btn_userid", model.userName);
                                HttpContext.Response.Cookies.Append("smartfactory_btn_company", _user_info.companyIdx.ToString());
                            }
                            catch
                            {

                            }
                            #endregion

                            History_write(model.userName, "/home/index", "로그인");

                            if (Url.IsLocalUrl(ReturnUrl))
                            {
                                // 원하는 경로가 있을 경우
                                return Redirect(ReturnUrl);
                            }
                            else
                            {
                                // 기본 경로
                                return RedirectToAction("Index", "Home");
                            }



                        }
                        #endregion

                

                }
                else
                {

                    ModelState.AddModelError("", "사용자 이름 또는 암호가 잘못되었습니다.");
                    sb.AppendFormat("<head>");
                    sb.AppendFormat("<meta http-equiv='Content-Type' content='text/html; charset = utf-8'>");
                    sb.AppendFormat("</head>");
                    sb.AppendFormat("<script src = '/Content/assets/js/jquery.min.js' ></script >");
                    sb.AppendFormat("<script>");
                    sb.AppendFormat("alert('사용자 이름 또는 암호가 잘못되었습니다.');");
                    sb.AppendFormat("location.href='/account/login';");
                    sb.AppendFormat("</script>");
                    Response.WriteAsync(sb.ToString());
                }


                
                #endregion



            }
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);


            History_write(User.Identity.Name, "/home/index", "로그아웃");

            return RedirectToAction("Login");
        }

        #region 회원가입
        public ActionResult Register(user doc, string idx, string my, int? company_idx)
        {
            //======================================================================================================================================================== 
            var Code_company =
                db.company.Where(p => (p.useYn == "Y")).OrderBy(o => o.indexOrder).Select(
                    c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 
            //======================================================================================================================================================== 
            var Code_department =
                db.department.Where(p => (p.company_idx == company_idx && p.use_yn == "Y")).OrderBy(
                    o => o.department_name).Select(c => new { 값 = c.idx, 이름 = c.department_name });
            ViewBag.부서 = new SelectList(Code_department.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 


            return View(doc);
        }
        public ActionResult Register_check(string doc_it)
        {

            var sb = new StringBuilder();

            int _doc2 = (from a in db.user where a.userId == doc_it select a.userId).Count();


            if (_doc2 > 0)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#user_id').attr('value' ,'') ; ");
                sb.AppendFormat("demo.showSwal('auto-close');");
                sb.AppendFormat("$('#user_id_check').attr('value' ,'N') ;");
                sb.AppendFormat("$('#user_id').css('border' ,'solid 1px red') ; ");
                sb.AppendFormat("$('#user_id').focus() ; ");
                sb.AppendFormat("demo.showSwal('alert','0','사용 불가한 아이디입니다.');");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }
            else
            {
                sb.AppendFormat("<script>");

                sb.AppendFormat("$('#user_id_check').attr('value' ,'Y') ;");
                sb.AppendFormat("$('#user_id').css('border' ,'solid 1px green') ; ");
                sb.AppendFormat("demo.showSwal('alert','0','사용 가능한 아이디입니다.');");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }

            return null;
        }

        public void History_write(string user_id, string _page, string _state)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = department_name,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }

        public ActionResult Register_action(user doc, string mode_type, string idx)
        {

            string msg = "";

            int new_user_index = 1;
            try
            {
                new_user_index = (from a in db.user select a.idx).Max() + 1;
            }
            catch
            {
            }

            if (string.IsNullOrEmpty(idx))
            {
                #region 저장

                doc.useYn = "Y";
                doc.checkAuth = 1;
                doc.userAuth = "1";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                db.user.Add(doc);
                db.SaveChanges(); // 실제로 저장 

                msg = Util.msg.msg_insert;

                #endregion
            }

            string _msg = doc.userName + "회원가입되었습니다. 관리자의 승인이 필요합니다.";


            //sms_send(_msg);


            return Redirect("/account/login");

        }
        #endregion
        public void sms_send(string _msg)
        {


            // POST, GET 보낼 데이터 입력
            string strUri = "http://sms.nanuminet.com/utf8.php";
            StringBuilder dataParams = new StringBuilder();
            string _now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            dataParams.Append("sms_id=leeyw94&");
            dataParams.Append("sms_pw=blueeye0037!&");
            dataParams.Append("callback=070-8244-8202&");
            dataParams.Append("senddate=" + _now + "&");
            dataParams.Append("return_url=http://desco.theblueeye.com/sys/sms_end&");
            dataParams.Append("return_data=&");
            dataParams.Append("use_mms=N&");
            dataParams.Append("upFile=&");
            dataParams.Append("phone[]=010-4490-0528&");
            dataParams.Append("msg[]=" + _msg + "&");




            // 요청 String -> 요청 Byte 변환
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            /* POST */

            // HttpWebRequest 객체 생성, 설정

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri);

            request.Method = "POST";    // 기본값 "GET"

            request.ContentType = "application/x-www-form-urlencoded";

            request.ContentLength = byteDataParams.Length;

            Stream stDataParams = request.GetRequestStream();

            stDataParams.Write(byteDataParams, 0, byteDataParams.Length);
            //core 추가 시작===================================
            var response = (HttpWebResponse)request.GetResponse();
            //core 추가 끝===================================
            stDataParams.Close();


        }



        #region 회사 추가 등록
        public ActionResult company_set(company doc, int? idx)
        {
            //======================================================================================================================================================== 
            var Code_nation =
                db.code_nationality.Where(p => p.use_yn == "Y").OrderBy(o => o.index_order).Select(
                    c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.국적 = new SelectList(Code_nation.AsEnumerable(), "값", "이름");

            //========================================================================================================================================================
            var code_company = db.code_company.Where(p => p.use_yn == "Y").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.회사구분 = new SelectList(code_company.AsEnumerable(), "값", "이름");

            //========================================================================================================================================================

            if (idx != null)
            {

                doc = db.company.Single(x => x.idx == idx);


            }
            else
            {

            }


            return View(doc);
        }

        public IActionResult company_set_action(company doc, string mode_type, int? idx)
        {
            var sb = new StringBuilder();
            string msg = "";
            int _id = 1;

            try
            {
                _id = (from a in db.company select a.idx).Max() + 1;
            }
            catch
            {
            }

            if (idx == null)
            {
                #region 저장

                msg = "S";
                doc.writeDate = DateTime.Now;
                doc.useYn = "Y";
                doc.indexOrder = _id;
                db.company.Add(doc);
                db.SaveChanges(); // 실제로 저장 

                //msg = Util.msg.msg_insert;

                sb.AppendFormat("<head>");
                sb.AppendFormat("<meta http-equiv='Content-Type' content='text/html; charset = utf-8'>");
                sb.AppendFormat("</head>");
                sb.AppendFormat("<script src = '/Content/assets/js/jquery.min.js' ></script >");
                sb.AppendFormat("<script>");
                sb.AppendFormat("alert('등록되었습니다');");
                sb.AppendFormat("opener.parent.window.location.href='/Account/Register?company_idx=" + _id + "';");
                sb.AppendFormat("$('#company_idx',opener.document).change( '<option value = " + _id + "></option>'); ");
                sb.AppendFormat("self.close();");
                sb.AppendFormat("</script>");

                #endregion
            }
            else
            {

            }

            Response.WriteAsync(sb.ToString());

            return View(doc);
        }
        #endregion

        #region 부서 추가 등록
        public ActionResult department_set(department doc, int? idx, string company_idx)
        {

            //======================================================================================================================================================== 
            var Code_company =
                db.company.Where(p => p.companyId == company_idx).OrderBy(
                    o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 


            if (idx != null)
            {

                doc = db.department.Where(p => p.company_idx == p.company_idx).Single(x => x.idx == idx);
            }

            return View(doc);
        }

        public ActionResult department_set_action(department doc, string mode_type, int? idx, string company_idx)
        {
            var sb = new StringBuilder();
            string msg = "";
            int department_idx = 1;

            try
            {
                department_idx = (from a in db.department select a.idx).Max() + 1;
            }
            catch
            {
            }


            if (idx == null)
            {
                #region 저장

                doc.use_yn = "Y";
                doc.write_date = DateTime.Now;
                doc.department_auth = "0,1";
                db.department.Add(doc);
                db.SaveChanges(); // 실제로 저장 

                msg = Util.msg.msg_insert;

                sb.AppendFormat("<head>");
                sb.AppendFormat("<meta http-equiv='Content-Type' content='text/html; charset = utf-8'>");
                sb.AppendFormat("</head>");
                sb.AppendFormat("<script src = '/Content/assets/js/jquery.min.js' ></script >");
                sb.AppendFormat("<script>");
                sb.AppendFormat("alert('등록되었습니다');");
                sb.AppendFormat("opener.parent.window.location.href='/Account/Register?company_idx=" + company_idx + "&department_idx=" + department_idx + "';");
                sb.AppendFormat("$('#company_idx',opener.document).change( '<option value = " + company_idx + "></option>'); ");
                sb.AppendFormat("$('#department_idx',opener.document).change( '<option value = " + department_idx + "></option>'); ");
                sb.AppendFormat("self.close();");
                sb.AppendFormat("</script>");

                #endregion
            }
            else
            {

            }

            Response.WriteAsync(sb.ToString());

            return null;
        }
        #endregion




    }
}