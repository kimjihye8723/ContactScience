﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ReflectionIT.Mvc.Paging;
using SmartFactory.Models;
using Microsoft.Extensions.Configuration;
using System.IO;
using LazZiya.ImageResize;
using SmartFactory.Util;

namespace SmartFactory.Controllers
{
    public class codeController : Controller
    {
        private readonly db_e db = new db_e();

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public codeController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        #region Nationality

        [Authorize]
        public ActionResult code_nationality(code_nationality doc, string idx)
        {
            if (!string.IsNullOrEmpty(idx))
            {
                
                doc = db.code_nationality.Single(x => x.code_id == idx);
            }

            return View(doc);
        }

        public ActionResult code_nationality_check( string doc_it)
        {         

            var sb = new StringBuilder();

            int _doc = (from a in db.code_nationality where a.code_id == doc_it select a.code_id).Count();
            sb.AppendFormat("<script>");
            if (_doc > 0)
            {
                
                sb.AppendFormat("$('#code_id').attr('value' ,'');");
                sb.AppendFormat("$('#code_id_check').attr('value' ,'N');");
                sb.AppendFormat("alert('중복된 코드입니다.');");
                sb.AppendFormat("$('#code_id').css('border' ,'solid 1px red');");
                sb.AppendFormat("$('#code_id').focus();");
                

            }
            else
            {

                sb.AppendFormat("$('#code_id_check').attr('value' ,'Y') ;");
                sb.AppendFormat("alert('사용 가능합니다.');");
                sb.AppendFormat("$('#code_id').css('border' ,'solid 1px green'); ");                

                
            }
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
        }
             
        public ActionResult code_nationality_action(code_nationality doc , string mode_type, string idx)
        {
         
            string msg = "";

            if (string.IsNullOrEmpty(idx))
            {
                #region 저장

                doc.write_date = DateTime.Now;
                doc.writer_id = User.Identity.Name;
                doc.index_order = 9;
                doc.use_yn = "Y";
                db.code_nationality.Add(doc);
                db.SaveChanges(); // 실제로 저장 

                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {          

                if (mode_type == "D")
                {
                    #region 삭제

                    code_nationality doc_del = db.code_nationality.Single(x => x.code_id == idx);
                    db.code_nationality.Remove(doc_del);
                    db.SaveChanges();

                    msg = Util.msg.msg_del;

                    #endregion
                }
                else
                {
                    #region 수정

                    doc.writer_id = User.Identity.Name;
                    doc.write_date = DateTime.Now;
                    doc.index_order = 9;
                    doc.use_yn = "Y";
                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();

                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }

            return Redirect("/code/code_nationality_list");
            
        }
      
        public ActionResult code_nationality_list()
        {
            IOrderedQueryable<code_nationality> _list = db.code_nationality.OrderBy(o => o.code_name);
            return View(_list.ToList());
        }

        #endregion






        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
    }
}