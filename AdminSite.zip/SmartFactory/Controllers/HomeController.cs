﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SmartFactory.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Authorization;
using System.Text;
using System.IO;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using static SmartFactory.Controllers.SysController;

namespace SmartFactory.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly db_e db = new db_e();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        
        public ActionResult Index(string projectmain)
        {

            #region 기본 사용자 정보           

            if (User.Identity.IsAuthenticated == false)
            {
                return Redirect("/Account/Login");
            }
            else
            {
                string user_id = User.Identity.Name;
                string user_name = UserData.user_get(user_id, "user_name");
                int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
                string company_name = UserData.user_get(user_id, "company_name");
                int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
                string department_name = UserData.user_get(user_id, "department_name");
                string position_name = UserData.user_get(user_id, "position_name");
                int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));

                //for left menu user--photo
                string web_user_id = User.Identity.Name ?? "";
                var user_list = (from a in db.user where a.userId == web_user_id select a).FirstOrDefault();
                string user_auth = user_list.userAuth;
                string photo = (from a in db.BoardFile where a.Md_id == user_list.photoProfile && a.use_yn == "M" select a.sImagePath).FirstOrDefault();

                ViewBag.photo = photo;
                ViewBag.user_name = user_name;
                ViewBag.company_idx = company_idx;
                ViewBag.company_name = company_name;
                ViewBag.department_idx = department_idx;
                ViewBag.department_name = department_name;
                ViewBag.position_name = position_name;



            }
            #endregion

            return View();
        }

        public ActionResult excel_upload(string projectmain)
        {


            return View();
        }

         public ActionResult Index2(string projectmain)
        {            


            return View();
        }

        public ActionResult Index3(string projectmain)
        {


            return View();
        }
        public ActionResult jusoPopup(string projectmain)
        {




            return View();
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public void History_write(string user_id, string _page, string _state)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip =_ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = department_name,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }


        public ActionResult monitoring_bc()
        {


            return View();
        }

    }
}
