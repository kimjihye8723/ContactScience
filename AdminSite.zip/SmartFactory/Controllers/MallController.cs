﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SmartFactory.Models;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Headers;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using LazZiya.ImageResize;
using System.IO;
using SmartFactory.Util;
using ReflectionIT.Mvc.Paging;
using Microsoft.AspNetCore.Routing;
using System.Net;
using NPOI.OpenXmlFormats.Dml;
using static SmartFactory.Controllers.SysController;
using System.Web;

namespace SmartFactory.Controllers
{
    public class MallController : Controller
    {
        // GET: Sys
        private readonly db_e db = new db_e();

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public MallController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        /// <summary>
        /// / 로그인 정보
        // / </summary>

        #region 상품 정보 등록
        [Authorize]
        public ActionResult productSet(productInfo doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //Select Box======================================================================================================================================================
            var category = db.code_productCategory.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.카테고리 = new SelectList(category.AsEnumerable(), "값", "이름");

            var scienceCate = db.code_shopinfo.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.shopName });
            ViewBag.판매처 = new SelectList(scienceCate.AsEnumerable(), "값", "이름");

            var productState = db.code_productState.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.판매상태 = new SelectList(productState.AsEnumerable(), "값", "이름");
            //Select Box======================================================================================================================================================


            if (idx != null)
            {
                doc = db.productInfo.Single(x => x.idx == idx);
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;

            }
            int file_menu_id = 0;

            try
            {
                file_menu_id = (from a in db.file_menu where a.gubun == 2 select a.file_menu_id).FirstOrDefault();
            }
            catch
            {

            }

            var file_list = (from a in db.file_management where a.code_doc_idx == file_menu_id && a.use_yn == "Y" select a).ToList();

            ViewBag.파일리스트 = file_list;
            ViewBag.파일리스트카운트 = file_list.Count();

            return View(doc);
        }
        [Authorize]
        public async Task<ActionResult> productList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;



            var _list = db.productInfo.Where(a => a.useYn != "D").Include(p => p.categoryNavigation).Include(p => p.shopIdxNavigation).Include(p => p.optionIdxNavigation).OrderByDescending(o => o.writeDate).AsNoTracking();


            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.productName.Contains(search_all) || p.categoryNavigation.codeName.Contains(search_all) || p.optionIdxNavigation.codeName.Contains(search_all) || p.shopIdxNavigation.shopName.Contains(search_all) || p.description.Contains(search_all) || Convert.ToString(p.price).Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.writeDate);

            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");
            return View(model);
        }

        public IActionResult mainYn_action(string arr, string state, string mainYn, string page, int? idx)
        {
            var sb = new StringBuilder();

            var _list = db.productInfo.ToList();
            int pageSkip = 0;

            if (mainYn != null)
            {
                _list = _list.Where(p => p.mainYn == mainYn).ToList(); // 메인선택여부 있을때              
            }
            else
            {
                _list = _list.Where(p => (p.mainYn == "N" || p.mainYn == "B" || p.mainYn == "R")).Take(10).ToList();
            }

            if (page != null)
            {
                int pageNum = Convert.ToInt32(page);
                pageSkip = (pageNum * 10) - 10;
                _list = _list.Skip(pageSkip).Take(10).ToList();
                _list = _list.Where(p => p.mainYn == mainYn).Take(10).ToList();
            }
            else
            {
                _list = _list.Where(p => p.mainYn == mainYn).Take(10).ToList();

            }

            if (_list.Count() > 0)
            {
                foreach (var item in _list)
                {
                    var item_idx = item.idx;
                    productInfo _update0 = (from a in db.productInfo where a.idx == item_idx select a).FirstOrDefault();

                    _update0.mainYn = null;

                    db.SaveChanges();
                }
            }

            if (arr != null) // 메인선택여부 있을때 
            {
                foreach (var item in arr.Split(","))
                {
                    int idx_ = Convert.ToInt32(item);
                    #region 수동 업데이트
                    productInfo _update1 = (from a in db.productInfo where a.idx == idx_ select a).FirstOrDefault();
                    _update1.mainYn = mainYn;

                    db.SaveChanges(); // 실제로 저장  
                    #endregion
                }

            }



            sb.AppendFormat("<script>");
            sb.AppendFormat("location.href='/mall/productList?mainYn=" + mainYn + "';");
            sb.AppendFormat("</script>");


            Response.WriteAsync(sb.ToString());
            return null;

        }

        public IActionResult productView(productInfo doc, string sdate, string mode, int? idx, int? classIdx)
        {

            DateTime _sdate = DateTime.Now;


            if (!string.IsNullOrEmpty(sdate))
            {
                _sdate = Convert.ToDateTime(sdate);
            }

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            ViewBag.companyIdx = company_idx;
            ViewBag.department_idx = department_idx;


            if (idx != null)
            {

                doc = db.productInfo.Where(x => x.idx == idx).Include(p => p.categoryNavigation).Include(p => p.optionIdxNavigation).Include(p => p.shopIdxNavigation).Include(p => p.stateIdxNavigation).FirstOrDefault();


                #region 이미지

                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.user_id = user_id;
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion

                var classPlan = db.codeOption.Where(p => p.productIdx == doc.idx && p.useYn != "N").OrderByDescending(p => p.writeDate).ToList();
                ViewBag.상품옵션들 = classPlan;
                ViewBag.상품옵션들_c = classPlan.Count();

            }

            int file_menu_id = 0;

            try
            {
                file_menu_id = (from a in db.file_menu where a.gubun == 1 select a.file_menu_id).FirstOrDefault();
            }
            catch
            {

            }


            var file_list = (from a in db.file_management where a.code_doc_idx == file_menu_id select a).ToList();

            ViewBag.파일리스트 = file_list;
            ViewBag.파일리스트카우트 = file_list.Count();

            return View(doc);
        }

        public async Task<IActionResult> productAction(productInfo doc, int? idx, string? useYn, string mode_type, List<IFormFile> files, string file_count)
        {


            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";


            // 노출여부
            if (doc.useYn == "N" || doc.useYn == "")
            {
                doc.useYn = "Y";
            }
            else
            {
                doc.useYn = "N";
            }


            if (idx == null)
            {

                #region 저장
                fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                msg = "S";  // 입력

                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.fileId = fileId;
                doc.useYn = "Y";
                db.productInfo.Add(doc);
                await db.SaveChangesAsync();

                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";  // 삭제
                    #region 수동 업데이트
                    productInfo _update2 = (from a in db.productInfo where a.idx == idx select a).Single();
                    _update2.useYn = "D";
                    _update2.editDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion

                }
                else
                {

                    #region 수정
                    fileId = doc.fileId;
                    if (string.IsNullOrEmpty(fileId))
                    {
                        fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        doc.fileId = fileId;
                    }

                    msg = "E"; //수정
                    doc.editDate = DateTime.Now;
                    //doc.useYn = "Y";
                    db.Entry(doc).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    db.SaveChanges();
                    #endregion

                }
            }

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int ssss = 0;
            foreach (var formFile in files)
            {
                try
                {

                    double file_size = formFile.Length;

                    int index_order_file = Convert.ToInt32(file_count.Split(',')[ssss]); // 0,2

                    if (file_size < _fileSizeLimit && file_size > 0)
                    {

                        var formFileContent =
                            await FileHelpers
                                .ProcessFormFile<IFormFile>(
                                    formFile, ModelState, _permittedExtensions,
                                    _fileSizeLimit);




                        #region 변수
                        // 변수 =========================================================================================================================
                        string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                     

                        string file_ex = ""; // 확장자

                        try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                        catch
                        {

                        }
                        var _fileName = only + "." + file_ex;     // 신규 파일 이름  




                        var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                        var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                        string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                        string ore_fileName = Path.GetFileName(formFile.FileName);
                        #endregion





                        //경로에 폴더가 없으면 만들어준다.=============================================
                        var dInfo = new DirectoryInfo(_local_path);
                        var dInfo_s = new DirectoryInfo(desiredThumbPath);
                        if (!dInfo.Exists)
                        {
                            dInfo.Create();
                        }
                        if (!dInfo_s.Exists)
                        {
                            dInfo_s.Create();
                        }
                        //=================================================================================




                        using (var fileStream = System.IO.File.Create(filePath))
                        {
                            await fileStream.WriteAsync(formFileContent);

                        }

                        if (get_word.img_check(file_ex) == "img")
                        {
                            // 세로 기준
                            ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                        }


                        #region 기존 파일 있으면 사용안함으로 변경

                        int _check_old = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a.id).Count();

                        if (_check_old > 0)
                        {
                            BoardFile _update = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a).FirstOrDefault();

                            _update.use_yn = "N";
                            db.SaveChanges(); // 실제로 저장 
                        }

                        #endregion





                        var _insert = new BoardFile()
                        {
                            Md_id = fileId,
                            ImagePath = Models_photo + company_id + "/" + _fileName,
                            fileName = ore_fileName,
                            use_yn = "Y",
                            file_ex = file_ex,
                            file_size = file_size,
                            r_date = DateTime.Now,
                            write_id = user_id,
                            sImagePath = Models_photo + company_id + "/s/" + _fileName,
                            index_order = index_order_file
                        };

                        db.BoardFile.Add(_insert);
                        db.SaveChanges();

                    }

                }
                catch
                {

                }

                ssss++;
            }


            #endregion

            return Redirect("/mall/productList?idx=" + doc.idx + "&msg="+msg);

        }



        // 상품 옵션 
        public ActionResult planSet2(codeOption doc, int? idx, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            if (idx != null)
            {
                doc = db.codeOption.Single(x => x.idx == idx);
            }

            return View(doc);
        }

        //상품 옵션 등록  action
        public async Task<IActionResult> planAction(codeOption doc, int? idx, string mode_type, int? productIdx, string mainYn, List<IFormFile> files)
        {
            StringBuilder sb = new StringBuilder();

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";

            string file_id = "";


            if (idx == null)
            {
                //if (files.Count() > 0)
                //{
                //    file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                //    doc.fileId = file_id;
                //}

                #region 저장
                msg = "저장";
                doc.writeDate = DateTime.Now;
                doc.productIdx = productIdx;
                doc.useYn = "Y";
                //doc.mainYn = mainYn;
                db.codeOption.Add(doc);
                await db.SaveChangesAsync();
                #endregion


            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "삭제";

                    #region 수동 업데이트
                    codeOption _update2 =
                             (from a in db.codeOption where a.idx == idx select a).Single();

                    _update2.useYn = "N";
                    _update2.writeDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion
                }
                else
                {

                    #region 수정
                    msg = "수정";

                    doc.writeDate = DateTime.Now;
                    doc.useYn = "Y";

                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();
                    #endregion

                }
            }




            return Redirect("/mall/productView?idx=" + productIdx);

        }


        #endregion

        #region 판매처 등록

        public async Task<ActionResult> shopList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.code_shopinfo.Where(p => p.useYn == "Y").OrderByDescending(o => o.idx).AsNoTracking();


            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.shopName.Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.idx);
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            return View(model);
        }
        [Authorize]
        public ActionResult shopSet(code_shopinfo doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion


            if (idx != null)
            {
                doc = db.code_shopinfo.Single(x => x.idx == idx);

            }
            return View(doc);
        }

        public async Task<IActionResult> shopAction(code_shopinfo doc, int? idx, string mode_type, List<IFormFile> files, string file_count)
        {


            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";

            if (idx == null)
            {

                #region 저장
                fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                msg = "S";  // 입력
                doc.useYn = "Y";
                db.code_shopinfo.Add(doc);
                await db.SaveChangesAsync();

                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";  // 삭제
                    #region 수동 업데이트
                    code_shopinfo _update2 = (from a in db.code_shopinfo where a.idx == idx select a).Single();
                    _update2.useYn = "N";
                    db.SaveChanges();
                    #endregion

                }
                else
                {

                    #region 수정   
                    msg = "E"; //수정
                    doc.useYn = "Y";
                    db.Entry(doc).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    db.SaveChanges();
                    #endregion

                }
            }

            return Redirect("/mall/shopList?idx=" + idx + "&msg="+msg);

        }

        #endregion

        #region 결제내역

        public async Task<ActionResult> mallPayList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.payment_payapp.Where(p => p.var1 == "4").OrderByDescending(a => a.pay_date).AsNoTracking();  // 사이언스몰 결제만 
            ViewBag.리스트카운트 = _list.Count();

            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.writer.Contains(search_all) || p.card_name.Contains(search_all) || p.var2.Contains(search_all) || Convert.ToString(p.price).Contains(search_all)).OrderByDescending(p => p.pay_date);
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");
            return View(model);
        }

        #endregion

        #region 배송내역 

        public async Task<ActionResult> ShippingList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.deliverInfo.Where(p => p.useYn != "N").Include(a => a.orderIdxNavigation).Include(a => a.orderIdxNavigation.userIdxNavigation).OrderByDescending(o => o.writeDate).AsNoTracking();
            ViewBag.배송내역 = _list;

            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.userName.Contains(search_all) || p.userTel.Contains(search_all) || p.userAddr.Contains(search_all) || p.deliveryName.Contains(search_all) || p.deliverNum.Contains(search_all)).OrderByDescending(p => p.writeDate);
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            return View(model);
        }
        [Authorize]
        public ActionResult ShippingSet(deliverInfo doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //Select Box======================================================================================================================================================

            var productState = db.orderProduct.Where(p => p.useYn == "Y").OrderBy(P => P.idx).Select(c => new { 값 = c.idx, 이름 = c.orderCode });
            ViewBag.주문번호 = new SelectList(productState.AsEnumerable(), "값", "이름");

            //Select Box======================================================================================================================================================


            if (idx != null)
            {
                doc = db.deliverInfo.Single(x => x.idx == idx);
                ViewBag.배송상태 = doc.state;
            }
            return View(doc);
        }

        public async Task<IActionResult> ShippingAction(deliverInfo doc, int? idx, string mode_type, List<IFormFile> files, string file_count)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";

            if (idx == null)
            {

                #region 저장
                msg = "S";  // 입력
                doc.useYn = "Y";
                doc.writeDate = DateTime.Now;
                db.deliverInfo.Add(doc);
                await db.SaveChangesAsync();

                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";  // 삭제
                    #region 수동 업데이트
                    deliverInfo _update2 = (from a in db.deliverInfo where a.idx == idx select a).Single();
                    _update2.useYn = "N";
                    doc.writeDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion

                }
                else
                {

                    #region 수정   
                    msg = "E"; //수정
                    doc.useYn = "Y";
                    doc.writeDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    db.SaveChanges();
                    #endregion

                }
            }

            return Redirect("/mall/shippingList?idx=" + idx +"&msg="+msg);

        }


        #endregion

        #region 교환내역 

        public async Task<ActionResult> ReclaimList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.productReclaim.Where(p => p.useYn == "Y").Include(a => a.orderIdxNavigation.userIdxNavigation).Include(a => a.userIdxNavigation).OrderByDescending(o => o.writeDate).AsNoTracking();
            ViewBag.배송내역 = _list;

            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.orderIdxNavigation.userIdxNavigation.userName.Contains(search_all) || p.orderIdxNavigation.orderCode.Contains(search_all) || p.userTel.Contains(search_all) || p.userAddr.Contains(search_all) || p.deliverNum1.Contains(search_all) || p.deliverNum2.Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.writeDate);
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            return View(model);
        }
        [Authorize]
        public ActionResult ReclaimSet(productReclaim doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //Select Box======================================================================================================================================================

            var productState = db.orderProduct.Where(p => p.useYn == "Y").OrderBy(P => P.idx).Select(c => new { 값 = c.idx, 이름 = c.orderCode });
            ViewBag.주문번호 = new SelectList(productState.AsEnumerable(), "값", "이름");

            //Select Box======================================================================================================================================================


            if (idx != null)
            {
                doc = db.productReclaim.Where(x => x.idx == idx).FirstOrDefault();
                ViewBag.배송상태 = doc.state;
            }
            return View(doc);
        }

        public async Task<IActionResult> ReclaimAction(productReclaim doc, int? idx, string mode_type, List<IFormFile> files, string file_count)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";



            if (idx == null)
            {
                #region 저장
                msg = "S";  // 입력
                doc.useYn = "Y";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                db.productReclaim.Add(doc);
                await db.SaveChangesAsync();
                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";  // 삭제
                    #region 수동 업데이트
                    productReclaim _update2 = (from a in db.productReclaim where a.idx == idx select a).Single();
                    _update2.useYn = "N";
                    _update2.editDate = DateTime.Now;
                    _update2.delDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion

                }
                else
                {

                    #region 수정   
                    msg = "E"; //수정
                    doc.useYn = "Y";
                    doc.writeDate = DateTime.Now;
                    doc.editDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;
                    db.Entry(doc).Property("idx").IsModified = false;
                    db.SaveChanges();
                    #endregion

                }
            }

            return Redirect("/mall/reclaimList?idx=" + idx+"&msg=" + msg
);

        }

        #endregion

        #region 반품내역 

        public async Task<ActionResult> RefundList(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.productRefund.Where(p => p.useYn == "Y").Include(a => a.orderIdxNavigation).Include(a => a.orderIdxNavigation.userIdxNavigation).OrderByDescending(o => o.writeDate).AsNoTracking();


            // 검색 관련 
            if (!string.IsNullOrEmpty(search_all))
            {
                _list = _list.Where(p => p.orderIdxNavigation.userIdxNavigation.userId.Contains(search_all) || p.orderIdxNavigation.orderCode.Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.writeDate);
            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            return View(model);
        }
        [Authorize]
        public ActionResult RefundSet(productRefund doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //Select Box======================================================================================================================================================

            var productState = db.orderProduct.Where(p => p.useYn == "Y").OrderBy(P => P.idx).Select(c => new { 값 = c.idx, 이름 = c.orderCode });
            ViewBag.주문번호 = new SelectList(productState.AsEnumerable(), "값", "이름");

            //Select Box======================================================================================================================================================


            if (idx != null)
            {
                doc = db.productRefund.Where(x => x.idx == idx).FirstOrDefault();
                ViewBag.환불상태 = doc.state;
            }

            return View(doc);
        }

        public async Task<IActionResult> refundAction(productRefund doc, int? idx, string mode_type, List<IFormFile> files, string file_count)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";

            if (idx == null)
            {

                #region 저장
                msg = "S";  // 입력
                doc.useYn = "Y";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                db.productRefund.Add(doc);
                await db.SaveChangesAsync();

                #endregion

            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "D";  // 삭제
                    #region 수동 업데이트
                    productReclaim _update2 = (from a in db.productReclaim where a.idx == idx select a).Single();
                    _update2.useYn = "N";
                    _update2.writeDate = doc.writeDate;
                    _update2.editDate = DateTime.Now;
                    _update2.delDate = DateTime.Now;
                    //_update2.completeDate = doc.completeDate;
                    //_update2.startDate = doc.startDate;
                    //_update2.endDate = doc.endDate;
                    db.SaveChanges();
                    #endregion

                }
                else
                {

                    #region 수정   
                    msg = "E"; //수정
                    doc.useYn = "Y";
                    doc.writeDate = DateTime.Now;
                    doc.editDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    db.SaveChanges();
                    #endregion

                }
            }

            return Redirect("/mall/RefundList?idx=" + idx + "&msg=" + msg);

        }

        #endregion


        public ActionResult orderN_check(int doc_it)
        {
            var sb = new StringBuilder();

            string userName = "";
            string userId = "";
            string userTel = "";
            string userAdd = "";
            int userIdx = 0;

            int optionIdx = 0;
            string itemOption = "";
            int itemPrice = 0;



            var _list = (from a in db.orderProduct where a.idx == doc_it select a).Include(a => a.userIdxNavigation).Include(a => a.deliveryIdxNavigation).FirstOrDefault();



            if (_list == null)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("demo.showSwal('alert','0','등록된 주문이 없습니다.');");
                sb.AppendFormat("</script>");
            }
            else
            {
                userName = _list.userIdxNavigation.userName;
                userId = _list.userIdxNavigation.userId;
                userTel = _list.userIdxNavigation.userTel;
                userAdd = _list.deliveryIdxNavigation.userAddr ?? null;
                userIdx = _list.userIdx ?? 0;

                optionIdx = _list.idx;
                itemOption = _list.cartInfo;
                itemPrice = _list.price;

                sb.AppendFormat("<script>");

                sb.AppendFormat("$('#userName').attr('value' ,'" + userName + "') ;");
                sb.AppendFormat("$('#userId').attr('value' ,'" + userId + "') ;");
                sb.AppendFormat("$('#userTel').attr('value' ,'" + userTel + "') ;");
                sb.AppendFormat("$('#userIdx').attr('value' ,'" + userIdx + "') ;");
                sb.AppendFormat("$('#optionIdx').attr('value' ,'" + optionIdx + "') ;");
                sb.AppendFormat("$('#optionInfo').attr('value' ,'" + itemOption + "') ;");
                sb.AppendFormat("$('#price').attr('value' ,'" + itemPrice + "') ;");
                sb.AppendFormat("$('#userAddr').attr('value' ,'" + userAdd + "') ;");
                sb.AppendFormat("$('#userIdx').attr('value' ,'" + userIdx + "') ;");
                // sb.AppendFormat("$('#userAddr').focus() ; ");
                sb.AppendFormat("</script>");

            }




            Response.WriteAsync(sb.ToString());


            return null;
        }








        [Authorize]
        public async Task<ActionResult> applyLIst(int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.orderClassDetail.Where(p => p.useYn != "N" && p.state == "Y" && p.classIdx == classIdx).Include(p => p.userIdxNavigation).OrderByDescending(p => p.writeDate).AsNoTracking();

            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.userIdxNavigation.userName.Contains(search_all) || p.userIdxNavigation.userTel.Contains(search_all) || p.userIdxNavigation.userEmail.Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.writeDate);

            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            ViewBag.신청목록_c = _list.Count();
            return View(model);
        }

        [Authorize]
        public async Task<ActionResult> surveyList(int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;

            var _list = db.classSurvey.Where(p => p.classIdx == classIdx && p.useYn != "N").Include(p => p.userIdxNavigation).OrderByDescending(p => p.writeDate).AsNoTracking();

            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.userIdxNavigation.userName.Contains(search_all) || p.userIdxNavigation.userTel.Contains(search_all) || p.userIdxNavigation.userEmail.Contains(search_all) && p.useYn != "N").OrderByDescending(p => p.writeDate);

            }

            var model = await PagingList.CreateAsync(_list, 20, page, sortExpression, "-idx");


            ViewBag.설문조사_c = _list.Count();
            return View(model);
        }



        #region 게시판

        public async Task<IActionResult> Board_List(int? cate, int? productIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            ViewBag.company_idx = company_idx;
            #endregion

            #region 변수설정
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;
            ViewBag.카테고리 = cate.ToString();

            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }

            if (auth >= 8)
            {
                //게시판 종류 드롭다운==============================================================================================================================================          
                var category =
                    db.BoardMenu.Where(
                        a =>
                        a.company_idx == company_idx && a.open_yn == "Y").Select(
                            a => new { 값 = a.idx, 이름 = a.title });
                ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
                //=====================================================================================================================================================================

            }
            else
            {
                //회사별 데이터 드롭다운==============================================================================================================================================          
                var category =
                    db.BoardMenu.Where(
                        a =>
                        a.company_idx == company_idx && ((a.department_idx == department_idx || a.open_yn == "Y"))).Select(
                             a => new { 값 = a.idx, 이름 = a.title });
                ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
                //=====================================================================================================================================================================
            }

            //======================================================================================================================================================== 
            var company_type =
                db.company.Where(p => (p.useYn == "Y" && p.idx != 4)).OrderBy(
                    o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.요청회사 = new SelectList(company_type.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 

            #endregion

            var query = db.BoardList.AsNoTracking().Where(a => a.useable != "N" && a.BM_idx == cate && a.productIdx == productIdx).Include(a => a.productIdxNavigation).OrderByDescending(a => a.writeDate);

            //var proName = db.productInfo.Where(a => a.idx == productIdx && a.useYn == "Y").FirstOrDefault();

            var model = await PagingList.CreateAsync(query, 10, page, sortExpression, "-idx");

            model.RouteValue = new RouteValueDictionary {
                { "search_all", search_all},
                { "search_all_type", search_all_type}
            };

            if (!string.IsNullOrEmpty(search_all))
            {
                if (search_all_type == "1")
                {
                    query = query.Where(p => p.title.Contains(search_all) || p.content.Contains(search_all) || p.productIdxNavigation.productName.Contains(search_all)).OrderByDescending(a => a.writeDate);
                }
                if (search_all_type == "2")
                {
                    query = query.Where(p => p.title.Contains(search_all)).OrderByDescending(a => a.writeDate);
                }
                if (search_all_type == "3")
                {
                    query = query.Where(p => p.writer.StartsWith(search_all)).OrderByDescending(a => a.writeDate);
                }

                model = await PagingList.CreateAsync(query, 20, page, sortExpression, "-idx");

                model.RouteValue = new RouteValueDictionary {
                { "search_all", search_all},
                { "search_all_type", search_all_type}

            };

            }

            //권한 시작==============================================================================================
            BoardAuth(null, cate);
            //권한 끝================================================================================================

            return View(model);

        }

        public ActionResult BoardView(int idx, int? cate, int? classIdx)
        {
            if (idx == 0)
            {
                //0번 게시글은 임시글로써, DB에 존재하지 않는 글임
                return NotFound();
            }

            //권한 시작==============================================================================================
            BoardAuth(idx, cate);
            //권한 끝================================================================================================

            BoardList data = db.BoardList.Find(idx);

            #region 파일 가져오기
            //파일 가져오기=====================================================================================================================                    

            var _list = (from a in db.BoardFile where a.Md_id == data.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

            ViewBag.이미지리스트 = _list;
            ViewBag.이미지리스트카운트 = _list.Count();

            //파일 끝============================================================================================================================ 
            #endregion

            #region 조회수 증가

            data.hit = data.hit + 1; ;

            db.SaveChanges(); // 실제로 저장 


            #endregion

            #region 읽은 사용자 저장

            int _readCount = (from a in db.BoardRread where a.board_idx == idx && a.user_id == User.Identity.Name select a.idx).Count();

            if (_readCount == 0)
            {

                var _insert = new BoardRread
                {
                    user_id = User.Identity.Name,
                    user_name = (from a in db.user where a.userId == User.Identity.Name select a.userName).FirstOrDefault(),
                    read_date = DateTime.Now,
                    board_idx = idx

                };

                db.BoardRread.Add(_insert);
                db.SaveChanges(); // 실제로 저장 
            }


            var _read = (from a in db.BoardRread where a.board_idx == idx select a).ToList();

            ViewBag.읽은사람 = _read;

            #endregion

            #region 코멘트 가져오기

            IQueryable<BoardComment> _listComent = Enumerable.Empty<BoardComment>().AsQueryable();

            _listComent = db.BoardComment.Where(p => p.BD_idx == idx && p.use_yn == "Y").OrderByDescending(o => o.idx);

            ViewBag.댓글 = _listComent;
            ViewBag.댓글수 = _listComent.Count();
            #endregion

            return View(data);
        }

        private void BoardAuth(int? idx, int? cate)
        {
            #region 권한

            ViewBag.권한 = "";
            ViewBag.부서 = "";
            ViewBag.관리자 = "";
            ViewBag.코멘트 = "N";
            ViewBag.파일 = "N";

            string user_id = "";

            if (cate != null)
            {
                ViewBag.부서 = (from a in db.BoardMenu where a.idx == cate select a.department_idx).FirstOrDefault();
            }
            string board_type = (from a in db.BoardMenu where a.idx == cate select a.BoardType_idxNavigation.gubun).FirstOrDefault();

            foreach (var item in board_type.Split(","))
            {
                if (item == "file")
                {
                    ViewBag.파일 = "Y";
                }
                if (item == "replay")
                {
                    ViewBag.코멘트 = "Y";
                }
            }

            int _auth_department = 0;
            if (User.Identity.IsAuthenticated)
            {
                //로그인 했을 경우

                user_id = User.Identity.Name;

                _auth_department = (from a in db.user where a.userId == user_id select a.checkAuth).FirstOrDefault();

                if (_auth_department >= 8)
                {
                    ViewBag.권한 = "E";
                    ViewBag.관리자 = "Y";

                }

                if (idx != null)
                {
                    string _auth_writer = (from a in db.BoardList where a.idx == idx select a.writer).FirstOrDefault() ?? "";

                    if (user_id == _auth_writer)
                    {
                        ViewBag.권한 = "E";
                    }
                }

                ViewBag.로그인 = "Y";
            }

            else
            {
                ViewBag.타입 = "normal";
                ViewBag.타이틀 = "전체";
                ViewBag.권한 = "";

                if (ViewBag.부서 == "guest")
                {
                    ViewBag.권한 = "G";
                }
            }

            #endregion
        }

        public ActionResult BoardWrite(BoardList doc, int? idx, int? cate, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.company_idx = company_idx;

            //======================================================================================================================================================== 
            var company_type =
                db.company.Where(p => (p.useYn == "Y")).OrderBy(
                    o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.요청회사 = new SelectList(company_type.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 


            if (idx != null)
            {
                //수정모드
                doc = db.BoardList.Find(idx);

                #region 첨부파일 가져오기
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;
            }

            BoardAuth(idx, cate);

            return View(doc);
        }

        [HttpPost]
        public async Task<IActionResult> Board_action(BoardList doc, int? idx, int cate, string mode_type, List<IFormFile> files, int? productIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            string file_id = "";
            string msg = "";

            if (idx == null)
            {
                msg = "S";
                file_id = DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                #region 저장
                doc.fileId = file_id;
                doc.useable = "Y";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.productIdx = productIdx;
                db.BoardList.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                #endregion
            }
            else
            {
                int _idx = Convert.ToInt32(idx);

                if (mode_type == "D")
                {
                    #region 삭제

                    msg = "D";
                    BoardList _update =
                     (from a in db.BoardList where a.idx == idx select a).Single();

                    _update.useable = "N";
                    _update.delDate = DateTime.Now;

                    db.SaveChanges(); // 실제로 저장 

                    #endregion
                }
                else
                {
                    #region 수정
                    msg = "E";
                    #region 파일 아이디
                    file_id = doc.fileId;

                    if (string.IsNullOrEmpty(file_id))
                    {

                        file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                        doc.fileId = file_id;
                    }
                    #endregion

                    doc.useable = "Y";
                    doc.editDate = DateTime.Now;
                    doc.writeDate = DateTime.Now;
                    db.Entry(doc).State = EntityState.Modified;

                    //idx 제외 업데이트=================================
                    db.Entry(doc).Property("idx").IsModified = false;
                    //==================================================
                    db.SaveChanges();



                    #endregion
                }
            }

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            //===============================================================================
            UserData history = new UserData();
            history.History_write(User.Identity.Name, "/board/boardwrite/cate=" + cate, msg);
            //==============================================================================

            string returnUrl = "/mall/board_list?cate=" + cate + "&productIdx=" + productIdx;

            return Redirect(returnUrl);

        }

        [HttpPost]
        public async Task<IActionResult> BoardImageUpload(string CKEditorFuncNum, IFormFile upload)
        {

            #region 파일 올리기

            string user_id = User.Identity.Name;
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");




            var formFileContent =
                await FileHelpers
                    .ProcessFormFile<IFormFile>(
                        upload, ModelState, _permittedExtensions,
                        _fileSizeLimit);



            // 변수 =========================================================================================================================
            string only = DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

            var _fileName = only + Path.GetFileName(upload.FileName);     // 신규 파일 이름                    
            var _local_path = _targetFilePath + company_id + "/";            // 신규 파일 경로
            var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로

            string ImagePath = Models_photo + company_id + "/" + _fileName;




            //경로에 폴더가 없으면 만들어준다.=============================================
            var dInfo = new DirectoryInfo(_local_path);

            if (!dInfo.Exists)
            {
                dInfo.Create();
            }

            //=================================================================================



            using (var fileStream = System.IO.File.Create(filePath))
            {
                await fileStream.WriteAsync(formFileContent);

            }



            var sb = new StringBuilder();
            sb.AppendFormat("<script>");
            sb.AppendFormat("window.parent.CKEDITOR.tools.callFunction('" + CKEditorFuncNum + "', '" + ImagePath + "', 'OK'); ");
            sb.AppendFormat("history.go(-1)");
            sb.AppendFormat("</script>");
            await Response.WriteAsync(sb.ToString());


            #endregion

            return null;

        }

        public ActionResult BoardComment_action(BoardComment doc, string BD_idx, string cate, string mode_type, int? c_idx, int? productIdx)
        {
            int idx = 0;

            string msg = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            if (c_idx == null)
            {
                #region 저장

                doc.write_date = DateTime.Now;
                doc.writer = User.Identity.Name;
                doc.edit_date = DateTime.Now;
                doc.use_yn = "Y";
                db.BoardComment.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {

                if (mode_type == "D")
                {
                    #region 삭제

                    BoardComment doc_del = db.BoardComment.Single(x => x.idx == c_idx);
                    db.BoardComment.Remove(doc_del);
                    db.SaveChanges();

                    msg = Util.msg.msg_del;

                    #endregion
                }

                else if (mode_type == "E")
                {
                    #region 임시 삭제 / 상태 변환 업데이트

                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == c_idx select a).Single();
                    _update.edit_date = DateTime.Now;
                    _update.use_yn = "D";
                    _update.writer = User.Identity.Name;

                    db.SaveChanges(); // 실제로 저장 


                    msg = Util.msg.msg_disable;

                    #endregion
                }
                else
                {
                    #region 수정


                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == idx select a).Single();

                    _update.edit_date = DateTime.Now;
                    _update.memo = doc.memo;


                    db.SaveChanges(); // 실제로 저장 



                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }
            string url = "/mall/boardview?idx=" + BD_idx + "&cate=" + cate + "&productIdx=" + productIdx;

            return Redirect(url);

        }

        public ActionResult del_set_check(BoardList doc, int file_idx)
        {

            BoardList _updateContent =
                    (from a in db.BoardList where a.idx == doc.idx select a).Single();

            _updateContent.title = doc.title;
            _updateContent.content = doc.content;
            _updateContent.editDate = DateTime.Now;

            db.SaveChanges(); // 실제로 저장 

            #region 삭제

            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();
            _update.use_yn = "N";

            db.SaveChanges(); // 실제로 저장 

            #endregion                       

            return Redirect("/classSquare/BoardWrite?cate=" + doc.BM_idx + "&idx=" + doc.idx);
        }
        #endregion




        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
        private async Task fileUpload(List<IFormFile> files, string user_id, string file_id)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }
        }
        public void History_write(string user_id, string _page, string _state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }

        // 결제 취소 
        public ActionResult payapp_request(string cmd, string goodname, int? goodprice, int? price, string recvphone, string rebillCycleType, string rebillCycleMonth, string rebillExpire, int? mul_no, string rebill_no, string var1, string var2)
        {

            #region 기본 변수
            string user_id = User.Identity.Name;
            price = price ?? 0;
            goodprice = goodprice ?? 0;
            string pay_url3 = "";
            string url = "https://api.payapp.kr/oapi/apiLoad.html";
            string responseText = string.Empty;
            StringBuilder dataParams = new StringBuilder();
            #region 종료일 변경
            DateTime endDate = DateTime.Now;
            if (var1 == "2")
            {
                endDate = endDate.AddMonths(1);
            }
            else
            {
                endDate = endDate.AddMonths(36);
            }
            #endregion
            #endregion

            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                #region 기본 정보 저장
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    linkkey = "gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=",
                    linkval = "gOss/MdwFI1k/Qtrly5ZpxxeRLbvrLi1v5VQbFpTZYk=",
                    recvphone = recvphone,
                    var1 = var1,
                    var2 = var2,
                    payGubun = Convert.ToInt32(var1),
                    startDate = DateTime.Now,
                    endDate = endDate,
                    goodname = goodname,
                    price = Convert.ToInt32(price),
                    goodprice = Convert.ToInt32(goodprice)

                };
                db.payment_payapp.Add(_insert);
                db.SaveChanges();
                #endregion
                goodname = System.Web.HttpUtility.UrlEncode(goodname);
                dataParams.Append("cmd=" + cmd + "&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("goodname=" + goodname + "&");
                dataParams.Append("recvphone=" + recvphone + "&");
                dataParams.Append("var1=" + var1 + "&");
                dataParams.Append("var2=" + var2 + "&");
                dataParams.Append("smsuse=n&");
                dataParams.Append("checkretry=y&");
                dataParams.Append("redirectpay=1&");
                dataParams.Append("openpaytype=phone,card,kakaopay,naverpay,zeropay&");
                dataParams.Append("price=" + price + "&");
                dataParams.Append("goodprice=" + goodprice + "&");
                dataParams.Append("rebillCycleType=" + rebillCycleType + "&");
                dataParams.Append("rebillCycleMonth=" + rebillCycleMonth + "&");
                dataParams.Append("rebillExpire=" + rebillExpire + "&");
                dataParams.Append("feedbackurl=https://contactsci.theblueeye.com/mypage/payapp_feedbackurl&");
                dataParams.Append("returnurl=https://contactsci.theblueeye.com/mypage/payapp_success");


            }
            else if (cmd == "rebillCancel" || cmd == "paycancel") //결제취소시
            {
                dataParams.Append("cmd=paycancel&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                dataParams.Append("mul_no=" + mul_no + "&");
            }

            #region 데이터 전송
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";    // 기본값 "GET"
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.ContentLength = dataParams.Length;
            Stream stDataParams = webRequest.GetRequestStream();
            stDataParams.Write(byteDataParams, 0, dataParams.Length); //전송
            #endregion

            #region 데이터 응답
            using (HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse())
            {
                HttpStatusCode status = resp.StatusCode;
                Console.WriteLine(status); // status 가 정상일경우 OK가 입력된다. 

                // 응답과 관련된 stream을 가져온다.
                Stream respStream = resp.GetResponseStream();
                using (StreamReader streamReader = new StreamReader(respStream))
                {
                    responseText = streamReader.ReadToEnd(); //데이터 결과값  
                }
            }

            #endregion

            #region 데이터 후처리
            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                string[] divided = responseText.Split('&');
                var pay_url = divided[4].Split('=');
                pay_url3 = HttpUtility.UrlDecode(pay_url[1]);
                var rebill_param = divided[3].Split('=')[1];
                var result_no = 0;
                //mul_no, rebill_no 구분 저장
                switch (var1)
                {
                    case "2":
                        result_no = 0;
                        break;

                    case "3":
                        result_no = Convert.ToInt32(rebill_param);
                        rebill_no = null;
                        break;
                }

                payment_payapp _update = (from a in db.payment_payapp where a.var2 == var2 select a).OrderByDescending(a => a.writeDate).FirstOrDefault();
                _update.payurl = pay_url3;
                _update.rebill_no = rebill_param;
                _update.mul_no = result_no;

                db.SaveChanges();
                stDataParams.Close();
            }
            else //결제 취소시
            {
                if (cmd == "rebillCancel") //정기결제 해지 후에 결제 취소 진행
                {
                    stDataParams.Close();
                    dataParams = new StringBuilder(); //파라미터 초기화
                    dataParams.Append("cmd=rebillCancel&");
                    dataParams.Append("userid=hellodd5005&");
                    dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                    dataParams.Append("mul_no=" + mul_no + "&");
                    dataParams.Append("rebill_no=" + rebill_no + "&");
                    byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
                    webRequest = (HttpWebRequest)WebRequest.Create(url);
                    webRequest.Method = "POST";    // 기본값 "GET"
                    webRequest.ContentType = "application/x-www-form-urlencoded";
                    webRequest.ContentLength = dataParams.Length;
                    stDataParams = webRequest.GetRequestStream();
                    stDataParams.Write(byteDataParams, 0, dataParams.Length);
                    stDataParams.Close();
                }
                else
                {
                    stDataParams.Close();
                }

                var sb = new StringBuilder();
                sb.AppendFormat("<script type='text/javascript'>");
                sb.AppendFormat("location.href='/mall/mallPayList?alert=C'");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
                return null;

            }
            #endregion

            return Redirect(pay_url3);
        }

        // for ckeditor5
        public async Task<JsonResult> ckeditor_one_fileUp(IFormFile upload)
        {


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list"];




            var uploads = Path.Combine(Models_photo, "images/vehicle-key");
            var filePath = Path.Combine(uploads, "rich-text");
            var urls = new List<string>();

            //If folder of new key is not exist, create the folder.
            if (!Directory.Exists(filePath)) Directory.CreateDirectory(filePath);



            var formFileContent =
                await FileHelpers
                    .ProcessFormFile<IFormFile>(
                        upload, ModelState, _permittedExtensions,
                        _fileSizeLimit);





            // 변수 =========================================================================================================================
            string only = DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

            var _fileName = only + Path.GetFileName(upload.FileName);     // 신규 파일 이름                    
            var _local_path = filePath + "/";            // 신규 파일 경로
            var _filePath = Path.Combine(_local_path, _fileName);            // 전체 경로


            using (var fileStream = System.IO.File.Create(_filePath))
            {
                await fileStream.WriteAsync(formFileContent);

            }

            string _url = $"http://{HttpContext.Request.Host}/searchFile/images/vehicle-key/rich-text/{_fileName}";

            //  return Json(urls);
            return Json(new { uploaded = "true", url = _url });
        }

    }
}