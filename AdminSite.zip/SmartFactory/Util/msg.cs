﻿using SmartFactory.Models;

using System.Linq;
namespace SmartFactory.Util
{
    public class msg
    {
        public static string msg_insert = "Saved.";
        public static string msg_edit = "Update complete";
        public static string msg_del = "Deleted.";
        public static string msg_no = "You do not have permission.";
        public static string msg_disable = "Disable.";



    }

    public class get_word
    {



        // string language = Request.Cookies["language"].Value ?? "korea";
        public static string language_code(string language_code, string code)
        {
            db_e db = new db_e();

            code = code.Trim();

            string _language_code = "korea";

            if (language_code == "korea")
            {

                _language_code = (from a in db.language
                                  where a.code_name.Equals(code)
                                  select a.korea).FirstOrDefault();
            }

            else if (language_code == "english")
            {

                _language_code = (from a in db.language
                                  where a.code_name.Equals(code)
                                  select a.english).FirstOrDefault();

            }

            return _language_code;

        }
        public static string style_color(string code)
        {

            string color = "red";

            if (code == "blue") { color = "tbl_blue"; }
            else if (code == "azure") { color = "tbl_azure"; }
            else if (code == "green") { color = "tbl_green"; }
            else if (code == "orange") { color = "tbl_orange"; }
            else if (code == "red") { color = "tbl_red"; }
            else if (code == "purple") { color = "tbl_purple"; }





            return color;
        }

        public static string file_type(string code)
        {

            string color = "file.gif";
            code = code.ToLower();
            if (code == "jpg") { color = "img.gif"; }
            else if (code == "gif") { color = "img.gif"; }
            else if (code == "jpeg") { color = "img.gif"; }
            else if (code == "png") { color = "img.gif"; }
            else if (code == "eps") { color = "eps.gif"; }
            else if (code == "pdf") { color = "pdf.gif"; }
            else if (code == "hwp") { color = "hwp.gif"; }
            else if (code == "doc") { color = "doc.gif"; }
            else if (code == "docx") { color = "doc.gif"; }
            else if (code == "ppt") { color = "ppt.gif"; }
            else if (code == "pptx") { color = "ppt.gif"; }
            else if (code == "xlsx") { color = "xlsx.gif"; }
            else if (code == "xls") { color = "xlsx.gif"; }
            else if (code == "zip") { color = "zip.gif"; }
            else if (code == "txt") { color = "txt.gif"; }


            return color;
        }
        public static string file_type2(string code)
        {

            string color = "b_file.PNG";
            code = code.ToLower();
          
           
             if (code == "pdf")     { color = "b_pdf.png"; }
            else if (code == "hwp") { color = "b_hwp.png"; }
            else if (code == "doc") { color = "b_doc.png"; }
            else if (code == "docx") { color = "b_doc.png"; }
            else if (code == "ppt") { color = "b_ppt.png"; }
            else if (code == "pptx") { color = "b_ppt.png"; }
            else if (code == "xlsx") { color = "b_xlsx.png"; }
            else if (code == "xls") { color = "b_xlsx.png"; }
            else if (code == "zip") { color = "b_zip.png"; }
            else if (code == "txt") { color = "b_txt.png"; }
            else if (code == "7z") { color = "b_7z.png"; }
            else if (code == "mp3") { color = "b_mp3.png"; }
            else if (code == "mp4") { color = "b_mp4.png"; }
            else if (code == "avi") { color = "b_mp4.png"; }
            else if (code == "mkv") { color = "b_mp4.png"; }
            else if (code == "txt") { color = "b_txt.png"; }
            else if (code == "show") { color = "b_show.png"; }


            return color;
        }


        public static string img_check(string code)
        {

            string color = "";
            code = code.ToLower();

            if (code == "jpg")  { color = "img"; }
            else if (code == "gif")  { color = "img"; }
            else if (code == "jpeg") { color = "img"; }
            else if (code == "png")  { color = "img"; }
         


            return color;
        }

    }
 
}