﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class orderClass
    {
        public orderClass()
        {
            orderClassDetail = new HashSet<orderClassDetail>();
        }

        [Key]
        public int idx { get; set; }
        public string orderCode { get; set; }
        public int? userIdx { get; set; }
        public string cartInfo { get; set; }
        public int price { get; set; }
        public int payType { get; set; }
        [StringLength(1)]
        public string state { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime delDate { get; set; }

        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.orderClass))]
        public virtual user userIdxNavigation { get; set; }
        [InverseProperty("orderIdxNavigation")]
        public virtual ICollection<orderClassDetail> orderClassDetail { get; set; }
    }
}
