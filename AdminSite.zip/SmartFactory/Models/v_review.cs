﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    [Keyless]
    public partial class v_review
    {
        public int idx { get; set; }
        public int BM_idx { get; set; }
        [StringLength(1)]
        public string userYn { get; set; }
        [StringLength(1)]
        public string classYn { get; set; }
        [StringLength(2)]
        public string boardYn { get; set; }
        public int BoardType_idx { get; set; }
        [StringLength(200)]
        public string writer { get; set; }
        [Required]
        [StringLength(250)]
        public string title { get; set; }
        public int boardIdx { get; set; }
        [StringLength(50)]
        public string fileId { get; set; }
        [Column(TypeName = "ntext")]
        public string content { get; set; }
        [StringLength(150)]
        public string photoProfile { get; set; }
        public int Expr1 { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [StringLength(1)]
        public string mainYn { get; set; }
        public int classIdx { get; set; }
    }
}
