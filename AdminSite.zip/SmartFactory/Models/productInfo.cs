﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class productInfo
    {
        public productInfo()
        {
            BoardList = new HashSet<BoardList>();
            codeOption = new HashSet<codeOption>();
            orderProductDetail = new HashSet<orderProductDetail>();
            productCart = new HashSet<productCart>();
            productRefund = new HashSet<productRefund>();
            productReturn = new HashSet<productReturn>();
            productReview = new HashSet<productReview>();
        }

        [Key]
        public int idx { get; set; }
        public int category { get; set; }
        public int shopIdx { get; set; }
        public string productName { get; set; }
        public int? optionIdx { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        [StringLength(50)]
        public string fileId { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }
        public int price { get; set; }
        public int? stateIdx { get; set; }
        public int? uploadGubun { get; set; }
        public int? indexOrder { get; set; }
        public string returnInfo { get; set; }
        [StringLength(1)]
        public string mainYn { get; set; }

        [ForeignKey(nameof(category))]
        [InverseProperty(nameof(code_productCategory.productInfo))]
        public virtual code_productCategory categoryNavigation { get; set; }
        [ForeignKey(nameof(optionIdx))]
        [InverseProperty("productInfo")]
        public virtual codeOption optionIdxNavigation { get; set; }
        [ForeignKey(nameof(shopIdx))]
        [InverseProperty(nameof(code_shopinfo.productInfo))]
        public virtual code_shopinfo shopIdxNavigation { get; set; }
        [ForeignKey(nameof(stateIdx))]
        [InverseProperty(nameof(code_productState.productInfo))]
        public virtual code_productState stateIdxNavigation { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<BoardList> BoardList { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<codeOption> codeOption { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<orderProductDetail> orderProductDetail { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<productCart> productCart { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<productRefund> productRefund { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<productReturn> productReturn { get; set; }
        [InverseProperty("productIdxNavigation")]
        public virtual ICollection<productReview> productReview { get; set; }
    }
}
