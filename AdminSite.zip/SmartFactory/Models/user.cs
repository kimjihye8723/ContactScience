﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class user
    {
        public user()
        {
            classCart = new HashSet<classCart>();
            classFavorite = new HashSet<classFavorite>();
            classInfo = new HashSet<classInfo>();
            classSurvey = new HashSet<classSurvey>();
            deliveryList = new HashSet<deliveryList>();
            orderClass = new HashSet<orderClass>();
            orderClassDetail = new HashSet<orderClassDetail>();
            orderProduct = new HashSet<orderProduct>();
            orderProductDetail = new HashSet<orderProductDetail>();
            productCart = new HashSet<productCart>();
            productReclaim = new HashSet<productReclaim>();
            productReturn = new HashSet<productReturn>();
            productReview = new HashSet<productReview>();
        }

        [Key]
        public int idx { get; set; }
        [Required]
        [StringLength(50)]
        public string userId { get; set; }
        [StringLength(50)]
        public string userPassword { get; set; }
        [Required]
        [StringLength(50)]
        public string userName { get; set; }
        [StringLength(50)]
        public string userTel { get; set; }
        [StringLength(150)]
        public string userEmail { get; set; }
        [StringLength(150)]
        public string companyId { get; set; }
        public int companyIdx { get; set; }
        public int departmentIdx { get; set; }
        public int userClass { get; set; }
        [StringLength(150)]
        public string userAuth { get; set; }
        public int checkAuth { get; set; }
        [StringLength(150)]
        public string photoProfile { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [StringLength(50)]
        public string writer { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }
        [MaxLength(50)]
        public byte[] sicEnterKey { get; set; }
        public int? nBoardCate { get; set; }
        public int? qBoardCate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? cStartDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? cEndDate { get; set; }
        [StringLength(1)]
        public string classYn { get; set; }
        public int? dBoardCate { get; set; }
        [StringLength(1)]
        public string month1Free { get; set; }
        [StringLength(1)]
        public string id_save { get; set; }
        [StringLength(1)]
        public string id_one { get; set; }
        [StringLength(50)]
        public string now_ip { get; set; }
        [StringLength(1)]
        public string sms_send { get; set; }
        [StringLength(10)]
        public string main_bg_color { get; set; }

        [ForeignKey(nameof(companyIdx))]
        [InverseProperty(nameof(company.user))]
        public virtual company companyIdxNavigation { get; set; }
        [ForeignKey(nameof(departmentIdx))]
        [InverseProperty(nameof(department.user))]
        public virtual department departmentIdxNavigation { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<classCart> classCart { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<classFavorite> classFavorite { get; set; }
        [InverseProperty("managerIdxNavigation")]
        public virtual ICollection<classInfo> classInfo { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<classSurvey> classSurvey { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<deliveryList> deliveryList { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<orderClass> orderClass { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<orderClassDetail> orderClassDetail { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<orderProduct> orderProduct { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<orderProductDetail> orderProductDetail { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<productCart> productCart { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<productReclaim> productReclaim { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<productReturn> productReturn { get; set; }
        [InverseProperty("userIdxNavigation")]
        public virtual ICollection<productReview> productReview { get; set; }
    }
}
