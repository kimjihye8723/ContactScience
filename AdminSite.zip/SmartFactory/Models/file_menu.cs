﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class file_menu
    {
        public file_menu()
        {
            file_list = new HashSet<file_list>();
        }

        [Key]
        public int file_menu_id { get; set; }
        [StringLength(50)]
        public string file_menu_name { get; set; }
        [StringLength(1)]
        public string use_yn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? write_date { get; set; }
        public int? company_idx { get; set; }
        public int? gubun { get; set; }

        [InverseProperty("file_menu")]
        public virtual ICollection<file_list> file_list { get; set; }
    }
}
