﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class classInfo
    {
        public classInfo()
        {
            BoardList = new HashSet<BoardList>();
            BoardMenu = new HashSet<BoardMenu>();
            classCart = new HashSet<classCart>();
            classContents = new HashSet<classContents>();
            classFavorite = new HashSet<classFavorite>();
            classPlan = new HashSet<classPlan>();
            classReview = new HashSet<classReview>();
            classSurvey = new HashSet<classSurvey>();
            orderClassDetail = new HashSet<orderClassDetail>();
        }

        [Key]
        public int idx { get; set; }
        [StringLength(150)]
        public string className { get; set; }
        public int category { get; set; }
        public int scienceCate { get; set; }
        public int place { get; set; }
        public int age { get; set; }
        public int classType { get; set; }
        public int managerIdx { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime startDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime endDate { get; set; }
        public int period { get; set; }
        public int state { get; set; }
        public int price { get; set; }
        [StringLength(50)]
        public string fileId { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime delDate { get; set; }
        public int nBoardCate { get; set; }
        public int qBoardCate { get; set; }
        public int rBoardCate { get; set; }
        [StringLength(2)]
        public string searchInfo { get; set; }
        [Column(TypeName = "ntext")]
        public string openLink { get; set; }
        public int? limitCount { get; set; }
        public string surveyLink { get; set; }

        [ForeignKey(nameof(age))]
        [InverseProperty(nameof(code_classAges.classInfo))]
        public virtual code_classAges ageNavigation { get; set; }
        [ForeignKey(nameof(category))]
        [InverseProperty(nameof(code_classCategory.classInfo))]
        public virtual code_classCategory categoryNavigation { get; set; }
        [ForeignKey(nameof(managerIdx))]
        [InverseProperty(nameof(user.classInfo))]
        public virtual user managerIdxNavigation { get; set; }
        [ForeignKey(nameof(place))]
        [InverseProperty(nameof(code_classPlace.classInfo))]
        public virtual code_classPlace placeNavigation { get; set; }
        [ForeignKey(nameof(scienceCate))]
        [InverseProperty(nameof(code_scienceCategory.classInfo))]
        public virtual code_scienceCategory scienceCateNavigation { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<BoardList> BoardList { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<BoardMenu> BoardMenu { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<classCart> classCart { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<classContents> classContents { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<classFavorite> classFavorite { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<classPlan> classPlan { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<classReview> classReview { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<classSurvey> classSurvey { get; set; }
        [InverseProperty("classIdxNavigation")]
        public virtual ICollection<orderClassDetail> orderClassDetail { get; set; }
    }
}
