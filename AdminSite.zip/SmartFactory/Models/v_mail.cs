﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    [Keyless]
    public partial class v_mail
    {
        public int userClass { get; set; }
        [StringLength(1)]
        public string classYn { get; set; }
        public int managerIdx { get; set; }
        public int class_qBoardCate { get; set; }
        public int BoardType_idx { get; set; }
        public int? classIdx { get; set; }
        public int? userIdx { get; set; }
        public int BM_idx { get; set; }
        public int BoardList_idx { get; set; }
        [StringLength(150)]
        public string userEmail { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Required]
        [StringLength(250)]
        public string BoardList_title { get; set; }
        [StringLength(200)]
        public string BoardList_writer { get; set; }
        [Column(TypeName = "ntext")]
        public string content { get; set; }
        public int idx { get; set; }
        [Required]
        [StringLength(50)]
        public string userId { get; set; }
        public int? commentsIdx { get; set; }
        [StringLength(2)]
        public string useable { get; set; }
        [StringLength(50)]
        public string commentsWriter { get; set; }
        [StringLength(1)]
        public string commentsYn { get; set; }
        public string classInfoTilte { get; set; }
        [StringLength(1)]
        public string mailYn { get; set; }
        public int classInfo_idx { get; set; }
    }
}
