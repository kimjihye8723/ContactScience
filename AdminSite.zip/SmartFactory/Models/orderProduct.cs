﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class orderProduct
    {
        public orderProduct()
        {
            deliverInfoorderIdxNavigation = new HashSet<deliverInfo>();
            deliverInfouserIdxNavigation = new HashSet<deliverInfo>();
            orderProductDetail = new HashSet<orderProductDetail>();
            productReclaimoptionIdxNavigation = new HashSet<productReclaim>();
            productReclaimorderIdxNavigation = new HashSet<productReclaim>();
            productRefund = new HashSet<productRefund>();
            productReturn = new HashSet<productReturn>();
            productReview = new HashSet<productReview>();
        }

        [Key]
        public int idx { get; set; }
        [StringLength(100)]
        public string orderCode { get; set; }
        public int? userIdx { get; set; }
        public int deliveryIdx { get; set; }
        public string cartInfo { get; set; }
        public int price { get; set; }
        public int payType { get; set; }
        public int? state { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }

        [ForeignKey(nameof(deliveryIdx))]
        [InverseProperty(nameof(deliveryList.orderProduct))]
        public virtual deliveryList deliveryIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.orderProduct))]
        public virtual user userIdxNavigation { get; set; }
        [InverseProperty(nameof(deliverInfo.orderIdxNavigation))]
        public virtual ICollection<deliverInfo> deliverInfoorderIdxNavigation { get; set; }
        [InverseProperty(nameof(deliverInfo.userIdxNavigation))]
        public virtual ICollection<deliverInfo> deliverInfouserIdxNavigation { get; set; }
        [InverseProperty("orderIdxNavigation")]
        public virtual ICollection<orderProductDetail> orderProductDetail { get; set; }
        [InverseProperty(nameof(productReclaim.optionIdxNavigation))]
        public virtual ICollection<productReclaim> productReclaimoptionIdxNavigation { get; set; }
        [InverseProperty(nameof(productReclaim.orderIdxNavigation))]
        public virtual ICollection<productReclaim> productReclaimorderIdxNavigation { get; set; }
        [InverseProperty("orderIdxNavigation")]
        public virtual ICollection<productRefund> productRefund { get; set; }
        [InverseProperty("orderIdxNavigation")]
        public virtual ICollection<productReturn> productReturn { get; set; }
        [InverseProperty("orderIdxNavigation")]
        public virtual ICollection<productReview> productReview { get; set; }
    }
}
