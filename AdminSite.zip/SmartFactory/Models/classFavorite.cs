﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class classFavorite
    {
        [Key]
        public int idx { get; set; }
        public int classIdx { get; set; }
        public int userIdx { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }
        [StringLength(1)]
        public string alarmYn { get; set; }

        [ForeignKey(nameof(classIdx))]
        [InverseProperty(nameof(classInfo.classFavorite))]
        public virtual classInfo classIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.classFavorite))]
        public virtual user userIdxNavigation { get; set; }
    }
}
