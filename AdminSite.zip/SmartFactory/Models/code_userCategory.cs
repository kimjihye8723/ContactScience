﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class code_userCategory
    {
        [Key]
        public int idx { get; set; }
        [Required]
        [StringLength(150)]
        public string codeName { get; set; }
        public int indexOrder { get; set; }
        [Required]
        [StringLength(1)]
        public string useYn { get; set; }
    }
}
