﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class deliverInfo
    {
        [Key]
        public int idx { get; set; }
        public int userIdx { get; set; }
        [StringLength(50)]
        public string userName { get; set; }
        [StringLength(50)]
        public string userTel { get; set; }
        public string userAddr { get; set; }
        public string request { get; set; }
        [StringLength(1)]
        public string mainYn { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        public int? orderIdx { get; set; }
        public int? state { get; set; }
        [StringLength(350)]
        public string deliverNum { get; set; }
        public string deliverLink { get; set; }
        [StringLength(250)]
        public string deliveryName { get; set; }

        [ForeignKey(nameof(orderIdx))]
        [InverseProperty(nameof(orderProduct.deliverInfoorderIdxNavigation))]
        public virtual orderProduct orderIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(orderProduct.deliverInfouserIdxNavigation))]
        public virtual orderProduct userIdxNavigation { get; set; }
    }
}
