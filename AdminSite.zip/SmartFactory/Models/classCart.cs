﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class classCart
    {
        [Key]
        public int idx { get; set; }
        public int classIdx { get; set; }
        public int userIdx { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime delDate { get; set; }

        [ForeignKey(nameof(classIdx))]
        [InverseProperty(nameof(classInfo.classCart))]
        public virtual classInfo classIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.classCart))]
        public virtual user userIdxNavigation { get; set; }
    }
}
