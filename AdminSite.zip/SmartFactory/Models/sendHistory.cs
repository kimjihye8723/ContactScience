﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class sendHistory
    {
        [Key]
        public int idx { get; set; }
        [StringLength(50)]
        public string title { get; set; }
        [StringLength(10)]
        public string gubun { get; set; }
        [StringLength(100)]
        public string user_id { get; set; }
        public string memo { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
    }
}
