﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class code_classPlace
    {
        public code_classPlace()
        {
            classInfo = new HashSet<classInfo>();
        }

        [Key]
        public int idx { get; set; }
        public int placeType { get; set; }
        [StringLength(250)]
        public string codeName { get; set; }
        public int indexOrder { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }

        [InverseProperty("placeNavigation")]
        public virtual ICollection<classInfo> classInfo { get; set; }
    }
}
