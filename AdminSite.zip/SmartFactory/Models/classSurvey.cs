﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class classSurvey
    {
        [Key]
        public int idx { get; set; }
        public int classIdx { get; set; }
        public int userIdx { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        public double score { get; set; }
        public string link { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }

        [ForeignKey(nameof(classIdx))]
        [InverseProperty(nameof(classInfo.classSurvey))]
        public virtual classInfo classIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.classSurvey))]
        public virtual user userIdxNavigation { get; set; }
    }
}
