﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class code_classAges
    {
        public code_classAges()
        {
            classInfo = new HashSet<classInfo>();
        }

        [Key]
        public int idx { get; set; }
        [Required]
        [StringLength(250)]
        public string codeName { get; set; }
        public int indexOrder { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }

        [InverseProperty("ageNavigation")]
        public virtual ICollection<classInfo> classInfo { get; set; }
    }
}
