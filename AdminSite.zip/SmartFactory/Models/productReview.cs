﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class productReview
    {
        [Key]
        public int idx { get; set; }
        public int orderIdx { get; set; }
        public int productIdx { get; set; }
        public int userIdx { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        public string title { get; set; }
        [Column(TypeName = "ntext")]
        public string description { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }
        [StringLength(150)]
        public string fileId { get; set; }

        [ForeignKey(nameof(orderIdx))]
        [InverseProperty(nameof(orderProduct.productReview))]
        public virtual orderProduct orderIdxNavigation { get; set; }
        [ForeignKey(nameof(productIdx))]
        [InverseProperty(nameof(productInfo.productReview))]
        public virtual productInfo productIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.productReview))]
        public virtual user userIdxNavigation { get; set; }
    }
}
