﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class classContents
    {
        [Key]
        public int idx { get; set; }
        [StringLength(150)]
        public string fileId { get; set; }
        public int classIdx { get; set; }
        [Required]
        [StringLength(1)]
        public string mainYn { get; set; }
        [Required]
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "ntext")]
        public string link { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }

        [ForeignKey(nameof(classIdx))]
        [InverseProperty(nameof(classInfo.classContents))]
        public virtual classInfo classIdxNavigation { get; set; }
    }
}
