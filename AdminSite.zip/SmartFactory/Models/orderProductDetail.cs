﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class orderProductDetail
    {
        [Key]
        public int idx { get; set; }
        public int orderIdx { get; set; }
        public int productIdx { get; set; }
        public int userIdx { get; set; }
        public int optionIdx { get; set; }
        public int price { get; set; }
        public int qty { get; set; }
        [StringLength(1)]
        public string state { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }

        [ForeignKey(nameof(orderIdx))]
        [InverseProperty(nameof(orderProduct.orderProductDetail))]
        public virtual orderProduct orderIdxNavigation { get; set; }
        [ForeignKey(nameof(productIdx))]
        [InverseProperty(nameof(productInfo.orderProductDetail))]
        public virtual productInfo productIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.orderProductDetail))]
        public virtual user userIdxNavigation { get; set; }
    }
}
