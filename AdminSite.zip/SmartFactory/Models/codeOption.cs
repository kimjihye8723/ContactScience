﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class codeOption
    {
        public codeOption()
        {
            productCart = new HashSet<productCart>();
            productInfo = new HashSet<productInfo>();
        }

        [Key]
        public int idx { get; set; }
        [StringLength(150)]
        public string codeName { get; set; }
        public int price { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? writeDate { get; set; }
        public int? productIdx { get; set; }

        [ForeignKey(nameof(productIdx))]
        [InverseProperty("codeOption")]
        public virtual productInfo productIdxNavigation { get; set; }
        [InverseProperty("optionIdxNavigation")]
        public virtual ICollection<productCart> productCart { get; set; }
        [InverseProperty("optionIdxNavigation")]
        public virtual ICollection<productInfo> productInfo { get; set; }
    }
}
