﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    [Keyless]
    public partial class ViewClassInfo
    {
        [StringLength(250)]
        public string classCate { get; set; }
        [StringLength(250)]
        public string scienceCate { get; set; }
        [StringLength(150)]
        public string className { get; set; }
        public int place { get; set; }
        public int age { get; set; }
        public int classType { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime startDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime endDate { get; set; }
        public int state { get; set; }
        [StringLength(50)]
        public string fileId { get; set; }
        public int nBoardCate { get; set; }
        public int qBoardCate { get; set; }
        public int rBoardCate { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        public int period { get; set; }
        public int price { get; set; }
        [Required]
        [StringLength(50)]
        public string userName { get; set; }
        [StringLength(150)]
        public string companyId { get; set; }
        [StringLength(1)]
        public string Expr1 { get; set; }
        public int? Expr2 { get; set; }
        public int? Expr3 { get; set; }
        [StringLength(250)]
        public string classPlace { get; set; }
        [Required]
        [StringLength(250)]
        public string classAges { get; set; }
        public int idx { get; set; }
        public int scIdx { get; set; }
        public int cateIdx { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        public int managerIdx { get; set; }
        [StringLength(150)]
        public string userEmail { get; set; }
        public int? dBoardCate { get; set; }
    }
}
