﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SmartFactory.Models
{
    public partial class deliverState
    {
        [Key]
        public int idx { get; set; }
        public int? deliverNum { get; set; }
        public string deliverLink { get; set; }
        public int state { get; set; }
        public int? orderIdx { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [StringLength(250)]
        public string deliveryName { get; set; }

        [ForeignKey(nameof(orderIdx))]
  //      [InverseProperty(nameof(orderProduct.deliverState))]
        public virtual orderProduct orderIdxNavigation { get; set; }
    }
}
