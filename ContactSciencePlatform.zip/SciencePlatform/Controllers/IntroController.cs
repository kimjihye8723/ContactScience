﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SciencePlatform.Controllers
{
    public class IntroController : Controller
    {


        private readonly db_e db = new db_e();


        // 콘택트 사이언스란?
        public IActionResult intro1()
        {
            return View();
        }

        // 참여과학자
        public IActionResult intro2(string tab_id, string search_all, int? idx)
        {
            int tabN = 0;

            //분야별 찾기 - 클래스 운영이 끝난 과학자들만 참여과학자 페이지로 보이게 
            var _list = db.code_scienceCategory.Where(a=>a.useYn =="Y").OrderBy(p => p.idx).ToList();
            ViewBag.선택리스트 = _list;
                      
            var _list2 = db.ViewClassInfo.Where(p => p.useYn == "Y" && p.endDate <= DateTime.Today).OrderBy(p => p.idx);

            if (tab_id != null)
            {
                tabN = Convert.ToInt32(tab_id.Substring(4,1));

                // 과학분야별 리스트 내용 
                _list2 = _list2.Where(p => p.scIdx == tabN).OrderBy(p => p.idx);
            }

            ViewBag.클래스운영끝난과학자들 = _list2;
            ViewBag.클래스운영끝난과학자들c = _list2.Count();

            //통합검색창
            ViewBag.search_all = search_all;
            #region 검색 리스트

            if (!string.IsNullOrEmpty(search_all))
            {
                _list2 = _list2.Where(p => p.userName.Contains(search_all) || p.className.Contains(search_all) || p.title.Contains(search_all) && p.useYn != "N").OrderBy(p => p.idx);

                ViewBag.검색결과c = _list2.Count();
            }
            #endregion

            return View(_list2);
        }

      
        public IActionResult sciRoom()
        {
            return View();
        }



        public ActionResult calendar(int? sCate)
        {
            //과학분야별 체크박스 리스트 
            var _list = (from a in db.code_scienceCategory select a).OrderBy(p => p.idx).ToList();
            ViewBag.선택리스트 = _list;


            // 접수가능 리스트
            var _list2 = db.classInfo.Where(p => p.useYn != "N" && p.state == 1).Include(p=>p.managerIdxNavigation).OrderByDescending(p => p.writeDate).ToList();           
            ViewBag.접수가능 = _list2;
            ViewBag.접수가능c = _list2.Count();

            // 접수예정 리스트
            var _list3 = db.classInfo.Where(p => p.useYn != "N" && p.state == 2).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.writeDate).ToList();
            ViewBag.접수예정 = _list3;
            ViewBag.접수예정c = _list3.Count();

            return View();
        }



        public string GetCalendarItem(string sCate)
        {
            string json = "";

            List<classInfo> calData = db.classInfo.Where(p => p.useYn != "N").ToList();
           
            


            calData = db.classInfo.Where(p => p.useYn != "N" && sCate.Contains(p.searchInfo)).ToList();


            //if (/*sCate != null*/ !string.IsNullOrEmpty(sCate))
            //{

            //    foreach (var item in sCate.Split(','))
            //    {

            //        //calData.AddRange(calData);

            //        calData = calData.OrderByDescending(o => o.scienceCate == Int32.Parse(item)).ToList();


            //    }
            //}
            //else
            //{
            //  calData = db.classInfo.Where(p => p.useYn != "N" && p.scienceCate == Int32.Parse(sCate)).ToList();
            //}


            json = JsonConvert.SerializeObject(calData.Select(a => new {
                id = a.idx,
                title = a.title,
                gubun_type = a.scienceCate,
                start = a.startDate,
                end = a.endDate
            }));

            ViewBag.calDate = calData;
            
            
            //json
            string stop = string.Empty;

            return json;
        }

    }
}
