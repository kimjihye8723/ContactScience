﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ReflectionIT.Mvc.Paging;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using SmartFactory.Util;
using static SciencePlatform.Controllers.AccountController;
using Microsoft.AspNetCore.Http;
using LazZiya.ImageResize;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;
using Microsoft.AspNetCore.Routing;
using System.Net;
using Newtonsoft.Json;
using System.Web;

namespace SciencePlatform.Controllers
{
    public class MyPageController : Controller
    {
        private readonly db_e db = new db_e();


        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public MyPageController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion


        #region 일반회원 마이페이지 

        public IActionResult myPage()
        {
            return View();
        }
        public IActionResult myWriting()
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            // 일반유저가 작성한 QNA글 리스트
            var qna_list = db.BoardList.Include(a=>a.classIdxNavigation).Where(a => a.BM_idx == 6 && a.writer == user_id && a.useable != "N").OrderByDescending(a => a.writeDate).ToList();
            ViewBag.qna_list = qna_list;
            ViewBag.qna_list_c = qna_list.Count();

            // 일반유저가 작성한 후기글 리스트
            var review_list = db.BoardList.Include(a => a.classIdxNavigation).Where(a => a.BM_idx == 7 && a.writer == user_id && a.useable != "N").OrderByDescending(a => a.writeDate).ToList();
            ViewBag.review_list = review_list;
            ViewBag.review_list_c = review_list.Count();

            return View();
        }

        // 진행중인 클래스 
        [Authorize]
        public async Task<IActionResult> ingClass(orderClassDetail doc, int? idx, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            // 보드리스트처럼 필터링 해주고 user_id랑 매칭시켜 리스트 뿌리기 
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();
            var query = db.orderClassDetail.AsNoTracking().Include(a=>a.classIdxNavigation).Where(a => a.useYn != "N" && a.userIdx == userIdx && a.state == "Y" && DateTime.Now.Year == a.classIdxNavigation.startDate.Year && DateTime.Now.Month <= a.classIdxNavigation.startDate.Month);
                      
            ViewBag.c = query.Count();
            var model = await PagingList.CreateAsync(query, 15, page, sortExpression, "-idx");
            return View(model);


        }


        // 관심있는 클래스 
        public async Task<IActionResult> interestClass(classFavorite doc, int? idx, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();
            var query = db.classFavorite.AsNoTracking().Where(a => a.userIdx == userIdx);
            ViewBag.c = query.Count();


            var model = await PagingList.CreateAsync(query, 15, page, sortExpression, "-idx");




            var _list3 = db.classFavorite.Where(p => p.idx == idx && p.userIdx == userIdx).Count();
            if (_list3 > 0)
            {
                ViewBag.알람 = "Y";
            }
            else
            {
                ViewBag.알람 = "N";
            }


            return View(model);
        }


        // 종료/이수된 클래스        
        public async Task<IActionResult> endClass(orderClassDetail doc, int? idx, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            // 보드리스트처럼 필터링 해주고 user_id랑 매칭시켜 리스트 뿌리기 
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();
            //var query = db.orderClassDetail.AsNoTracking().Where(a => a.useYn != "N" && a.userIdx == userIdx && a.state == "E");
            var query = db.orderClassDetail.AsNoTracking().Include(a => a.classIdxNavigation).Where(a => a.useYn != "N" && a.userIdx == userIdx && a.state == "Y" && DateTime.Today > a.classIdxNavigation.endDate);


            ViewBag.c = query.Count();
            var model = await PagingList.CreateAsync(query, 15, page, sortExpression, "-idx");



            return View(model);
        }



        // 구독권 결제 
        public IActionResult purchaseDetails()
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a).FirstOrDefault();
            ViewBag.userTel = userIdx.userTel;


            return View();
        }

        // 구독권 결제 내역
        public IActionResult purchaseDetailsList()
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a).FirstOrDefault();
            ViewBag.userTel = userIdx.userTel;


            return View();
        }

        // 사이언스몰 결제 내역
        public IActionResult purchaseDetailsList2()
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a).FirstOrDefault();
            ViewBag.userTel = userIdx.userTel;



            //var orderList = db.orderProduct.Where(a => a.userIdx == userIdx.idx).OrderByDescending(a => a.writeDate).ToList();
            //var thisM = orderList.Where(a => a.writeDate.Month == DateTime.Now.Month).ToList();
            //var beforeM = orderList.Where(a => a.writeDate.Month != DateTime.Now.Month).ToList();

            //ViewBag.주문내역 = orderList;
            //ViewBag.주문내역c = orderList.Count();

            //ViewBag.thisM = thisM; // 이번달 구매내역
            //ViewBag.beforeM = beforeM; // 다음달 구매내역 
            //ViewBag.beforeM_c = beforeM.Count();


            var orderList = db.payment_payapp.Where(a => a.writer == user_id && a.var1 == "4").OrderByDescending(a => a.writeDate).ToList();
            var thisM = orderList.Where(a => a.writeDate.Month == DateTime.Now.Month && (a.pay_state == 64 || a.pay_state == 4)).ToList();
            var beforeM = orderList.Where(a => a.writeDate.Month != DateTime.Now.Month && (a.pay_state == 64 || a.pay_state == 4)).ToList();

            ViewBag.주문내역 = orderList;
            ViewBag.주문내역c = orderList.Count();

            ViewBag.thisM = thisM; // 이번달 구매내역
            ViewBag.thisM_c = thisM.Count(); 
            ViewBag.beforeM = beforeM; // 이전달 구매내역 
            ViewBag.beforeM_c = beforeM.Count();


            return View();
        }




        // 1달 단기 결제 
        [HttpPost]
        public ActionResult payapp_feedbackurl(string rebill_no, string linkkey, string linkval, string goodname, int? price, string recvphone, string reqdate, string pay_date, int? pay_type, int? pay_state, string var1, string var2, int? mul_no, string payurl, string csturl, int? orig_mul_no, int? orig_price, int? amount_taxable, int? amount_taxfree, int? amount_vat, int? naverpoint, string card_name, string naverpay, string canceldate, string cancelmemo, int? goodprice, string memo, int? addcomm, string rebillCycleType, int? rebillCycleMonth, string rebillExpire)
        {
            var sb = new StringBuilder();

            #region Param
            //var userid = "판매자 회원 아이디";
            //var linkkey = "연동 KEY";
            //var linkval = "연동 VALUE";
            //var goodname = "상품명";
            //var price = "결제요청 금액";
            //var recvphone = "수신 휴대폰번호";
            //var memo = "메모";
            //var reqaddr = "주소요청 (1:요청, 0:요청안함)";
            //var reqdate = "결제요청 일시";
            //var pay_memo = "결제시 입력한 메모";
            //var pay_addr = "결제시 입력한 주소";
            //var pay_date = "결제승인 일시";
            //var pay_type = "결제수단 (1:신용카드, 2:휴대전화, 3:해외결제, 4:대면결제, 6:계좌이체, 7:가상계좌, 9:문화상품권)";
            //var pay_state = "결제요청 상태 (4:결제완료, 8,16,31:요청취소, 9,64:승인취소, 10:결제대기)";
            //var var1 = "임의 사용 변수 1";
            //var var2 = "임의 사용 변수 2";
            //var mul_no = "결제요청번호";
            //var payurl = "결제페이지 주소";
            //var csturl = "매출전표URL";
            //var amount_taxable  == "과세 공급가액";
            //var amount_taxfree  == "면세 공급가액";
            //var amount_vat == "부가세";
            //var naverpoint == "네이버 포인트 결제시 금액(네이버페이 결제시만 제공)";
            //var naverpay == "네이버결제 구분 방법(네이버페이 결제시만 제공 카드일 경우: 'card', 계좌결제일경우: 'bank')";
            //var buyerid == "구매자 아이디";
            //var canceldate == "취소일시";
            //var cancelmemo == "취소메모";

            #endregion

            try
            {
                payment_payapp _update1 = (from a in db.payment_payapp where a.var2 == var2 select a).OrderByDescending(a => a.writeDate).FirstOrDefault();

                switch (pay_state)
                {
                    // 결제요청
                    case 1:
                        _update1.reqdate = reqdate ?? null;
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_type = pay_type ?? 0;
                        _update1.pay_state = pay_state ?? 0;
                        _update1.mul_no = mul_no ?? 0;
                        _update1.orig_mul_no = orig_mul_no ?? 0;
                        _update1.orig_price = orig_price ?? 0;
                        _update1.amount_taxable = amount_taxable ?? 0;
                        _update1.amount_taxfree = amount_taxfree ?? 0;
                        _update1.amount_vat = amount_vat ?? 0;
                        _update1.rebill_no = rebill_no ?? null;

                        db.SaveChangesAsync();

                        break;


                    //결제완료
                    case 4:
                        _update1.reqdate = reqdate ?? null;
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_type = pay_type ?? 0;
                        _update1.pay_state = pay_state ?? 0;
                        _update1.mul_no = mul_no ?? 0;
                        _update1.naverpoint = naverpoint ?? 0;
                        _update1.naverpay = naverpay ?? null;
                        _update1.card_name = card_name ?? null;
                        _update1.csturl = csturl ?? null;

                        db.SaveChangesAsync(); // 실제로 저장 



                        #region user 수동 업데이트
                        user _update =
                                     (from a in db.user where a.userId == _update1.writer select a).Single();

                            _update.cStartDate = _update1.startDate;
                            _update.cEndDate = _update1.endDate;
                            _update.month1Free = "N";
                            _update.classYn = "Y";
                            db.SaveChanges(); // 실제로 저장  
                        #endregion


                        break;




                    //요청취소
                    case 8:
                    case 16:
                    case 32:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        _update1.canceldate = canceldate ?? null;
                        _update1.cancelmemo = cancelmemo ?? null;

                        db.SaveChangesAsync();

                        #region user 수동 업데이트
                            user _update_ =
                                         (from a in db.user where a.userId == _update1.writer select a).Single();

                            _update_.cStartDate = null;
                            _update_.cEndDate = null;
                            _update_.month1Free = "N";
                            _update_.classYn = "N";

                        db.SaveChanges(); // 실제로 저장  
                        #endregion

                        break;


                    //승인취소
                    case 9:
                    case 64:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        _update1.canceldate = canceldate ?? null;
                        _update1.cancelmemo = cancelmemo ?? null;

                        db.SaveChangesAsync();


                        #region user 수동 업데이트
                            user _update_c =
                                         (from a in db.user where a.userId == _update1.writer select a).Single();

                            _update_c.cStartDate = null;
                            _update_c.cEndDate = null;
                            _update_c.month1Free = "N";
                            _update_c.classYn = "N";

                        db.SaveChanges(); // 실제로 저장  
                        #endregion

                        break;


                    //결제대기
                    case 10:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        db.SaveChangesAsync();

                        break;


                    //부분취소
                    case 70:
                    case 71:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        _update1.orig_mul_no = orig_mul_no ?? 0;
                        _update1.orig_price = orig_price ?? 0;
                        _update1.canceldate = canceldate ?? null;
                        _update1.cancelmemo = cancelmemo ?? null;
                        db.SaveChangesAsync();


                        #region user 수동 업데이트
                        user _update_c1 =
                                     (from a in db.user where a.userId == _update1.writer select a).Single();

                        _update_c1.cStartDate = null;
                        _update_c1.cEndDate = null;
                        _update_c1.month1Free = "N";
                        _update_c1.classYn = "N";

                        db.SaveChanges(); // 실제로 저장  
                        #endregion

                        break;
                }


                //결제내역 payapp_library 에 백업
                var _insert_ = new payapp_library
                {
                    writeDate = DateTime.Now,
                    linkkey = linkkey ?? null,
                    linkval = linkval ?? null,
                    recvphone = recvphone ?? null,
                    reqdate = reqdate ?? null,
                    pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    pay_type = pay_type ?? 0,
                    pay_state = pay_state ?? 0,
                    var1 = var1 ?? null,
                    var2 = var2 ?? null,
                    mul_no = mul_no ?? 0,
                    csturl = csturl ?? null,
                    orig_mul_no = orig_mul_no ?? 0,
                    orig_price = orig_price ?? 0,
                    amount_taxable = amount_taxable ?? 0,
                    amount_taxfree = amount_taxfree ?? 0,
                    amount_vat = amount_vat ?? 0,
                    naverpoint = naverpoint ?? 0,
                    naverpay = naverpay ?? null,
                    canceldate = canceldate ?? null,
                    cancelmemo = cancelmemo ?? null,
                    card_name = card_name ?? null,
                    payurl = payurl ?? null,
                    goodname = goodname ?? null,
                    goodprice = goodprice ?? 0,
                    rebillCycleType = rebillCycleType ?? null,
                    rebillExpire = rebillExpire ?? null,
                    price = price ?? 0,
                    rebill_no = rebill_no ?? null,

                };

                db.payapp_library.Add(_insert_);
                db.SaveChangesAsync(); // 실제로 저장 


            }
            catch
            { }


            return null;


        }


        //구독권 결제 성공시
        public ActionResult payapp_success(payment_payapp doc, int? idx)
        {


            if (idx != null)
            {
                doc = db.payment_payapp.Where(a => a.idx == idx).OrderBy(a => a.idx).LastOrDefault();

                #region 기본 사용자 정보
                string user_id = doc.writer;
                string company_id = UserData.user_get(user_id, "company_id");
                string department_idx = UserData.user_get(user_id, "department_idx");
                string department_name = UserData.user_get(user_id, "department_name");
                int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
                #endregion

                //결제된 디바이스 목록
                var _list = db.payment_payapp.Where(p => p.pay_state == 4 && p.writer == user_id && p.var1 == "1").OrderByDescending(o => o.pay_date);
                ViewBag.paymentList = _list.FirstOrDefault();
            }


            return View(doc);
        }

        //사이언스몰 결제 성공시
        public ActionResult payapp_success2(payment_payapp doc, int? idx)
        {


            if (idx != null)
            {
                doc = db.payment_payapp.Where(a => a.idx == idx).OrderBy(a => a.idx).LastOrDefault();

                #region 기본 사용자 정보
                string user_id = doc.writer;
                string company_id = UserData.user_get(user_id, "company_id");
                string department_idx = UserData.user_get(user_id, "department_idx");
                string department_name = UserData.user_get(user_id, "department_name");
                int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
                #endregion

                //결제된 디바이스 목록
                var _list = db.payment_payapp.Where(p => p.pay_state == 4 && p.writer == user_id && p.var1 == "1").OrderByDescending(o => o.pay_date);
                ViewBag.paymentList = _list.FirstOrDefault();
            }


            return View(doc);
        }

        public ActionResult paymentOrder_action(string var2, int how_ck)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            var sb = new StringBuilder();
            sb.AppendFormat("<script>");

            if (how_ck == 1)
            {
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    var2 = var2,
                    payGubun = 1, // 1달 단기 결제 
                    startDate = DateTime.Now,
                    endDate = DateTime.Now.AddMonths(1)
                };

                db.payment_payapp.Add(_insert);
                db.SaveChanges();
            }
            else if (how_ck == 2)
            {
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    var2 = var2,
                    payGubun = 2, // 1달 정기 결제 
                    startDate = DateTime.Now,
                    endDate = DateTime.Now.AddMonths(1)
                };
                db.payment_payapp.Add(_insert);
                db.SaveChanges();
            }
            else if (how_ck == 3)
            {
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    var2 = var2,
                    payGubun = 3, // 1년 정기 결제 
                    startDate = DateTime.Now,
                    endDate = DateTime.Now.AddMonths(1)
                };

                db.payment_payapp.Add(_insert);
                db.SaveChanges();


            }


            sb.AppendFormat("payment_it('" + var2 + "', '" + how_ck + "');");
            sb.AppendFormat("</script>");

            Response.WriteAsync(sb.ToString());

            return null;
        }

        // 1달 결제 취소 
        public ActionResult payment_cancel(string var2, string pay_gubun)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string department_name = UserData.user_get(user_id, "department_name");
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            var sb = new StringBuilder();

            //payment_payapp delete = db.payment_payapp.Where(x => x.var2 == var2).FirstOrDefault();
            var delete = db.payment_payapp.Where(x => x.var2 == var2).FirstOrDefault();


            sb.AppendFormat("<script>");

            string cmd = "";
            //var rebill_no = doc.rebill_no;
            DateTime excess = Convert.ToDateTime(delete.pay_date).AddDays(5);
            if (pay_gubun == "2")
            {
                cmd = "rebillCancel"; //정기결제 해지 
            }
            else
            {
                if (excess <= DateTime.Now)
                {
                    cmd = "paycancelreq"; //결제 취소 요청 (구매자가 결제승인 후 D+5일이 경과 되었거나, 판매자 정산이 완료된 경우)
                }
                else
                {
                    cmd = "paycancel"; // 결제 취소
                }
            }



            sb.AppendFormat("$('#cmd').val('" + cmd + "');");
            sb.AppendFormat("$('#var2').val('" + var2 + "');");
            //sb.AppendFormat("$('#rebill_no').val('" + rebill_no + "');");
            sb.AppendFormat("$('#linkkey').val('" + delete.linkkey + "');");
            sb.AppendFormat("$('#mul_no').val('" + delete.mul_no + "');");
            sb.AppendFormat("cancelPay('" + pay_gubun + "');");
            sb.AppendFormat("</script>");

            Response.WriteAsync(sb.ToString());

            return null;
        }

















        //회원정보수정
        public IActionResult myinfoEdit()
        {
            return View();
        }

        //클래스 만족도 설문조사
        public IActionResult Survey()
        {
            return View();
        }

        //  찜 버튼 클릭시 , 관심있는 클래스 리스트 
        public IActionResult like_check(classFavorite doc, string clicked, int idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var sb = new StringBuilder();
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();
            var classIdx = (from a in db.classInfo where a.idx == idx select a.idx).FirstOrDefault();
            sb.AppendFormat("<script>");
            if (clicked != "n")
            {
                #region 입력
                var _insert = new classFavorite
                {
                    classIdx = idx,
                    userIdx = userIdx,
                    writeDate = DateTime.Now,
                    delDate = DateTime.Now,

                };

                db.classFavorite.Add(_insert);
                db.SaveChanges(); // 실제로 저장 

                #endregion
                sb.AppendFormat("$('#favor_" + idx + "').val('Y');"); // 찜 저장 
                sb.AppendFormat("location.reload();");
            }
            else
            {
                #region 삭제

                classFavorite doc_del = (from a in db.classFavorite where a.classIdx == idx && a.userIdx == userIdx select a).FirstOrDefault();
                db.classFavorite.Remove(doc_del);
                db.SaveChanges();

                var msg = SmartFactory.Util.msg.msg_del;
                sb.AppendFormat("$('#favor_" + idx + "').val('N');");  //찜 해제 
                sb.AppendFormat("location.reload();");
                #endregion
            }
            Response.WriteAsync(sb.ToString());
            return null;
        }



        // 마이페이지 벨 버튼 체크 
        public IActionResult bell_check(orderClassDetail doc, string clicked, int idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            var sb = new StringBuilder();
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();
            var classIdx = (from a in db.orderClassDetail where a.idx == idx select a.idx).FirstOrDefault();
            sb.AppendFormat("<script>");

            #region 수동 업데이트
            orderClassDetail _update = (from a in db.orderClassDetail where a.idx == idx select a).Single();

            if (_update.alarmBellYn == "Y")
            {
                _update.alarmBellYn = "N";
                sb.AppendFormat("$('#Btn_" + idx + "').removeClass('clicked');");
                sb.AppendFormat("alert('알림설정이 해제되었습니다.');");

            }
            else if (_update.alarmBellYn == null || _update.alarmBellYn == "N")
            {
                _update.alarmBellYn = "Y";
                sb.AppendFormat("$('#Btn_" + idx + "').addClass('clicked');");
                sb.AppendFormat("alert('알림이 설정되었습니다.');");

            }


            db.SaveChanges(); // 실제로 저장  
            #endregion
            sb.AppendFormat("</script>");
            #endregion



            Response.WriteAsync(sb.ToString());
            return null;
        }


        //  관심클래스 체크여부 
        public IActionResult alarm_check(classFavorite doc, int? idx)
        {
            var sb = new StringBuilder();
            if (idx != null)
            {
                sb.AppendFormat("<script>");
                #region 수동 업데이트
                classFavorite _update = (from a in db.classFavorite where a.idx == idx select a).Single();


                if (_update.alarmYn == "Y")
                {
                    _update.alarmYn = "N";
                    sb.AppendFormat("$('.alCk_" + idx + "').removeClass('clicked');");

                }
                else
                {
                    _update.alarmYn = "Y";
                    sb.AppendFormat("$('.alCk_" + idx + "').addClass('clicked');");

                }

                db.SaveChanges(); // 실제로 저장               
                sb.AppendFormat("</script>");
                #endregion
            }




            Response.WriteAsync(sb.ToString());
            return null;
        }




        //  신청한 클래스 여부 
        public IActionResult class_check(orderClassDetail doc, string ck, int idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion


            var sb = new StringBuilder();
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a).FirstOrDefault();
            var classIdx = (from a in db.orderClassDetail where a.idx == idx select a.idx).FirstOrDefault();

            var clName = db.classInfo.Where(a => a.idx == idx).FirstOrDefault();

            // 결제여부 체크
            DateTime _now = DateTime.Now;


            sb.AppendFormat("<script>");
            if (userIdx.classYn == "Y")
            {
                var stDate = (from a in db.user where a.userId == user_id && a.classYn == "Y" select a.cStartDate).FirstOrDefault();
                var endDate = (from a in db.user where a.userId == user_id && a.classYn == "Y" select a.cEndDate).FirstOrDefault();

                DateTime startTime = Convert.ToDateTime(stDate);
                DateTime endTime = Convert.ToDateTime(endDate);

                if (startTime <= _now && endTime >= _now)
                {
                    if (ck != "Y")
                    {

                        #region 입력
                        var _insert = new orderClassDetail
                        {
                            orderIdx = 0,
                            price = 0,
                            state = "Y",
                            useYn = "Y", // 수강권 구매 ok
                            classIdx = idx,
                            userIdx = userIdx.idx,
                            writeDate = DateTime.Now,
                            delDate = DateTime.Now,

                        };

                        db.orderClassDetail.Add(_insert);


                        db.SaveChanges(); // 실제로 저장 
                        #endregion



                        sb.AppendFormat("$('#ck').val('Y');");
                        sb.AppendFormat("$('#classBtn').addClass('active');");
                        sb.AppendFormat("$('#classBtn').html('클래스 신청완료');");
                        sb.AppendFormat("demo.showSwal('success','0','클래스가 신청되었습니다.');");
                        sb.AppendFormat("$('#reviewWrite').html('<span type=button class=btn style=border-radius:4px; onclick=goreviewWrite("+idx+")> 후기 쓰기 </span>');");
                        sb.AppendFormat("$('#reviewWrite span').addClass('btn-secondary');");

                        string _msg = userIdx.userName + "님," + clName.className + "클래스 신청이 완료 되었습니다. 마이페이지에서 수강내역 확인 가능하십니다!😊";
                        string _uTel = userIdx.userTel;


                        //sms 전송
                        sms_send(_msg, _uTel);

                        // 클래스 행사 전 안내문자  (1일 전 오전 10:00) 
                        //DateTime beforeOneDay = DateTime.Today.AddDays(-1);

                        DateTime startTimeSet = startTime.AddDays(-1);


                        if (startTimeSet.Hour == 10 && startTimeSet.Minute == 00)
                        {
                            sms_send_before_oneday(_msg, _uTel);
                        }


                    }
                    else
                    {
                        #region 삭제

                        orderClassDetail doc_del = (from a in db.orderClassDetail where a.classIdx == idx && a.userIdx == userIdx.idx select a).FirstOrDefault();
                        db.orderClassDetail.Remove(doc_del);
                        db.SaveChanges();

                        var msg = SmartFactory.Util.msg.msg_del;

                        #endregion
                        sb.AppendFormat("$('#ck').val('N');");
                        sb.AppendFormat("$('#classBtn').removeClass('active');");
                        sb.AppendFormat("$('#classBtn').html('클래스 신청');");
                        sb.AppendFormat("demo.showSwal('fail','0','신청이 해제되었습니다.');");
                        sb.AppendFormat("$('#reviewWrite').html('<span type=button class=btn style=border-radius:4px; onclick=alertreviewWrite()> 후기 쓰기 </span>');");
                        sb.AppendFormat("$('#reviewWrite span').addClass('btn-secondary');");

                    }



                }
                else
                {
                    //sweetAlert 이용 

                    sb.AppendFormat("$('#ck').val('N');");
                    sb.AppendFormat("demo.showSwal('needPay','0','정기결제가 필요합니다.');");



                }
            }
            else
            {
                sb.AppendFormat("$('#ck').val('N');");
                sb.AppendFormat("demo.showSwal('needPay','0','정기결제가 필요합니다.');");

            }

            sb.AppendFormat("</script>");




            Response.WriteAsync(sb.ToString());



            return null;
        }


        public void sms_send(string _msg, string _uTel)
        {


            // POST, GET 보낼 데이터 입력
            string strUri = "http://sms.nanuminet.com/utf8.php";
            StringBuilder dataParams = new StringBuilder();
            string _now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            dataParams.Append("sms_id=leeyw94&");
            dataParams.Append("sms_pw=blueeye0037!&");
            dataParams.Append("callback=070-8244-8202&"); // 발신자 
            dataParams.Append("senddate=" + _now + "&");
            //dataParams.Append("return_url=http://desco.theblueeye.com/sys/sms_end&");
            dataParams.Append("return_data=&");
            dataParams.Append("use_mms=N&"); // text길어지면 Y로 변경 
            dataParams.Append("upFile=&");
            dataParams.Append("phone[]=" + _uTel + "&"); // 수신자 번호 추후변경
            //dataParams.Append("phone[]=010-3948-1930&"); // 테스트 
            dataParams.Append("msg[]=" + _msg + "&");




            // 요청 String -> 요청 Byte 변환
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            /* POST */

            // HttpWebRequest 객체 생성, 설정

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri);

            request.Method = "POST";    // 기본값 "GET"

            request.ContentType = "application/x-www-form-urlencoded";

            request.ContentLength = byteDataParams.Length;

            Stream stDataParams = request.GetRequestStream();

            stDataParams.Write(byteDataParams, 0, byteDataParams.Length);
            //core 추가 시작===================================
            var response = (HttpWebResponse)request.GetResponse();
            //core 추가 끝===================================
            stDataParams.Close();


        }

        public void sms_send_before_oneday(string _msg, string _uTel)
        {


            // POST, GET 보낼 데이터 입력
            string strUri = "http://sms.nanuminet.com/utf8.php";
            StringBuilder dataParams = new StringBuilder();
            string _now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            dataParams.Append("sms_id=leeyw94&");
            dataParams.Append("sms_pw=blueeye0037!&");
            dataParams.Append("callback=070-8244-8202&"); // 발신자 
            dataParams.Append("senddate=" + _now + "&");
            //dataParams.Append("return_url=http://desco.theblueeye.com/sys/sms_end&");
            dataParams.Append("return_data=&");
            dataParams.Append("use_mms=N&"); // text길어지면 Y로 변경 
            dataParams.Append("upFile=&");
            dataParams.Append("phone[]=" + _uTel + "&"); // 수신자 번호 추후변경
            //dataParams.Append("phone[]=010-3948-1930&"); // 테스트 
            dataParams.Append("msg[]=" + _msg + "&");




            // 요청 String -> 요청 Byte 변환
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            /* POST */

            // HttpWebRequest 객체 생성, 설정

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri);

            request.Method = "POST";    // 기본값 "GET"

            request.ContentType = "application/x-www-form-urlencoded";

            request.ContentLength = byteDataParams.Length;

            Stream stDataParams = request.GetRequestStream();

            stDataParams.Write(byteDataParams, 0, byteDataParams.Length);
            //core 추가 시작===================================
            var response = (HttpWebResponse)request.GetResponse();
            //core 추가 끝===================================
            stDataParams.Close();


        }

        //#endregion




        #region 과학자회원 마이페이지
        [Authorize]

        public ActionResult ClassForSci(string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;



            var _list = db.classInfo.Where(p => p.managerIdxNavigation.userId == user_id && p.useYn !="D").Include(p => p.managerIdxNavigation).Include(p => p.categoryNavigation).Include(p => p.placeNavigation).Include(p => p.scienceCateNavigation).OrderBy(o => o.className).AsNoTracking();

            if (!string.IsNullOrEmpty(search_all))
            {

                _list = _list.Where(p => p.className.Contains(search_all) || p.categoryNavigation.codeName.Contains(search_all) || p.scienceCateNavigation.codeName.Contains(search_all) || p.placeNavigation.codeName.Contains(search_all) || p.title.Contains(search_all) || p.description.Contains(search_all) && p.useYn != "N").OrderBy(p => p.className);

            }

            var model = PagingList.Create(_list, 20, page, sortExpression, "-idx");

            ViewBag.user_id = user_id;



            return View(model);
        }
        [Authorize]
        public ActionResult classSet(classInfo doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //Select Box======================================================================================================================================================
            var category = db.code_classCategory.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.카테고리 = new SelectList(category.AsEnumerable(), "값", "이름");

            var scienceCate = db.code_scienceCategory.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.과학분야 = new SelectList(scienceCate.AsEnumerable(), "값", "이름");

            var place = db.code_classPlace.Where(p => p.useYn == "Y").OrderBy(P => P.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.장소 = new SelectList(place.AsEnumerable(), "값", "이름");

            var managerIdx = db.user.Where(p => p.useYn == "Y" && p.userClass == 3 && p.userId == user_id).OrderBy(P => P.userName).Select(c => new { 값 = c.idx, 이름 = c.userName });
            ViewBag.과학자 = new SelectList(managerIdx.AsEnumerable(), "값", "이름");

            var state = db.code_state.Where(p => p.useYn == "Y").OrderBy(P => P.codeName).Select(c => new { 값 = c.idx, 이름 = c.codeName });
            ViewBag.상태 = new SelectList(state.AsEnumerable(), "값", "이름");
            //Select Box======================================================================================================================================================


            if (idx != null)
            {
                doc = db.classInfo.Single(x => x.idx == idx);
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;

            }
            // 클래스:1 과학자:2

            int file_menu_id = 0;

            try
            {
                file_menu_id = (from a in db.file_menu where a.gubun == 1 select a.file_menu_id).FirstOrDefault();
            }
            catch
            {

            }

            var file_list = (from a in db.file_management where a.code_doc_idx == file_menu_id && a.use_yn == "Y" select a).ToList();

            ViewBag.파일리스트 = file_list;
            ViewBag.파일리스트카운트 = file_list.Count();

            return View(doc);
        }
        public IActionResult classView(classInfo doc, string sdate, string mode, int? idx, int? classIdx)
        {

            DateTime _sdate = DateTime.Now;


            if (!string.IsNullOrEmpty(sdate))
            {
                _sdate = Convert.ToDateTime(sdate);
            }

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            ViewBag.companyIdx = company_idx;
            ViewBag.department_idx = department_idx;


            if (idx != null)
            {

                doc = db.classInfo.Include(p => p.categoryNavigation).Include(p => p.placeNavigation).Include(p => p.scienceCateNavigation).Single(x => x.idx == idx);


                #region 이미지

                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.user_id = user_id;
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion

                var classPlan = db.classContents.Where(p => p.classIdx == doc.idx && p.useYn != "N").OrderByDescending(p => p.idx).ToList();
                ViewBag.클래스콘텐츠들 = classPlan;
                ViewBag.클래스콘텐츠들_c = classPlan.Count();



            }


            return View(doc);
        }

        public async Task<IActionResult> classAction(classInfo doc, int? idx, string mode_type, List<IFormFile> files, string file_count)
        {
            StringBuilder sb = new StringBuilder();

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";
            string fileId = "";
            if(doc.useYn == "on")
            {
                doc.useYn = "Y";
            }
            else
            {
                doc.useYn = "N";
            }
            if (idx == null)
            {

                #region 저장
                fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                msg = "저장";

                    doc.qBoardCate = 6;
                    doc.rBoardCate = 7;
                    doc.nBoardCate = 5;
                    doc.searchInfo = doc.scienceCate.ToString();
                    doc.writeDate = DateTime.Now;
                    doc.editDate = DateTime.Now;
                    doc.delDate = DateTime.Now;
                    doc.fileId = fileId;
                    doc.useYn = "Y";
                    db.classInfo.Add(doc);
                    await db.SaveChangesAsync();
                #endregion





                // 과학자가 클래스 등록할 경우

                //var sciCklist = db.user.Where(a => a.userId == user_id && a.useYn != "N").FirstOrDefault();
                //var sciCk = sciCklist.idx;
                //if (doc.managerIdx == sciCk)
                //{
                //    #region 클래스 생성시 자동 공지/QNA/후기 게시판들 생성      

                //    var _insert1 = new BoardMenu
                //    {
                //        title = "공지사항",
                //        BoardType_idx = 8,
                //        open_yn = "Y",
                //        userIdx = doc.nBoardCate,
                //        classIdx = doc.idx,

                //    };


                //    var _insert2 = new BoardMenu
                //    {
                //        title = "Q&A",
                //        BoardType_idx = 7,
                //        open_yn = "Y",
                //        userIdx = doc.qBoardCate,
                //        classIdx = doc.idx,
                //    };


                //    var _insert3 = new BoardMenu
                //    {
                //        title = "후기",
                //        BoardType_idx = 6,
                //        open_yn = "Y",
                //        userIdx = doc.rBoardCate,
                //        classIdx = doc.idx,
                //    };



                //    db.BoardMenu.AddRange(_insert1, _insert2, _insert3);
                //    db.SaveChanges();

                //    #endregion




                    //#region 수동 업데이트 
                    //classInfo _update =
                    //         (from a in db.classInfo where a.idx == doc.idx select a).Single();

                    //_update.nBoardCate = _insert1.idx;
                    //_update.qBoardCate = _insert2.idx;
                    //_update.rBoardCate = _insert3.idx;

                    //db.SaveChanges(); // 실제로 저장  
                    //#endregion

               // }
            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "삭제";

                    #region 수동 업데이트
                    classInfo _update2 =
                             (from a in db.classInfo where a.idx == idx select a).Single();

                    _update2.useYn = "N";
                    _update2.delDate = DateTime.Now;


                    db.SaveChanges(); // 실제로 저장 
                    #endregion
                }
                else
                {

                    #region 수정
                    fileId = doc.fileId;
                    //if (string.IsNullOrEmpty(fileId))
                    //{

                        fileId = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                        doc.fileId = fileId;
                    //}

                            doc.qBoardCate = 6;
                            doc.rBoardCate = 7;
                            doc.nBoardCate = 5;

                        msg = "수정";
                        doc.searchInfo = doc.scienceCate.ToString();
                        doc.editDate = DateTime.Now;
                        //doc.useYn = "Y";
                        db.Entry(doc).State = EntityState.Modified;
                        await db.SaveChangesAsync();
                        db.SaveChanges();
                        #endregion

                }
            }

            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int ssss = 0;
            foreach (var formFile in files)
            {
                try
                {

                    double file_size = formFile.Length;

                    int index_order_file = Convert.ToInt32(file_count.Split(',')[ssss]); // 0,2

                    if (file_size < _fileSizeLimit && file_size > 0)
                    {

                        var formFileContent =
                            await FileHelpers
                                .ProcessFormFile<IFormFile>(
                                    formFile, ModelState, _permittedExtensions,
                                    _fileSizeLimit);




                        #region 변수
                        // 변수 =========================================================================================================================
                        string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                     

                        string file_ex = ""; // 확장자

                        try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                        catch
                        {

                        }
                        var _fileName = only + "." + file_ex;     // 신규 파일 이름  




                        var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                        var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                        string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                        string ore_fileName = Path.GetFileName(formFile.FileName);
                        #endregion





                        //경로에 폴더가 없으면 만들어준다.=============================================
                        var dInfo = new DirectoryInfo(_local_path);
                        var dInfo_s = new DirectoryInfo(desiredThumbPath);
                        if (!dInfo.Exists)
                        {
                            dInfo.Create();
                        }
                        if (!dInfo_s.Exists)
                        {
                            dInfo_s.Create();
                        }
                        //=================================================================================




                        using (var fileStream = System.IO.File.Create(filePath))
                        {
                            await fileStream.WriteAsync(formFileContent);

                        }

                        if (get_word.img_check(file_ex) == "img")
                        {
                            // 세로 기준
                            ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                        }


                        #region 기존 파일 있으면 사용안함으로 변경

                        int _check_old = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a.id).Count();

                        if (_check_old > 0)
                        {
                            BoardFile _update = (from a in db.BoardFile where a.Md_id == fileId && a.index_order == index_order_file && a.use_yn == "Y" select a).FirstOrDefault();

                            _update.use_yn = "N";
                            db.SaveChanges(); // 실제로 저장 
                        }

                        #endregion





                        var _insert = new BoardFile()
                        {
                            Md_id = fileId,
                            ImagePath = Models_photo + company_id + "/" + _fileName,
                            fileName = ore_fileName,
                            use_yn = "Y",
                            file_ex = file_ex,
                            file_size = file_size,
                            r_date = DateTime.Now,
                            write_id = user_id,
                            sImagePath = Models_photo + company_id + "/s/" + _fileName,
                            index_order = index_order_file
                        };

                        db.BoardFile.Add(_insert);
                        db.SaveChanges();

                    }

                }
                catch
                {

                }

                ssss++;
            }


            #endregion

            return Redirect("/mypage/ClassForSci");

        }

        public ActionResult planSet(classContents doc, int? idx, int? classIdx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion


            //if (idx != null)
            //{
            //    doc = db.classPlan.Single(x => x.idx == idx);

            //}

            if (idx != null)
            {
                doc = db.classContents.Single(x => x.idx == idx);

            }

            return View(doc);
        }




        public async Task<IActionResult> planAction(classContents doc, int? idx, string mode_type, int? classIdx, string mainYn, List<IFormFile> files)
        {
            StringBuilder sb = new StringBuilder();

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion
            string msg = "";

            string file_id = "";


            if (idx == null)
            {
                if (files.Count() > 0)
                {
                    file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    doc.fileId = file_id;
                }

                #region 저장
                msg = "저장";
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.useYn = "Y";
                doc.mainYn = mainYn;
                db.classContents.Add(doc);
                await db.SaveChangesAsync();
                #endregion


            }
            else
            {

                if (mode_type == "D")
                {
                    msg = "삭제";

                    #region 수동 업데이트
                    classContents _update2 =
                             (from a in db.classContents where a.idx == idx select a).Single();

                    _update2.useYn = "N";
                    //_update2.delDate = DateTime.Now;
                    db.SaveChanges();
                    #endregion
                }
                else
                {

                    #region 수정
                    msg = "수정";

                    #region 파일 아이디

                    if (files.Count() > 0)
                    {
                        file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                        doc.editDate = DateTime.Now;
                        doc.fileId = file_id;
                    }
                    #endregion

                    //#region 업로드 링크
                    //var link = doc.link;

                    //if (link != "")
                    //{
                    //    doc.fileId = "";
                    //    doc.link = link;
                    //}
                    //#endregion



                    // doc.editDate = DateTime.Now;
                    doc.useYn = "Y";

                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();
                    #endregion

                }
            }




            #region 파일 올리기

            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);

                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;    // 신규 파일 이름   
                    var _local_path = _targetFilePath + "/";   // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);    // 전체 경로
                    string desiredThumbPath = _local_path + "s/";   // 작은 이미지 전체 경로
                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion

                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================

                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);
                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }

                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion



            return Redirect("/mypage/classView?idx=" + classIdx + "&classIdx=" + classIdx);

        }


        #endregion







        #region 첨부파일 관련 기본 소스

        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
        private async Task fileUpload(List<IFormFile> files, string user_id, string file_id)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }
        }
        public void History_write(string user_id, string _page, string _state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }

        #endregion

        public IActionResult monthly_pap_popUp(string cmd, string goodname, int? goodprice, int? price, string recvphone, string rebillCycleType, string rebillCycleMonth, string rebillExpire, string var1, string var2)
        {
            //cmd
            ViewBag.cmd = cmd;
            //상품명
            ViewBag.goodname = goodname;
            //월정기결제 
            ViewBag.goodprice = goodprice;
            //연결제 
            ViewBag.price = price;
            //연락처#
            ViewBag.recvphone = recvphone;
            //정기결제 반복구분
            ViewBag.rebillCycleType = rebillCycleType;
            //정기결제 결제일
            ViewBag.rebillCycleMonth = rebillCycleMonth;
            //정기결제 만료일
            ViewBag.rebillExpire = rebillExpire;
            //cmd 구분
            ViewBag.var1 = var1;
            //임의변수
            ViewBag.var2 = var2;

            return View();
        }

        // 정기결제
        public ActionResult payapp_request(string cmd, string goodname, int? goodprice, int? price, string recvphone, string rebillCycleType, string rebillCycleMonth, string rebillExpire, int? mul_no, string rebill_no, string var1, string var2)
        {

            #region 기본 변수
            string user_id = User.Identity.Name;
            price = price ?? 0;
            goodprice = goodprice ?? 0;
            string pay_url3 = "";
            string url = "https://api.payapp.kr/oapi/apiLoad.html";
            string responseText = string.Empty;
            StringBuilder dataParams = new StringBuilder();
            #region 종료일 변경
            DateTime endDate = DateTime.Now;
            if (var1 == "2")
            {
                endDate = endDate.AddMonths(1);
            }
            else
            {
                endDate = endDate.AddMonths(36);
            }
            #endregion
            #endregion

            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                #region 기본 정보 저장
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    linkkey = "gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=",
                    linkval = "gOss/MdwFI1k/Qtrly5ZpxxeRLbvrLi1v5VQbFpTZYk=",
                    recvphone = recvphone,
                    var1 = var1,
                    var2 = var2,
                    payGubun = Convert.ToInt32(var1),
                    startDate = DateTime.Now,
                    endDate = endDate,
                    goodname = goodname,
                    price = Convert.ToInt32(price),
                    goodprice = Convert.ToInt32(goodprice)

                };
                db.payment_payapp.Add(_insert);
                db.SaveChanges();
                #endregion
                goodname = HttpUtility.UrlEncode(goodname);
                dataParams.Append("cmd=" + cmd + "&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("goodname=" + goodname + "&");
                dataParams.Append("recvphone=" + recvphone + "&");
                dataParams.Append("var1=" + var1 + "&");
                dataParams.Append("var2=" + var2 + "&");
                dataParams.Append("smsuse=n&");
                dataParams.Append("checkretry=y&");
                dataParams.Append("redirectpay=1&");
                dataParams.Append("openpaytype=phone,card,kakaopay,naverpay,zeropay&");
                dataParams.Append("price=" + price + "&");
                dataParams.Append("goodprice=" + goodprice + "&");               
                dataParams.Append("rebillCycleType=" + rebillCycleType + "&");
                dataParams.Append("rebillCycleMonth=" + rebillCycleMonth + "&");
                dataParams.Append("rebillExpire=" + rebillExpire + "&");
                dataParams.Append("feedbackurl=https://contactsci.theblueeye.com/mypage/payapp_feedbackurl&");
                dataParams.Append("returnurl=https://contactsci.theblueeye.com/mypage/payapp_success");


            }
            else if (cmd == "rebillCancel" || cmd == "paycancel") //결제취소시
            {
                dataParams.Append("cmd=paycancel&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                dataParams.Append("mul_no=" + mul_no + "&");
            }

            #region 데이터 전송
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";    // 기본값 "GET"
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.ContentLength = dataParams.Length;
            Stream stDataParams = webRequest.GetRequestStream();
            stDataParams.Write(byteDataParams, 0, dataParams.Length); //전송
            #endregion

            #region 데이터 응답
            using (HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse())
            {
                HttpStatusCode status = resp.StatusCode;
                Console.WriteLine(status); // status 가 정상일경우 OK가 입력된다. 

                // 응답과 관련된 stream을 가져온다.
                Stream respStream = resp.GetResponseStream();
                using (StreamReader streamReader = new StreamReader(respStream))
                {
                    responseText = streamReader.ReadToEnd(); //데이터 결과값  
                }
            }

            #endregion

            #region 데이터 후처리
            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                string[] divided = responseText.Split('&');
                var pay_url = divided[4].Split('=');
                pay_url3 = HttpUtility.UrlDecode(pay_url[1]);
                var rebill_param = divided[3].Split('=')[1];
                var result_no = 0;
                //mul_no, rebill_no 구분 저장
                switch (var1)
                {
                    case "2":
                        result_no = 0;
                        break;

                    case "3":
                        result_no = Convert.ToInt32(rebill_param);
                        rebill_no = null;
                        break;
                }

                payment_payapp _update = (from a in db.payment_payapp where a.var2 == var2 select a).OrderByDescending(a => a.writeDate).FirstOrDefault();
                _update.payurl = pay_url3;
                _update.rebill_no = rebill_param;
                _update.mul_no = result_no;

                db.SaveChanges();
                stDataParams.Close();
            }
            else //결제 취소시
            {
                if (cmd == "rebillCancel") //정기결제 해지 후에 결제 취소 진행
                {
                    stDataParams.Close();
                    dataParams = new StringBuilder(); //파라미터 초기화
                    dataParams.Append("cmd=rebillCancel&");
                    dataParams.Append("userid=hellodd5005&");
                    dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                    dataParams.Append("mul_no=" + mul_no + "&");
                    dataParams.Append("rebill_no=" + rebill_no + "&");
                    byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
                    webRequest = (HttpWebRequest)WebRequest.Create(url);
                    webRequest.Method = "POST";    // 기본값 "GET"
                    webRequest.ContentType = "application/x-www-form-urlencoded";
                    webRequest.ContentLength = dataParams.Length;
                    stDataParams = webRequest.GetRequestStream();
                    stDataParams.Write(byteDataParams, 0, dataParams.Length);
                    stDataParams.Close();
                }
                else
                {
                    stDataParams.Close();
                }

                return Redirect("/mypage/purchaseDetails");
            } 
            #endregion

            return Redirect(pay_url3);
        }

        // 정기결제 해지
        public ActionResult payapp_cancle_1m(string cmd, string userid, string linkkey, string rebill_no, string var2)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            //var _split0 = var2.Split('_')[0];
            var rebill_n = (from a in db.payment_payapp where a.var2 == var2 select a.rebill_no).FirstOrDefault();

            string url = "https://api.payapp.kr/oapi/apiLoad.html";
            string responseText = string.Empty;
            StringBuilder dataParams = new StringBuilder();
            dataParams.Append("cmd=" + cmd + "&");
            dataParams.Append("userid=" + userid + "&");
            dataParams.Append("rebill_no=" + rebill_n + "&");
            dataParams.Append("linkkey=" + linkkey + "&");
            dataParams.Append("feedbackurl=https://contactsci.theblueeye.com/mypage/payapp_feedbackurl&");

            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";    // 기본값 "GET"

            webRequest.ContentType = "application/x-www-form-urlencoded";

            webRequest.ContentLength = dataParams.Length;

            Stream stDataParams = webRequest.GetRequestStream();

            stDataParams.Write(byteDataParams, 0, dataParams.Length);

            // 응답 받기
            using (HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse())
            {
                HttpStatusCode status = resp.StatusCode;
                Console.WriteLine(status); // status 가 정상일경우 OK가 입력된다. 

                // 응답과 관련된 stream을 가져온다.
                Stream respStream = resp.GetResponseStream();
                using (StreamReader streamReader = new StreamReader(respStream))
                {
                    responseText = streamReader.ReadToEnd();

                    #region 수동 업데이트


                    payment_payapp _update =
                             (from a in db.payment_payapp where a.var2 == var2 select a).FirstOrDefault();

                    _update.pay_state = 8; // 취소요청
                    _update.canceldate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");


                    db.SaveChanges(); // 실제로 저장  
                    #endregion

                }
            }
            stDataParams.Close();

            string url11 = "/mypage/purchaseDetails";
            return Redirect(url11);
        }


    }
}
