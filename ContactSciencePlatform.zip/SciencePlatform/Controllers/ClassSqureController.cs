﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using static SciencePlatform.Controllers.AccountController;

namespace SciencePlatform.Controllers
{
    public class ClassSqureController : Controller
    {

        private readonly db_e db = new db_e();

        private readonly ILogger<ClassSqureController> _logger;

        public ClassSqureController(ILogger<ClassSqureController> logger)
        {
            _logger = logger;
        }

        // 클래스 상세페이지
        public IActionResult classInfo(classInfo doc, string sdate, string mode, int? idx, int? classIdx, int? cate, int? Bidx, int? typeIdx, string view, string write)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;

            #endregion



            DateTime _sdate = DateTime.Now;


            if (!string.IsNullOrEmpty(sdate))
            {
                _sdate = Convert.ToDateTime(sdate);
            }

          

            if (idx != null)
            {

                doc = db.classInfo.Where(p => p.useYn != "D").Include(p => p.categoryNavigation).Include(p => p.managerIdxNavigation).Include(p => p.placeNavigation).Include(p => p.scienceCateNavigation).Single(x => x.idx == idx);
                var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();

                #region 이미지

                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

                ViewBag.user_id = user_id;
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count();
                #endregion

                var classPlan = db.classPlan.Where(p => p.classIdx == doc.idx && p.useYn != "N").OrderBy(p => p.planWeek).ToList();
                ViewBag.운영계획 = classPlan;
                ViewBag.운영계획_c = classPlan.Count();


                var _list2 = db.classInfo.Where(p => p.useYn != "D" && p.managerIdx == doc.managerIdx).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.idx).ToList();        
                ViewBag.과학자클래스들 = _list2;

                // 관심클래스 체크 여부 
                var _list3 = db.classFavorite.Where(p => p.classIdx == idx && p.userIdx == userIdx).Count();
                if(_list3 > 0)
                {
                    ViewBag.관심 = "Y";
                }
                else
                {
                    ViewBag.관심 = "N";
                }

                // 클래스 신청 체크 여부 
                var _listc = db.orderClassDetail.Where(p => p.classIdx == idx && p.userIdx == userIdx).Count();
                if (_listc > 0)
                {
                    ViewBag.신청 = "Y";
                }
                else
                {
                    ViewBag.신청 = "N";
                }


                // 공지사항 & 질의응답 & 후기게시판
                // classIdx , bordeTpye_idx 구분해서 게시판리스트 뿌리기

                var _query = db.BoardList.Where(a => a.useable != "N").Include(p => p.BM_idxNavigation.classIdxNavigation).Include(p => p.BM_idxNavigation);
              
                var _Blist1 = _query.Where(a => a.BM_idx == 5 && a.classIdx == doc.idx).OrderByDescending(a => a.writeDate).AsNoTracking();
                ViewBag.공지사항 = _Blist1;
                ViewBag.query_c1 = _Blist1.Count();

                // 관리자 승인후 보여지게 -> mainYn=="Y"
                var _Blist2 = _query.Where(a => a.BM_idx == 6 && a.classIdx == doc.idx).OrderByDescending(a => a.writeDate).AsNoTracking();
                ViewBag.QNA = _Blist2;
                ViewBag.query_c2 = _Blist2.Count();

                var _Blist3 = _query.Where(a => a.BM_idx == 7 && a.classIdx == doc.idx).OrderByDescending(a => a.writeDate).AsNoTracking();
                ViewBag.후기 = _Blist3;


                // 신청한 클래스인지 카운트
                var orderCk = db.orderClassDetail.Where(a => a.classIdx == idx && a.userIdx == userIdx && a.useYn != "N").ToList();
                ViewBag.신청여부c = orderCk.Count();


                ViewBag.query_c3 = _Blist3.Count();
                
                if(cate != null && Bidx != null)
                {
                    var _view = db.BoardList.Where(a => a.BM_idx == cate && a.idx == Bidx && a.useable == "Y").FirstOrDefault();
                    ViewBag.게시물 = _view;
                }

                int file_menu_id = 0;

                try
                {
                    file_menu_id = (from a in db.file_menu where  a.gubun == 1 select a.file_menu_id).FirstOrDefault();
                }
                catch
                {

                }

                var file_list = (from a in db.file_management where a.code_doc_idx == file_menu_id  select a).ToList();

                ViewBag.파일리스트 = file_list;
                ViewBag.파일리스트카우트 = file_list.Count();

                ViewBag.과학자프로필 = file_list.OrderByDescending(p => p.idx).Take(1);

                if(doc.managerIdx == userIdx)
                {
                    ViewBag.과학자권한 = "Y";
                }
                else
                {
                    ViewBag.과학자권한 = "N";
                }

                // 클래스 관련 콘텐츠들  
                var classContents = db.classContents.Include(a => a.classIdxNavigation).Where(a => a.useYn != "N" && a.classIdxNavigation.useYn == "Y" && a.classIdxNavigation.state != 0 && a.classIdx == idx && (a.link != null || a.fileId != null)).OrderByDescending(a => a.writeDate).ToList();

                ViewBag.관련콘텐츠들 = classContents.ToList();
                ViewBag.관련콘텐츠들_c = classContents.Count();

                var mainCk = classContents.Where(a => a.mainYn == "Y").OrderByDescending(a => a.editDate).FirstOrDefault();
                ViewBag.메인콘텐츠 = mainCk;
                ViewBag.메인콘텐츠_c = mainCk;

            }


            return View(doc);
        }

       

      
        public IActionResult newC(classInfo doc, string tab_id)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            ////분야별 찾기
            //var _list = (from a in db.code_scienceCategory select a).OrderBy(p => p.idx).ToList();
            //ViewBag.선택리스트 = _list;


            //신규 등록된 클래스 - 1달에 4개+ 운영예정, 매주 1나씩 업로드??
            //DateTime MonthFirstDay = DateTime.Now.AddDays(1 - DateTime.Now.Day);  // 이번달 첫째날
            //DateTime MonthLastDay = MonthFirstDay.AddMonths(1).AddDays(-1);  // 이번달 마지막날   
            //var _list2 = db.classInfo.Where(p => p.useYn != "N" && p.state != 3  && MonthFirstDay <= p.startDate && p.endDate <= MonthLastDay).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.idx).ToList();

            //DateTime nowDt = DateTime.Now;

            //ViewBag.신규클래스나머지 = "";
            //for (int i = 1; i < 6; i++)
            //{
            //    if (nowDt.DayOfWeek == DayOfWeek.Monday) // 매주 월요일 
            //    {
            //        ViewBag.신규클래스나머지 = _list2.Skip(4).ToList();
            //    }
            //}

            //ViewBag.신규클래스나머지c = _list2.Skip(4).ToList().Count();


            var _list2 = db.classInfo.Where(p => p.useYn == "Y" && p.state != 3 && DateTime.Now.Year == p.startDate.Year && DateTime.Now.Month == p.startDate.Month).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.idx).ToList();
            ViewBag.신규클래스4 = _list2;



            // 클래스 관련 콘텐츠 
            var classContents = db.classContents.Where(a => a.useYn != "N" && a.classIdxNavigation.useYn != "N" && a.classIdxNavigation.state != 3 &&
                                DateTime.Now.Year == a.classIdxNavigation.startDate.Year && a.classIdxNavigation.endDate.Month == DateTime.Now.Month).Include(a => a.classIdxNavigation).OrderByDescending(a => a.writeDate).ToList();

            ViewBag.관련콘텐츠들 = classContents.ToList();
            ViewBag.관련콘텐츠들_c = classContents.Count();


            // 예정된 클래스 
            var _listNext = db.classInfo.Where(p => p.useYn == "Y" && p.state != 3 && p.startDate.Year >= DateTime.Now.Year && p.startDate.Month >= DateTime.Now.AddMonths(1).Month).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.idx).ToList();
            ViewBag.예정된클래스 = _listNext.ToList();
            ViewBag.예정된클래스c = _listNext.Count();


            //분야별 찾기
            var _list = db.code_scienceCategory.Where(a => a.useYn != "N").OrderBy(p => p.idx).ToList();
            ViewBag.선택리스트 = _list;



            return View(_list2);
        }


        // 정기 클래스
        public ActionResult regularC()
        {
            var _list = (from a in db.classInfo where a.useYn != "N" && a.classType == 1 select a).Include(p => p.categoryNavigation).Include(p => p.scienceCateNavigation).Include(p => p.placeNavigation).Include(p => p.ageNavigation).Include(p => p.managerIdxNavigation).OrderBy(p => p.idx).ToList();
            ViewBag.정기클래스All = _list;
            
            //카테고리 분류
            var _list1 = (from a in db.code_classCategory select a).OrderBy(p => p.idx).ToList();
            ViewBag.카테고리 = _list1;


            //과학분야
            var _list2 = db.code_scienceCategory.Where(a => a.useYn != "N").OrderBy(p => p.idx).ToList();
            ViewBag.과학분야 = _list2;


            //장소
            var _list3 = (from a in db.code_classPlace select a).OrderBy(p => p.idx).ToList();
            ViewBag.장소 = _list3;

            //연령
            var _list4 = (from a in db.code_classAges select a).OrderBy(p => p.idx).ToList();
            ViewBag.연령 = _list4;

            return View(_list);
        }



        // 비정기 클래스
        public IActionResult irregularC()
        {

            var _list = (from a in db.classInfo where a.useYn != "N" && a.period == 0 select a).Include(p => p.categoryNavigation).Include(p => p.scienceCateNavigation).Include(p => p.placeNavigation).Include(p => p.ageNavigation).Include(p => p.managerIdxNavigation).OrderBy(p => p.idx).ToList();


            //카테고리 분류
            var _list1 = (from a in db.code_classCategory select a).OrderBy(p => p.idx).ToList();
            ViewBag.카테고리 = _list1;


            //과학분야
            var _list2 = (from a in db.code_scienceCategory select a).OrderBy(p => p.idx).ToList();
            ViewBag.과학분야 = _list2;


            //장소
            var _list3 = (from a in db.code_classPlace select a).OrderBy(p => p.idx).ToList();
            ViewBag.장소 = _list3;

            //연령
            var _list4 = (from a in db.code_classAges select a).OrderBy(p => p.idx).ToList();
            ViewBag.연령 = _list4;


            return View(_list);
        }






       

    }
}
