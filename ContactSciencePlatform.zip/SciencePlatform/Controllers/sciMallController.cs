﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SciencePlatform.Controllers
{
    public class sciMallController : Controller
    {
        //private readonly ILogger<IntroController> _logger;
        private readonly db_e db = new db_e();
        //public sciMallController(ILogger<IntroController> logger)
        //{
        //    _logger = logger;
        //}

        public IActionResult sciMall(productInfo doc, string cate)
        {


            return View();
        }

        public IActionResult exKits()
        {
            return View();
        }
        public IActionResult codingKits()
        {
            return View();
        }
        public IActionResult mathKits()
        {
            return View();
        }

        public IActionResult sciGoods()
        {
            return View();
        }


        public IActionResult contents()
        {
            return View();
        }

        //상품 상세페이지
        public IActionResult proDetail(int? idx)
        {
            #region 로그인 정보
            string user_id = User.Identity.Name ?? "";
            #endregion


            ViewBag.userId = user_id;

            var _list2 = (from a in db.productInfo select a).OrderBy(p => p.idx).ToList();
            ViewBag.상품정보 = _list2;

            var codeOption = db.codeOption.Where(p => p.productIdx == idx).Select(c => new { 값 = c.idx, 이름 = c.codeName+" (+"+c.price.ToString("###,###")+"원)" });
            ViewBag.옵션 = new SelectList(codeOption.AsEnumerable(), "값", "이름");

            return View();
        }

        // proDetail 페이지에서 상품옵션 선택시 보여주기
        public ActionResult option_check(int doc_it, int oriP)
        {
            var sb = new StringBuilder();

            string name = "";
            int price = 0;

            var _list = (from a in db.codeOption where a.idx == doc_it select a);
            sb.AppendFormat("<script>");
          
           if(_list.Count() > 0)
            {
                name = _list.FirstOrDefault().codeName;
                price = _list.FirstOrDefault().price + oriP;
                string won = string.Format("{0:#,##0}", price); // 숫자단위 변환



                sb.AppendFormat("$('#productName').html('" + name + "') ;");
                sb.AppendFormat("$('.totalPrice').html('" + won + "') ;");
                sb.AppendFormat("$('#totalPrice').html('" + won + "') ;");
                sb.AppendFormat("$('#optionPrice').val('" + _list.FirstOrDefault().price + "') ;");
            }              
                       
            sb.AppendFormat("</script>");



            Response.WriteAsync(sb.ToString());


            return null;
        }






        //장바구니 
        public IActionResult proCart(int userIdx)
        // idx : 카트idx, p_idx : 제품idx, o_idx:상품옵션idx, qty: 개수, userIdx : 유저정보
        {
            var _list = db.productCart.Include(p => p.productIdxNavigation)
                .Where(p => p.userIdx == userIdx).OrderBy(p => p.productIdx).ThenBy(p => p.idx).ToList();
            ViewBag.userIdx = userIdx;
            return View(_list);
        }

        public IActionResult modQty(productCart doc, int idx, int qty, int userIdx)
        {
            StringBuilder sb = new StringBuilder();

            doc = db.productCart.Where(p => p.idx == idx).FirstOrDefault();

            doc.qty = qty;

            doc.writeDate = DateTime.Now;
            db.SaveChanges();

            var productPrice = db.codeOption.Where(p => p.idx == doc.optionIdx).Select(p => p.price).FirstOrDefault();

            var oriPrice = doc.price;

            var sumPrice = "";
            if (productPrice != 0) // 옵션이 있으면
            {
                sumPrice = Convert.ToInt32(qty * doc.price).ToString("###,###");
            }
            else
            {
                sumPrice = Convert.ToInt32(qty * oriPrice).ToString("###,###");


            }


            var userCart = db.productCart.Where(p => p.userIdx == userIdx && p.useYn == "C").ToList(); //장바구니 내역            

            var _temp = 0;
            foreach (var item in userCart)
            {
                _temp += item.qty * item.price;
            }

            var totalPrice = _temp;
            var deliverPrice = totalPrice + 3000;

            sb.AppendFormat("<script>");
            sb.AppendFormat("$('#price_" + idx + "').html('" + sumPrice + "');");
            sb.AppendFormat("$('#sumPrice').html('" + totalPrice.ToString("###,###") + "');");
            sb.AppendFormat("$('#totalPrice').html('" + deliverPrice.ToString("###,###") + "');");
            sb.AppendFormat("</script>");


            Response.WriteAsync(sb.ToString());

            return null;
        }

        public IActionResult modCheck(productCart doc, int idx, string check, int userIdx)
        {
            StringBuilder sb = new StringBuilder();
            var allCheck = db.productCart.Where(p => p.userIdx == userIdx).ToList();
            if (check == "A")
            {
                foreach (var item in allCheck)
                {
                    item.useYn = "C";
                    item.writeDate = DateTime.Now;
                }
            }
            else if (check == "AN")
            {
                foreach (var item in allCheck)
                {
                    item.useYn = "N";
                    item.writeDate = DateTime.Now;
                }
            }
            else
            {
                doc = db.productCart.Where(p => p.idx == idx).FirstOrDefault();
                doc.writeDate = DateTime.Now;
                doc.useYn = check;
            }
            db.SaveChanges();

            var productPrice = 0;
            if (doc.optionIdx == 0)
            {
                productPrice = db.productInfo.Where(p => p.idx == doc.productIdx).Select(p => p.price).FirstOrDefault();
            }
            else
            {
                //productPrice = db.codeOption.Where(p => p.idx == doc.optionIdx).Select(p => p.price).FirstOrDefault();
                productPrice = db.productCart.Where(p=>p.idx == idx).Select(p => p.price).FirstOrDefault();
            }
            

            var sumPrice = Convert.ToInt32(doc.qty * productPrice).ToString("###,###");
            var userCart = db.productCart.Where(p => p.userIdx == userIdx && p.useYn == "C").ToList(); //장바구니 내역            

            var _temp = 0;
            foreach (var item in userCart)
            {
                _temp += item.qty * item.price;
            }

            var totalPrice = _temp;
            var deliverPrice = totalPrice + 3000;

            sb.AppendFormat("<script>");
            sb.AppendFormat("$('#price_" + idx + "').html('" + sumPrice + "');");
            sb.AppendFormat("$('#sumPrice').html('" + totalPrice.ToString("###,###") + "');");
            sb.AppendFormat("$('#totalPrice').html('" + deliverPrice.ToString("###,###") + "');");
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
        }

        public IActionResult proCartAction(productCart doc, int? idx, int p_idx, int o_idx, int qty, int userIdx, string del, int mod)
        {// idx : 카트idx, p_idx : 제품idx, o_idx:상품옵션idx, qty: 개수, userIdx : 유저정보
            if (del == "D")
            {
                productCart doc_del = db.productCart.Single(x => x.idx == idx);
                db.productCart.Remove(doc_del);
                db.SaveChanges();
                return null;
            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("<script>");
            var productInfo = db.productInfo.Where(p => p.idx == p_idx).FirstOrDefault();
            var option = db.codeOption.Include(p => p.productIdxNavigation).Where(p => p.idx == o_idx);
            var optionIdx = 0;
            var optionPrice = 0;
           
            var userId = db.user.Where(p => p.idx == userIdx).FirstOrDefault();
            var cartCount = db.productCart.Where(p => p.productIdx == p_idx && p.userIdx == userIdx);
            if (option.Count() > 0)
            {
                optionIdx = option.Select(p => p.idx).FirstOrDefault();
                optionPrice = option.Select(p => p.price).FirstOrDefault();
                cartCount = cartCount.Where(p => p.optionIdx == o_idx);
            }
            if (userIdx == 0)
            {
                sb.AppendFormat("swalAlert(1)");
            }
            else
            {
                if (cartCount.Count() == 0)
                {
                    if (option.Count() > 0)
                    {
                        doc.price = (productInfo.price + optionPrice);
                    }
                    else
                    {
                        doc.price = productInfo.price;
                    }
                    doc.productIdx = p_idx;
                    doc.userIdx = userIdx;
                    doc.optionIdx = o_idx;
                    doc.qty = qty;                    
                    doc.writeDate = DateTime.Now;
                    db.productCart.Add(doc);
                    db.SaveChanges();
                }
                else
                {
                    var _productCart = db.productCart.Where(p => p.productIdx == p_idx && p.userIdx == userIdx);
                    if (option.Count() > 0)
                    {
                        _productCart = _productCart.Where(p => p.optionIdx == o_idx);
                        if (_productCart.FirstOrDefault().productIdx == p_idx && _productCart.FirstOrDefault().optionIdx == o_idx)
                        {
                            _productCart.FirstOrDefault().qty = _productCart.FirstOrDefault().qty + qty;
                            _productCart.FirstOrDefault().price = (productInfo.price + optionPrice);
                        }
                    }
                    else
                    {
                        _productCart.FirstOrDefault().qty = _productCart.FirstOrDefault().qty + qty;
                        _productCart.FirstOrDefault().price = productInfo.price;
                    }
                    

                    _productCart.FirstOrDefault().writeDate = DateTime.Now;
                    db.SaveChanges(); // 실제로 저장  
                }
                sb.AppendFormat("swalAlert(2,"+userIdx+")");


            }

            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());

            return null;
        }


        //주문/결제
        public ActionResult proPayment(int p_idx, int? o_idx, int userIdx, int qty, string cart, int price)
        {
            ViewBag.user = userIdx;
            var cartList = db.productCart.Include(p => p.productIdxNavigation)
                .Where(p => p.userIdx == userIdx && p.useYn == "C").OrderBy(o => o.idx).ToList();
            ViewBag.상품 = cartList;
            var proList = db.productInfo.Where(p => p.idx == p_idx).FirstOrDefault();
            #region 상품갯수
            int _qty = cartList.Count() - 1;
            string textQty = "";
            if (cart != "N")
            {
                if (_qty > 0)
                {
                    textQty = " 외 " + _qty + "개";
                }
                else if (_qty == 0)
                {
                    textQty = _qty + "개";
                }
                ViewBag.상품명 = cartList.Select(p => p.productIdxNavigation.productName).FirstOrDefault() + textQty;

            }
            else
            {
                textQty = qty + "개";
                ViewBag.갯수 = qty;
                //옵션o
                if (o_idx != null)
                {
                    var optList = db.codeOption.Where(p => p.idx == o_idx).Include(p => p.productIdxNavigation).FirstOrDefault();
                    ViewBag.가격 = ((optList.price + proList.price) * qty).ToString("###,###");
                    ViewBag.상품명 = optList.productIdxNavigation.productName + textQty;
                    ViewBag.옵션 = optList.codeName;
                    ViewBag.옵션idx = optList.idx;
                }
                //옵션x
                else
                {
                    ViewBag.가격 = (proList.price * qty).ToString("###,###");
                    ViewBag.상품명 = proList.productName + textQty;
                    ViewBag.옵션 = "N";
                }
                ViewBag.구매상품 = proList;

            }

            #endregion


            ViewBag.합계 = price;
         

            var mainUser = db.deliveryList.Where(p => p.mainYn == "Y" && p.userIdx == userIdx && p.useYn == "Y");
            if(mainUser.Count() > 0)
            {
                ViewBag.userName = mainUser.FirstOrDefault().userName;
                ViewBag.userTel = mainUser.FirstOrDefault().userTel;
                ViewBag.userAddr = mainUser.FirstOrDefault().userAddr;
                ViewBag.addrDetail = mainUser.FirstOrDefault().addrDetail;
                ViewBag.zipNo = mainUser.FirstOrDefault().zipNo;
                ViewBag.sendIdx = mainUser.FirstOrDefault().idx;
            }
           

            return View();
        }

        //주소록 찾기
        public ActionResult jusoPopup()
        {
            return View();
        }
        public ActionResult jusoPopup2()
        {
            return View();
        }
        public ActionResult modAddr(int? idx, int? mode_type, string userName, string userTel, string userAddr, string addrDetail, string zipNo, int userIdx)
        {
            var sb = new StringBuilder();

            sb.AppendFormat("<script>");
            if (idx == null)
            {
                sb.AppendFormat("$('#addrModal').modal('hide');");
            }
            else
            {
                if (mode_type == 2)
                {
                    var non_choice = db.deliveryList.Where(x => x.idx != idx && x.userIdx == userIdx && x.useYn != "N").ToList();
                    foreach (var item in non_choice)
                    {
                        item.mainYn = "N";
                    }
                    db.SaveChanges();

                    deliveryList doc_choice = db.deliveryList.Single(x => x.idx == idx);
                    doc_choice.mainYn = "Y";
                    doc_choice.writeDate = DateTime.Now;
                    db.SaveChanges();

                    
                    //sb.AppendFormat("$('.modal-backdrop.fade.in').remove();");
                    sb.AppendFormat("$('#addrModal').modal('hide');");
                    sb.AppendFormat("$('#userName').val('" + doc_choice.userName + "');");
                    sb.AppendFormat("$('#userTel').val('" + doc_choice.userTel + "');");
                    sb.AppendFormat("$('#userAddr').val('" + doc_choice.userAddr + "');");
                    sb.AppendFormat("$('#addrDetail').val('" + doc_choice.addrDetail + "');");
                    sb.AppendFormat("$('#zipNo').val('" + doc_choice.zipNo + "');");
                    sb.AppendFormat("$('#sendIdx').val('" + doc_choice.idx + "');");
                    sb.AppendFormat("location.reload();");
                }
                //삭제
                else if (mode_type == 3)
                {
                    deliveryList doc_del = db.deliveryList.Single(x => x.idx == idx);
                    doc_del.useYn = "N";
                    doc_del.writeDate = DateTime.Now;
                    db.SaveChanges();
                    sb.AppendFormat("$('#modal_"+idx+"').remove();");
                }
                else if (mode_type == 1)
                {
                    //수정
                    deliveryList doc_choice1 = db.deliveryList.Single(x => x.idx == idx);
                    doc_choice1.userAddr = userAddr;
                    doc_choice1.addrDetail = addrDetail;
                    doc_choice1.zipNo = zipNo;
                    db.SaveChanges();
                    //sb.AppendFormat("$('.modal-backdrop.fade.in').remove();");
                    sb.AppendFormat("$('#setModal').modal('show');");
                    sb.AppendFormat("$('#setIdx').val('" + idx + "');");
                    sb.AppendFormat("$('#setName').val('" + doc_choice1.userName + "');");
                    sb.AppendFormat("$('#setTel').val('" + doc_choice1.userTel + "');");
                    sb.AppendFormat("$('#twouserAddr').val('" + userAddr + "');");
                    sb.AppendFormat("$('#twoaddrDetail').val('" + addrDetail + "');");
                    sb.AppendFormat("$('#twozipNo').val('" + zipNo + "');");

                }
            }
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
        }

        public ActionResult deliveryAction(deliveryList doc, int?idx, int?setIdx, string setName, string setTel, string twouserAddr, string twoaddrDetail, int userIdx, string twozipNo)
        {
            var sb = new StringBuilder();
            sb.AppendFormat("<script>");
            if (idx == null) // 등록
            {
                string deliverId = "modal_first";
                var deliverLast = db.deliveryList.Where(p => p.userIdx == userIdx && p.useYn !="N");
                if (deliverLast.Count() > 0)
                {
                    deliverId = "modal_" + deliverLast.OrderByDescending(p => p.idx).Select(p => p.idx).FirstOrDefault();
                }
                #region 저장
                doc.userName = setName;
                doc.userTel = setTel;
                doc.userAddr = twouserAddr;
                doc.addrDetail = twoaddrDetail;
                doc.userIdx = userIdx;
                doc.useYn = "Y";
                doc.writeDate = DateTime.Now;
                doc.mainYn = "N";
                doc.zipNo = twozipNo;
                db.deliveryList.Add(doc);
                db.SaveChanges();
                #endregion         
                
                sb.AppendFormat("$('#"+deliverId+ "').after('<div class=modal-body id=modal_" + doc.idx + "><table><tr><td><input type=hidden id=mainYn_" + doc.idx + "name=mainYn/><label class=control-label><span id=userName_" + doc.idx + ">" + doc.userName + "</span></label></td></tr><tr><td><span id=userTel_" + doc.idx + ">" + doc.userTel + "</span></td></tr><tr><td><span id=userAddr_" + doc.idx + ">" + doc.userAddr + "</span><span id=addrDetail_" + doc.idx + ">" + doc.addrDetail + "</span></td></tr><tr><td>&nbsp</td></tr><tr><td><span class=btn id=editBtn_" + doc.idx + " style=width:60px onclick=goPopup(1," + doc.idx + ") data-dismiss=modal>수정</span><span class=btn id=delBtn_" + doc.idx + " style=width:60px onclick=modAddr(" + doc.idx + ",3)>삭제</span></td><td class=col-md-2><span class=btn id=choiceBtn_" + doc.idx + " style=width:60px onclick=choiceAddr(" + doc.idx + ",2," + doc.userIdx + ")>선택</span></td></tr></table></div>');");
                sb.AppendFormat("$('#editBtn_" + doc.idx + "').addClass('btn-warning');");
                sb.AppendFormat("$('#delBtn_" + doc.idx + "').addClass('btn-danger');");
                sb.AppendFormat("$('#choiceBtn_" + doc.idx + "').addClass('btn-success');");
            }
            else // 수정
            {
                var delivery = (from a in db.deliveryList where a.idx == idx select a).Single();
                delivery.userName = setName;
                delivery.userTel = setTel;
                delivery.zipNo = twozipNo;
                delivery.userAddr = twouserAddr;
                delivery.addrDetail = twoaddrDetail;
                db.SaveChanges();
                sb.AppendFormat("$('#modal_"+ delivery.idx + "').html('<table><tr><td><input type=hidden id=mainYn_" + delivery.idx + " name=mainYn/><label class=control-label><span id=userName_" + delivery.idx + ">" + delivery.userName + "</span></label></td></tr><tr><td><span id=userTel_" + delivery.idx + ">" + delivery.userTel + "</span></td></tr><tr><td><span id=userAddr_" + delivery.idx + ">" + delivery.userAddr + "</span><span id=addrDetail_" + delivery.idx + ">" + delivery.addrDetail + "</span></td></tr><tr><td>&nbsp</td></tr><tr><td><span class=btn id=editBtn_" + delivery.idx + " style=width:60px onclick=goPopup(1," + delivery.idx + ") data-dismiss=modal>수정</span><span class=btn id=delBtn_" + delivery.idx + " style=width:60px onclick=modAddr(" + delivery.idx + ",3)>삭제</span></td><td class=col-md-2><span class=btn id=choiceBtn_" + delivery.idx + " style=width:60px onclick=choiceAddr(" + delivery.idx + ",2," + delivery.userIdx + ")>선택</span></td></tr></table>');");
                sb.AppendFormat("$('#editBtn_" + delivery.idx + "').addClass('btn-warning');");
                sb.AppendFormat("$('#delBtn_" + delivery.idx + "').addClass('btn-danger');");
                sb.AppendFormat("$('#choiceBtn_" + delivery.idx + "').addClass('btn-success');");
            }

            //sb.AppendFormat("$('.modal-backdrop.fade.in').remove();");
            sb.AppendFormat("$('#setModal').modal('hide');");
            sb.AppendFormat("$('#addrModal').modal('show');");
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
            //return Redirect("/sciMall/proPayment?userIdx=" + userIdx + "&userName=" + setName + "&userTel=" + setTel + "&userAddr=" + twouserAddr + "&addrDetail=" + twoaddrDetail + "&zipNo="+ twozipNo);
        
        }

        public ActionResult paymentAction(int userIdx, int? sendIdx, string userName, string userTel, string userAddr, string request, string addrDetail, string zipNo, string cart, int? p_idx, int? qty, int? o_idx)
        {
            var sb = new StringBuilder();
            var deliveryIdx = 0;
            string code = userIdx + DateTime.Now.ToString("yyyyMMddHHmmss");
            if (sendIdx == 0 || sendIdx == null)
            {
                var deliveryInput = new deliveryList();
                deliveryInput.userIdx = userIdx;
                deliveryInput.userName = userName;
                deliveryInput.userTel = userTel;
                deliveryInput.userAddr = userAddr;
                deliveryInput.request = request;
                deliveryInput.useYn = "Y";
                deliveryInput.mainYn = "N";
                deliveryInput.writeDate = DateTime.Now;
                db.deliveryList.Add(deliveryInput);
                db.SaveChanges();

                deliveryIdx = deliveryInput.idx;
            }
            else
            {
                var nowDelivery = db.deliveryList.Where(p => p.idx == sendIdx).FirstOrDefault();
                deliveryIdx = Convert.ToInt32(sendIdx);
                nowDelivery.request = request;
                db.SaveChanges();
            }
            var allPrice = 0;

            var cartList = db.productCart.Include(p => p.productIdxNavigation).Include(p => p.optionIdxNavigation)
                .Where(p => p.userIdx == userIdx && p.useYn == "C").OrderBy(o => o.idx).ToList();

            if(cart == "N")
            {
                var pInfo = db.productInfo.Where(p => p.idx == p_idx).FirstOrDefault();
                if(o_idx == null)
                {
                    allPrice = Convert.ToInt32(pInfo.price * qty);
                }
                else
                {
                    var oInfo = db.codeOption.Where(p => p.idx == o_idx).FirstOrDefault();
                    allPrice = Convert.ToInt32((pInfo.price + oInfo.price) * qty);
                }                
            }
            else
            {
                foreach (var item in cartList)
                {
                    allPrice += item.qty * item.price;
                }
            }
            
            var orderProduct = new orderProduct();
            orderProduct.orderCode = code;
            orderProduct.userIdx = userIdx;
            orderProduct.price = allPrice;
            orderProduct.deliveryIdx = deliveryIdx;
            orderProduct.payType = 1;
            orderProduct.state = 1;
            orderProduct.useYn = "Y";
            orderProduct.writeDate = DateTime.Now;
            db.orderProduct.Add(orderProduct);
            db.SaveChanges();

            if(cart == "N")
            {
                var productDetail = new orderProductDetail();
                productDetail.orderIdx = orderProduct.idx;
                productDetail.productIdx = Convert.ToInt32(p_idx);
                productDetail.optionIdx = Convert.ToInt32(o_idx);
                productDetail.userIdx = userIdx;
                productDetail.qty = Convert.ToInt32(qty);
                productDetail.price = allPrice;
                productDetail.useYn = "Y";
                productDetail.writeDate = DateTime.Now;
                db.orderProductDetail.Add(productDetail);
                db.SaveChanges();
            }
            else
            {
                foreach (var insert in cartList)
                {
                    var productDetail = new orderProductDetail();
                    productDetail.orderIdx = orderProduct.idx;
                    productDetail.productIdx = insert.productIdx;
                    productDetail.optionIdx = insert.optionIdx;
                    productDetail.userIdx = userIdx;
                    productDetail.qty = insert.qty;
                    productDetail.price = insert.price;
                    productDetail.useYn = "Y";
                    productDetail.writeDate = DateTime.Now;
                    db.orderProductDetail.Add(productDetail);
                    db.SaveChanges();
                }
            }
            
            sb.AppendFormat("<script>");
            sb.AppendFormat("apply_it("+ code + ")");
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
        }

    }
}
