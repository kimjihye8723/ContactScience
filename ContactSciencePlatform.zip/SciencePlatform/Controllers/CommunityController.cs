﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SciencePlatform.Controllers
{
    public class CommunityController : Controller
    {

        private readonly db_e db = new db_e();

        private readonly ILogger<CommunityController> _logger;

        public CommunityController(ILogger<CommunityController> logger)
        {
            _logger = logger;
        }

        // 공지사항
        public IActionResult notice()
        {
            return View();
        }               

        // 뉴스
        public IActionResult news()
        {
            return View();
        }

        // 자료실
        public IActionResult down()
        {
            return View();
        }

        // Q&A
        public IActionResult fnq()
        {
            return View();
        }

    }
}
