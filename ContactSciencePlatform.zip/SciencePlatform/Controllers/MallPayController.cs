﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ReflectionIT.Mvc.Paging;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using SmartFactory.Util;
using static SciencePlatform.Controllers.AccountController;
using Microsoft.AspNetCore.Http;
using LazZiya.ImageResize;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;
using Microsoft.AspNetCore.Routing;
using System.Net;
using Newtonsoft.Json;
using System.Web;

namespace SciencePlatform.Controllers
{
    public class MallPayController : Controller
    {
        private readonly db_e db = new db_e();

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public MallPayController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        //결제내역관리
        public IActionResult purchaseDetails()
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a).FirstOrDefault();
            ViewBag.userTel = userIdx.userTel;


            return View();
        }

        // 1달 단기 결제 
        [HttpPost]
        public ActionResult payapp_feedbackurl(string rebill_no, string linkkey, string linkval, string goodname, int? price, string recvphone, string reqdate, string pay_date, int? pay_type, int? pay_state, string var1, string var2, int? mul_no, string payurl, string csturl, int? orig_mul_no, int? orig_price, int? amount_taxable, int? amount_taxfree, int? amount_vat, int? naverpoint, string card_name, string naverpay, string canceldate, string cancelmemo, int? goodprice, string memo, int? addcomm, string rebillCycleType, int? rebillCycleMonth, string rebillExpire)
        {
            var sb = new StringBuilder();

            #region Param
            //var userid = "판매자 회원 아이디";
            //var linkkey = "연동 KEY";
            //var linkval = "연동 VALUE";
            //var goodname = "상품명";
            //var price = "결제요청 금액";
            //var recvphone = "수신 휴대폰번호";
            //var memo = "메모";
            //var reqaddr = "주소요청 (1:요청, 0:요청안함)";
            //var reqdate = "결제요청 일시";
            //var pay_memo = "결제시 입력한 메모";
            //var pay_addr = "결제시 입력한 주소";
            //var pay_date = "결제승인 일시";
            //var pay_type = "결제수단 (1:신용카드, 2:휴대전화, 3:해외결제, 4:대면결제, 6:계좌이체, 7:가상계좌, 9:문화상품권)";
            //var pay_state = "결제요청 상태 (4:결제완료, 8,16,31:요청취소, 9,64:승인취소, 10:결제대기)";
            //var var1 = "임의 사용 변수 1";
            //var var2 = "임의 사용 변수 2";
            //var mul_no = "결제요청번호";
            //var payurl = "결제페이지 주소";
            //var csturl = "매출전표URL";
            //var amount_taxable  == "과세 공급가액";
            //var amount_taxfree  == "면세 공급가액";
            //var amount_vat == "부가세";
            //var naverpoint == "네이버 포인트 결제시 금액(네이버페이 결제시만 제공)";
            //var naverpay == "네이버결제 구분 방법(네이버페이 결제시만 제공 카드일 경우: 'card', 계좌결제일경우: 'bank')";
            //var buyerid == "구매자 아이디";
            //var canceldate == "취소일시";
            //var cancelmemo == "취소메모";

            #endregion

            try
            {
                payment_payapp _update1 = (from a in db.payment_payapp where a.var2 == var2 select a).OrderByDescending(a => a.writeDate).FirstOrDefault();

                switch (pay_state)
                {
                    // 결제요청
                    case 1:
                        _update1.reqdate = reqdate ?? null;
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_type = pay_type ?? 0;
                        _update1.pay_state = pay_state ?? 0;
                        _update1.mul_no = mul_no ?? 0;
                        _update1.orig_mul_no = orig_mul_no ?? 0;
                        _update1.orig_price = orig_price ?? 0;
                        _update1.amount_taxable = amount_taxable ?? 0;
                        _update1.amount_taxfree = amount_taxfree ?? 0;
                        _update1.amount_vat = amount_vat ?? 0;
                        _update1.rebill_no = rebill_no ?? null;

                        db.SaveChangesAsync();

                        break;


                    //결제완료
                    case 4:
                        _update1.reqdate = reqdate ?? null;
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_type = pay_type ?? 0;
                        _update1.pay_state = pay_state ?? 0;
                        _update1.mul_no = mul_no ?? 0;
                        _update1.naverpoint = naverpoint ?? 0;
                        _update1.naverpay = naverpay ?? null;
                        _update1.card_name = card_name ?? null;
                        _update1.csturl = csturl ?? null;

                        db.SaveChangesAsync(); // 실제로 저장 



                        #region user 수동 업데이트
                        user _update =
                                     (from a in db.user where a.userId == _update1.writer select a).Single();

                        _update.cStartDate = _update1.startDate;
                        _update.cEndDate = _update1.endDate;
                        _update.month1Free = "N";
                        _update.classYn = "Y";
                        db.SaveChanges(); // 실제로 저장  
                        #endregion


                        break;




                    //요청취소
                    case 8:
                    case 16:
                    case 32:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        _update1.canceldate = canceldate ?? null;
                        _update1.cancelmemo = cancelmemo ?? null;

                        db.SaveChangesAsync();

                        #region user 수동 업데이트
                        user _update_ =
                                     (from a in db.user where a.userId == _update1.writer select a).Single();

                        _update_.cStartDate = null;
                        _update_.cEndDate = null;
                        _update_.month1Free = "N";
                        _update_.classYn = "N";

                        db.SaveChanges(); // 실제로 저장  
                        #endregion

                        break;


                    //승인취소
                    case 9:
                    case 64:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        _update1.canceldate = canceldate ?? null;
                        _update1.cancelmemo = cancelmemo ?? null;

                        db.SaveChangesAsync();


                        #region user 수동 업데이트
                        user _update_c =
                                     (from a in db.user where a.userId == _update1.writer select a).Single();

                        _update_c.cStartDate = null;
                        _update_c.cEndDate = null;
                        _update_c.month1Free = "N";
                        _update_c.classYn = "N";

                        db.SaveChanges(); // 실제로 저장  
                        #endregion

                        break;


                    //결제대기
                    case 10:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        db.SaveChangesAsync();

                        break;


                    //부분취소
                    case 70:
                    case 71:
                        _update1.pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        _update1.pay_state = pay_state ?? 0;
                        _update1.orig_mul_no = orig_mul_no ?? 0;
                        _update1.orig_price = orig_price ?? 0;
                        _update1.canceldate = canceldate ?? null;
                        _update1.cancelmemo = cancelmemo ?? null;
                        db.SaveChangesAsync();


                        #region user 수동 업데이트
                        user _update_c1 =
                                     (from a in db.user where a.userId == _update1.writer select a).Single();

                        _update_c1.cStartDate = null;
                        _update_c1.cEndDate = null;
                        _update_c1.month1Free = "N";
                        _update_c1.classYn = "N";

                        db.SaveChanges(); // 실제로 저장  
                        #endregion

                        break;
                }


                //결제내역 payapp_library 에 백업
                var _insert_ = new payapp_library
                {
                    writeDate = DateTime.Now,
                    linkkey = linkkey ?? null,
                    linkval = linkval ?? null,
                    recvphone = recvphone ?? null,
                    reqdate = reqdate ?? null,
                    pay_date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    pay_type = pay_type ?? 0,
                    pay_state = pay_state ?? 0,
                    var1 = var1 ?? null,
                    var2 = var2 ?? null,
                    mul_no = mul_no ?? 0,
                    csturl = csturl ?? null,
                    orig_mul_no = orig_mul_no ?? 0,
                    orig_price = orig_price ?? 0,
                    amount_taxable = amount_taxable ?? 0,
                    amount_taxfree = amount_taxfree ?? 0,
                    amount_vat = amount_vat ?? 0,
                    naverpoint = naverpoint ?? 0,
                    naverpay = naverpay ?? null,
                    canceldate = canceldate ?? null,
                    cancelmemo = cancelmemo ?? null,
                    card_name = card_name ?? null,
                    payurl = payurl ?? null,
                    goodname = goodname ?? null,
                    goodprice = goodprice ?? 0,
                    rebillCycleType = rebillCycleType ?? null,
                    rebillExpire = rebillExpire ?? null,
                    price = price ?? 0,
                    rebill_no = rebill_no ?? null,

                };

                db.payapp_library.Add(_insert_);
                db.SaveChangesAsync(); // 실제로 저장 


            }
            catch
            { }


            return null;


        }

        public ActionResult payapp_success(payment_payapp doc, int? idx)
        {


            if (idx != null)
            {
                doc = db.payment_payapp.Where(a => a.idx == idx).OrderBy(a => a.idx).LastOrDefault();

                #region 기본 사용자 정보
                string user_id = doc.writer;
                string company_id = UserData.user_get(user_id, "company_id");
                string department_idx = UserData.user_get(user_id, "department_idx");
                string department_name = UserData.user_get(user_id, "department_name");
                int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
                #endregion

                //결제된 디바이스 목록
                var _list = db.payment_payapp.Where(p => p.pay_state == 4 && p.writer == user_id && p.var1 == "1").OrderByDescending(o => o.pay_date);
                ViewBag.paymentList = _list.FirstOrDefault();
            }


            return View(doc);
        }

        // 1달 결제 취소 
        public ActionResult payment_cancel(string var2, string pay_gubun)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string department_name = UserData.user_get(user_id, "department_name");
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            var sb = new StringBuilder();

            //payment_payapp delete = db.payment_payapp.Where(x => x.var2 == var2).FirstOrDefault();
            var delete = db.payment_payapp.Where(x => x.var2 == var2).FirstOrDefault();


            sb.AppendFormat("<script>");

            string cmd = "";
            //var rebill_no = doc.rebill_no;
            DateTime excess = Convert.ToDateTime(delete.pay_date).AddDays(5);
            if (pay_gubun == "2")
            {
                cmd = "rebillCancel"; //정기결제 해지 
            }
            else
            {
                if (excess <= DateTime.Now)
                {
                    cmd = "paycancelreq"; //결제 취소 요청 (구매자가 결제승인 후 D+5일이 경과 되었거나, 판매자 정산이 완료된 경우)
                }
                else
                {
                    cmd = "paycancel"; // 결제 취소
                }
            }



            sb.AppendFormat("$('#cmd').val('" + cmd + "');");
            sb.AppendFormat("$('#var2').val('" + var2 + "');");
            //sb.AppendFormat("$('#rebill_no').val('" + rebill_no + "');");
            sb.AppendFormat("$('#linkkey').val('" + delete.linkkey + "');");
            sb.AppendFormat("$('#mul_no').val('" + delete.mul_no + "');");
            sb.AppendFormat("cancelPay('" + pay_gubun + "');");
            sb.AppendFormat("</script>");

            Response.WriteAsync(sb.ToString());

            return null;
        }

        public IActionResult monthly_pap_popUp(string cmd, string goodname, int? goodprice, int? price, string recvphone, string rebillCycleType, string rebillCycleMonth, string rebillExpire, string var1, string var2)
        {
            //cmd
            ViewBag.cmd = cmd;
            //상품명
            ViewBag.goodname = goodname;
            //월정기결제 
            ViewBag.goodprice = goodprice;
            //연결제 
            ViewBag.price = price;
            //연락처#
            ViewBag.recvphone = recvphone;
            //정기결제 반복구분
            ViewBag.rebillCycleType = rebillCycleType;
            //정기결제 결제일
            ViewBag.rebillCycleMonth = rebillCycleMonth;
            //정기결제 만료일
            ViewBag.rebillExpire = rebillExpire;
            //cmd 구분
            ViewBag.var1 = var1;
            //임의변수
            ViewBag.var2 = var2;

            return View();
        }


        public ActionResult payapp_request(string cmd, string goodname, int? goodprice, int? price, string recvphone, string rebillCycleType, string rebillCycleMonth, string rebillExpire, int? mul_no, string rebill_no, string var1, string var2)
        {

            #region 기본 변수
            string user_id = User.Identity.Name;
            price = price ?? 0;
            goodprice = goodprice ?? 0;
            string pay_url3 = "";
            string url = "https://api.payapp.kr/oapi/apiLoad.html";
            string responseText = string.Empty;
            StringBuilder dataParams = new StringBuilder();

            #endregion

            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                #region 기본 정보 저장
                var _insert = new payment_payapp
                {
                    writer = user_id,
                    writeDate = DateTime.Now,
                    linkkey = "gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=",
                    linkval = "gOss/MdwFI1k/Qtrly5ZpxxeRLbvrLi1v5VQbFpTZYk=",
                    recvphone = recvphone,
                    var1 = var1,
                    var2 = var2,
                    payGubun = Convert.ToInt32(var1),
                    startDate = DateTime.Now,
                    endDate = DateTime.Now,
                    goodname = goodname,
                    price = Convert.ToInt32(price),
                    goodprice = Convert.ToInt32(goodprice)

                };
                db.payment_payapp.Add(_insert);
                db.SaveChanges();
                #endregion
                goodname = HttpUtility.UrlEncode(goodname);
                dataParams.Append("cmd=" + cmd + "&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("goodname=" + goodname + "&");
                dataParams.Append("recvphone=" + recvphone + "&");
                dataParams.Append("var1=" + var1 + "&");
                dataParams.Append("var2=" + var2 + "&");
                dataParams.Append("smsuse=n&");
                dataParams.Append("checkretry=y&");
                dataParams.Append("redirectpay=1&");
                dataParams.Append("skip_cstpage=y&");
                dataParams.Append("openpaytype=phone,card,kakaopay,naverpay,zeropay&");
                dataParams.Append("price=" + price + "&");
                dataParams.Append("goodprice=" + goodprice + "&");
                dataParams.Append("rebillCycleType=" + rebillCycleType + "&");
                dataParams.Append("rebillCycleMonth=" + rebillCycleMonth + "&");
                dataParams.Append("rebillExpire=" + rebillExpire + "&");
                dataParams.Append("feedbackurl=https://contactsci.theblueeye.com/mypage/payapp_feedbackurl&");
                dataParams.Append("returnurl=https://contactsci.theblueeye.com/mypage/payapp_success2");


            }
            else if (cmd == "rebillCancel" || cmd == "paycancel") //결제취소시
            {
                dataParams.Append("cmd=paycancel&");
                dataParams.Append("userid=hellodd5005&");
                dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                dataParams.Append("mul_no=" + mul_no + "&");
            }

            #region 데이터 전송
            byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
            webRequest.Method = "POST";    // 기본값 "GET"
            webRequest.ContentType = "application/x-www-form-urlencoded";
            webRequest.ContentLength = dataParams.Length;
            Stream stDataParams = webRequest.GetRequestStream();
            stDataParams.Write(byteDataParams, 0, dataParams.Length); //전송
            #endregion

            #region 데이터 응답
            using (HttpWebResponse resp = (HttpWebResponse)webRequest.GetResponse())
            {
                HttpStatusCode status = resp.StatusCode;
                Console.WriteLine(status); // status 가 정상일경우 OK가 입력된다. 

                // 응답과 관련된 stream을 가져온다.
                Stream respStream = resp.GetResponseStream();
                using (StreamReader streamReader = new StreamReader(respStream))
                {
                    responseText = streamReader.ReadToEnd(); //데이터 결과값  
                }
            }

            #endregion

            #region 데이터 후처리
            if (cmd == "rebillRegist" || cmd == "payrequest") //결제시
            {
                string[] divided = responseText.Split('&');
                var pay_url = divided[4].Split('=');
                pay_url3 = HttpUtility.UrlDecode(pay_url[1]);
                var rebill_param = divided[3].Split('=')[1];
                var result_no = 0;
                //mul_no, rebill_no 구분 저장
                switch (var1)
                {
                    case "2":
                        result_no = 0;
                        break;

                    case "3":
                        result_no = Convert.ToInt32(rebill_param);
                        rebill_no = null;
                        break;
                }

                payment_payapp _update = (from a in db.payment_payapp where a.var2 == var2 select a).OrderByDescending(a => a.writeDate).FirstOrDefault();
                _update.payurl = pay_url3;
                _update.rebill_no = rebill_param;
                _update.mul_no = result_no;

                db.SaveChanges();
                stDataParams.Close();
            }
            else //결제 취소시
            {
                if (cmd == "rebillCancel") //정기결제 해지 후에 결제 취소 진행
                {
                    stDataParams.Close();
                    dataParams = new StringBuilder(); //파라미터 초기화
                    dataParams.Append("cmd=rebillCancel&");
                    dataParams.Append("userid=hellodd5005&");
                    dataParams.Append("linkkey=gOss/MdwFI1k/Qtrly5Zp+1DPJnCCRVaOgT+oqg6zaM=&");
                    dataParams.Append("mul_no=" + mul_no + "&");
                    dataParams.Append("rebill_no=" + rebill_no + "&");
                    byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
                    webRequest = (HttpWebRequest)WebRequest.Create(url);
                    webRequest.Method = "POST";    // 기본값 "GET"
                    webRequest.ContentType = "application/x-www-form-urlencoded";
                    webRequest.ContentLength = dataParams.Length;
                    stDataParams = webRequest.GetRequestStream();
                    stDataParams.Write(byteDataParams, 0, dataParams.Length);
                    stDataParams.Close();
                }
                else
                {
                    stDataParams.Close();
                }

                return Redirect("/mallpay/purchaseDetails");
            }
            #endregion

            return Redirect(pay_url3);
        }



    }
}
