﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SciencePlatform.Models;
using SmartFactory.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using static SciencePlatform.Controllers.AccountController;

namespace SciencePlatform.Controllers
{
    public class HomeController : Controller
    {


        private readonly db_e db = new db_e();
        private void GetSession(string userName)
        {
            string _now = DateTime.Now.ToString("yyyy.MM.dd HH:mm"); //시간
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString(); //아이피

            //세션 저장
            HttpContext.Session.SetString("S_user_name", userName);
            HttpContext.Session.SetString("S_time", _now);
            HttpContext.Session.SetString("S_ip", _ip);

            var _cnt = (from a in db.user where a.userId == userName select a).Count();

            if (_cnt == 1)
            {
                var _update = (from a in db.user where a.userId == userName select a).Single();



                _update.now_ip = _ip;

                db.SaveChanges();
            }
        }

            public IActionResult Index(classInfo doc)
            {
            #region 로그인 정보
            string user_id = User.Identity.Name;
            #endregion

            if (User.Identity.IsAuthenticated )
            {

                //세션 저장===============================================================================================
                GetSession(user_id);
                //========================================================================================================
            }



            //분야별 찾기            
            var _list = db.code_scienceCategory.Where(a=>a.useYn!="N").OrderBy(p => p.idx).ToList();
            ViewBag.선택리스트 = _list;

            var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();

            //콘택트 사이언스 과학자 - 관리자가 선택? 이번달 클래스관련 과학자?, 5명 제한 
            //var _list_ck = db.classInfo.Where(p => p.useYn != "N").Include(p => p.scienceCateNavigation).Include(p => p.managerIdxNavigation);                     
            //var _list0 = db.user.Where(a => a.userClass == 3).OrderByDescending(p => p.writeDate).ToList();
            //ViewBag.과학자들 = _list0;
            //ViewBag.과학자들c = _list0.Count();                    

         

            //이번달 클래스 - 5개 배치
            var _list_ThisM = db.classInfo.Where(p => p.useYn == "Y" && p.state != 0 && DateTime.Now.Year == p.startDate.Year && DateTime.Now.Month == p.startDate.Month).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.idx).ToList();
            ViewBag.신규클래스 = _list_ThisM.Take(5);
            ViewBag.신규클래스c = _list_ThisM.Count();

            //다음달 클래스 - 10개 배치
            var _list_NextM = db.classInfo.Where(p => p.useYn == "Y" && p.state != 0 && DateTime.Now.Year == p.startDate.Year && DateTime.Now.AddMonths(1).Month == p.startDate.Month).Include(p => p.managerIdxNavigation).OrderByDescending(p => p.idx).ToList();
            ViewBag.다음달클래스 = _list_NextM.Take(10);
            ViewBag.다음달클래스c = _list_NextM.Count();


            //만남후기
            var _mlist = db.v_review.Where(p=>p.BM_idx== 7 && p.mainYn == "Y" && p.userYn =="Y" && p.classYn =="Y").OrderByDescending(p => p.idx).ToList(); // 관리자 선택           
            ViewBag.만남후기 = _mlist;
            ViewBag.만남후기c = _mlist.Count();

            //커뮤니티 - 공지사항만 나오게 
            //var clist= db.BoardList.Where(p => p.useable == "S" &&  p.BM_idx == 1 || p.useable == "S" &&  p.BM_idx == 2 || p.useable == "S" && p.BM_idx == 3).Include(p => p.BM_idxNavigation).OrderByDescending(p => p.idx).Take(4); // 관리자 선택
            var clist = db.BoardList.Where(p => p.useable != "N" &&  p.BM_idx == 1 && p.mainYn == "Y").Include(p => p.BM_idxNavigation).OrderByDescending(p => p.idx).Take(4); // 관리자 선택
            ViewBag.커뮤니티 = clist;
            ViewBag.커뮤니티c = clist.Count();


            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult sys_info()
        {
            ViewBag.세션이름 = HttpContext.Session.GetString("S_user_name");

            ViewBag.세션아이피 = HttpContext.Session.GetString("S_ip");

            ViewBag.세션접속시간 = HttpContext.Session.GetString("S_time");


            ViewBag.쿠키이름 = User.Identity.Name;
            ViewBag.세션아이디 = HttpContext.Session.Id;


            return View();
        }


        public IActionResult Privacy2()
        {
            return View();
        }
        public IActionResult Privacy3()
        {
            return View();
        }


        // 알람 view 모음 
        public IActionResult report(string msg, string return_url)
        {

            ViewBag.알림 = msg;

            ViewBag.이전 = return_url;

            return View();
        }


        // 로그인 중복 방지 알람 view
        public IActionResult report2(string msg, string return_url)
        {

            ViewBag.알림 = msg;

            ViewBag.이전 = return_url;

            return View();
        }



        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<ActionResult> CheckSession(string userName, string user_ip)
        {


            //if (string.IsNullOrEmpty(user_ip))
            //{
            //    return RedirectToAction("index", "home");

            //}


            var _cnt = (from a in db.user where a.userId == userName && a.now_ip == user_ip select a.idx).Count();
            var sb = new StringBuilder();
            if (_cnt == 0)
            {
                 return RedirectToAction("Report2", "home", new { msg = "다른 곳에서 접속했습니다. 다시 접속을 원하시면 로그인 해주세요.", return_url = "/account/Logout" });

               
                sb.AppendFormat("<script>");
                sb.AppendFormat("alert('다른 곳에서 접속했습니다. 다시 접속을 원하시면 로그인 해주세요');");
                sb.AppendFormat("window.location.href = '/account/Logout';");
                sb.AppendFormat("</script>");

                await Response.WriteAsync(sb.ToString());
            }
            else
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#result4').text('');");
             
                sb.AppendFormat("</script>");
                await Response.WriteAsync(sb.ToString());

            }
          


            return null;


        }


        public IActionResult totalSearchView(string search_all_Total)
        {


            //통합검색창
            ViewBag.search_all_Total = search_all_Total;
                      


            //------------- 클래스 광장 

            var _list2 = db.ViewClassInfo.Where(p => p.useYn != "N").OrderBy(p => p.idx);

            //------------- 커뮤니티

            var _list = db.BoardList.Where(p => p.useable != "N").OrderByDescending(p => p.writeDate); // 전체 

            //------------- 사이언스몰  

            var _listSci = db.productInfo.Where(p => p.useYn != "N").OrderBy(p => p.idx);


            #region 검색 리스트

            if (!string.IsNullOrEmpty(search_all_Total))
            {

                _list2 = _list2.Where(p => p.userName.Contains(search_all_Total) || p.className.Contains(search_all_Total) || p.title.Contains(search_all_Total) && p.useYn != "N").OrderBy(p => p.idx);

                _listSci = _listSci.Where(p=>p.productName.Contains(search_all_Total) || p.title.Contains(search_all_Total) || p.description.Contains(search_all_Total) && p.useYn != "N").OrderByDescending(p => p.writeDate);

                _list = _list.Where(p => p.title.Contains(search_all_Total) || p.content.Contains(search_all_Total) || p.writer.Contains(search_all_Total)).OrderByDescending(p => p.writeDate);

                var _list3 = _list.Where(p => p.BM_idx == 1 && p.useable=="Y").OrderByDescending(p => p.writeDate);
                var _list6 = _list.Where(p => p.BM_idx == 2 && p.useable != "T").OrderByDescending(p => p.writeDate);
                var community = _list3.Count() + _list6.Count();

                ViewBag.검색어 = search_all_Total;



                ViewBag.클래스광장 = _list2;
                ViewBag.클래스광장c = _list2.Count();



                ViewBag.커뮤니티c = community;
                ViewBag.공지사항 = _list3;
                ViewBag.공지사항c = _list3.Count();
                ViewBag.fnq = _list6;
                ViewBag.fnqc = _list6.Count();
                ViewBag.총c = _list2.Count() + community + _listSci.Count();


                ViewBag.사이언스몰 = _listSci;
                ViewBag.사이언스몰c = _listSci.Count();

            }


            #endregion


            return View(_list2);
        }




        // header의 통합알람창 
        public IActionResult totalAlarm_it(string userId, int result)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var sb = new StringBuilder();

            var userIdx = (from a in db.user where a.userId == userId select a).FirstOrDefault();
            sb.AppendFormat("<script>");
            var orderClass_ck = db.orderClassDetail.Where(a => a.userIdx == userIdx.idx && a.idx >= result && a.alarmBellYn == "Y" && a.alarmCheck != "N").Include(a => a.classIdxNavigation).Include(a => a.userIdxNavigation).ToList();

            DateTime now_1before = DateTime.Today.AddDays(-1);
            DateTime now = DateTime.Today;
            sb.AppendFormat("$('#tooltip_area ul').html('<li class=alarm_list></li>');");
            if (orderClass_ck.Count() > 0)
            {
                foreach (var item11 in orderClass_ck)
                {
                    var startDate = item11.classIdxNavigation.startDate;
                    DateTime startDate_ = Convert.ToDateTime(startDate.ToShortDateString());


                    if (startDate_ == now_1before)
                    {
                        sb.AppendFormat("$('.alarm_list:last').after('<li> ▪ " + item11.classIdxNavigation.className + " 클래스가 오픈되기 하루 전입니다.😊</li>');");                       

                    }
                    else if (startDate_ == now)
                    {
                        sb.AppendFormat("$('.alarm_list:last').after('<li> ▪ " + item11.classIdxNavigation.className + " 클래스가 오늘 시작됩니다.😍</li>');");                 

                    }
                   
                    sb.AppendFormat("$('#resultAlarm').val(" + item11.idx + ");");
                }
                sb.AppendFormat("$('#tooltip_area ul').append('<button> 닫기 </button>');");

                // 알람카운트 여부  UI 
                var orderClass_list = orderClass_ck.Where(a =>Convert.ToDateTime(a.classIdxNavigation.startDate.ToShortDateString()) == now_1before || Convert.ToDateTime(a.classIdxNavigation.startDate.ToShortDateString()) == now).ToList();
                ViewBag.알람셋팅리스트_c = orderClass_list.Count();

                if (ViewBag.알람셋팅리스트_c > 0)
                {
                    sb.AppendFormat("$('.noticeCount').html('" + orderClass_list.Count() + "');");
                }
                else
                {
                    sb.AppendFormat("$('.noticeCount').css('display','none');");
                    sb.AppendFormat("$('#tooltip_area ul').html('<li> 등록된 알람이 없습니다.</li>');");
                }
            }
            else
            {
                sb.AppendFormat("$('.noticeCount').css('display','none');");
                sb.AppendFormat("$('#tooltip_area ul').html('<li> 등록된 알람이 없습니다.</li>');");
            }


            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());

            return null;
        }

        // header의 통합알람창 클릭여부 Y/N 
        public IActionResult totalAlarm_check(string userId, int result)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion
            var sb = new StringBuilder();

            var userIdx = (from a in db.user where a.userId == userId select a).FirstOrDefault();
            sb.AppendFormat("<script>");
            var orderClass_ck = db.orderClassDetail.Where(a => a.userIdx == userIdx.idx && a.idx >= result && a.alarmBellYn == "Y" && a.alarmCheck != "N").Include(a => a.classIdxNavigation).Include(a => a.userIdxNavigation).ToList();

            DateTime now_1before = DateTime.Today.AddDays(-1);
            DateTime now = DateTime.Today;

            if (orderClass_ck.Count() > 0)
            {
                foreach (var item11 in orderClass_ck)
                {
                    orderClassDetail _update = (from a in db.orderClassDetail where a.idx == item11.idx select a).Single();
                    _update.alarmCheck = "N";
                    db.SaveChanges();

                  
                }

              
                    sb.AppendFormat("$('.noticeCount').css('display','none');");
                    sb.AppendFormat("$('#tooltip_area ul').html('<li> 등록된 알람이 없습니다.</li>');");
              

          
            }
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());

            return null;
        }

    }
}
