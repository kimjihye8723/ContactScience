﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SciencePlatform.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SciencePlatform.Controllers
{
    public class sciRoomController : Controller
    {
        //private readonly ILogger<IntroController> _logger;

        //public sciRoomController(ILogger<IntroController> logger)
        //{
        //    _logger = logger;
        //}

        private readonly db_e db = new db_e();

        public IActionResult sciRoom_view(user doc, int? idx, int? classIdx)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            if(doc != null)
            {
                doc = db.user.Where(p => p.useYn == "Y" && p.idx == idx).FirstOrDefault();
                var userIdx = (from a in db.user where a.userId == User.Identity.Name select a.idx).FirstOrDefault();
                // 과학자 정보 user로 돌리고, 클래스 정보는 classInfo 로 돌리기 
            
                var _list2 = db.classInfo.Where(p => p.useYn == "Y" && p.managerIdx == idx && p.state != 3).OrderByDescending(p => p.idx).ToList();
                ViewBag.과학자클래스들 = _list2;

                var _class = db.classInfo.Where(p => p.useYn == "Y" && p.managerIdx == idx).Include(p => p.scienceCateNavigation).Include(p => p.managerIdxNavigation).FirstOrDefault();
                ViewBag.과학자클래스 = _class;


                var now = DateTime.Now;   // 현재 날짜, 시간 얻기
                var _list3 = db.classInfo.Where(p => p.useYn == "Y" && p.managerIdx == idx && p.endDate < now && p.state == 3).OrderByDescending(p => p.idx).ToList();
                ViewBag.이전클래스 = _list3;
                ViewBag.이전클래스갯수 = _list3.Count();

                // 공지사항 & 질의응답 & 후기게시판
                // classIdx , bordeTpye_idx 구분해서 게시판리스트 뿌리기

                var _query = db.BoardList.Where(a => a.useable != "N").Include(p => p.BM_idxNavigation);

                //var _Blist1 = _query.Where(a => a.BM_idx == doc.nBoardCate).OrderByDescending(a => a.writeDate).AsNoTracking();
                //ViewBag.공지사항 = _Blist1;
                //ViewBag.query_c1 = _Blist1.Count();


                //var _Blist2 = _query.Where(a => a.BM_idx == doc.qBoardCate).OrderByDescending(a => a.writeDate).AsNoTracking();
                //ViewBag.QNA = _Blist2;
                //ViewBag.query_c2 = _Blist2.Count();

                if(doc.idx == userIdx)
                {
                    ViewBag.과학자권한 = "Y";
                }
                else
                {
                    ViewBag.과학자권한 = "N";
                }

                var _dlist = _query.Where(a => a.BM_idx == doc.dBoardCate).OrderByDescending(a => a.writeDate).AsNoTracking();
                ViewBag.자료실 = _dlist;
                ViewBag.자료실c = _dlist.Count();

            }

   

            return View(doc);
        }

    }
}
