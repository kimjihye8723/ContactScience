﻿using LazZiya.ImageResize;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SciencePlatform.Models;
using SmartFactory.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;


namespace SciencePlatform.Controllers
{
    public class AccountController : Controller
    {


        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public AccountController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion



        public class UserData
        {
            public static string user_get(string user_id, string what)
            {

                db_e db = new db_e();

                string company_id = "BlueEye";
                string company_name = "BlueEye";
                string user_name = "";
                int department_idx = 0;
                int company_idx = 0;
                string department_name = "";
                int auth = 0; //초기 :0
                string user_auth = "";
                string position_idx = "0";
                var _list = (from a in db.user where a.userId == user_id select a).Single();

                if (_list != null)
                {
                    //company_id = _list.company_idxNavigation.company_id;
                    //company_name = _list.company_idxNavigation.company_name;
                    //company_idx = _list.company_idxNavigation.idx;
                    //department_name = _list.department_idxNavigation.department_name;
                    user_name = _list.userName;
                    //department_idx = _list.department_idx;
                    auth = _list.checkAuth; //최고 권한 관리자 :9 , 회사별 권한 관리자 : 8 , 부서장 : 7
                    user_auth = _list.userAuth; //페이지 권한 
                    //position_idx = _list.code_position_idx.ToString();
                }

                string str = "";

                if (what == "user_id")
                {
                    str = user_id;
                }
                else if (what == "user_name")
                {
                    str = user_name;
                }
                else if (what == "company_id")
                {
                    str = company_id;
                }
                else if (what == "company_idx")
                {
                    str = company_idx.ToString();
                }
                else if (what == "company_name")
                {
                    str = company_name;
                }
                else if (what == "department_idx")
                {
                    str = department_idx.ToString();
                }
                else if (what == "department_name")
                {
                    str = department_name;
                }
                else if (what == "auth")
                {
                    str = auth.ToString();
                }
                else if (what == "user_auth")
                {
                    str = user_auth.ToString();
                }
                else if (what == "position_idx")
                {
                    str = position_idx.ToString();
                }

                return str;

            }

            public void History_write(string user_id, string _page, string _state)
            {
                db_e db = new db_e();

                string user_name = UserData.user_get(user_id, "user_name");
                string department_id = UserData.user_get(user_id, "department_id");
                string department_name = UserData.user_get(user_id, "department_name");
                string company_id = UserData.user_get(user_id, "company_id");
                string company_name = UserData.user_get(user_id, "company_name");
                string auth = UserData.user_get(user_id, "auth");

                var _insert = new history
                {
                    user_id = user_id,
                    company_id = company_id,
                    department_id = department_id,
                    user_ip = "",
                    pre_page = "",
                    connect_agent = company_name,
                    connect_host = auth,
                    connect_path = user_name,
                    memo = department_name,
                    connect_date = DateTime.Now,
                    state = _state,
                    page = _page
                };

                db.history.Add(_insert);
                db.SaveChanges(); // 실제로 저장 


            }
        }


        public class MyLoginModel
        {

            [StringLength(50)]
            public string userName { get; set; }

            [StringLength(50)]
            public string password { get; set; }

            //나중에 필요
            public bool RememberMe { get; set; }

        }
        

     
        private readonly db_e db = new db_e();

        private void GetSession(string userName)
        {
            string _now = DateTime.Now.ToString("yyyy.MM.dd HH:mm"); //시간
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString(); //아이피

            //세션 저장
            HttpContext.Session.SetString("S_user_name", userName);
            HttpContext.Session.SetString("S_time", _now);
            HttpContext.Session.SetString("S_ip", _ip);

            var _cnt = (from a in db.user where a.userId == userName select a).Count();

            if (_cnt == 1)
            {
                var _update = (from a in db.user where a.userId == userName select a).Single();


                _update.now_ip = _ip;


                db.SaveChanges();
            }


        }

        public IActionResult Login()
        {
            string _user_id = "";
            string hellodd_rememberMe = "Y";
            string id_one = "N";
            var name = HttpContext.Session.GetString("S_user_name");

            ViewBag.세션이름 = name;


            if (User.Identity.IsAuthenticated)
            {
                string userName = User.Identity.Name;
                //세션 저장===============================================================================================
                GetSession(userName);
                //========================================================================================================

          
            }


            try
            {
             
                _user_id = Request.Cookies["hellodd_userid"];
                hellodd_rememberMe = Request.Cookies["hellodd_rememberMe"];
                if (Request.Cookies["id_one"] != null) { id_one = Request.Cookies["id_one"].ToString(); }
            }
            catch { }
            ViewBag.user_id_check = _user_id;
            ViewBag.hellodd_rememberMe = hellodd_rememberMe;
            ViewBag.id_one = id_one;
            return View();
        }

        // 자동로그인 체크 
        public IActionResult login_check(string ReturnUrl)
        {
            string userName = "";
            string _company = "0";
            string password = "xx";
            int password_cont = 0;

            userName = Request.Cookies["hellodd_userid"].ToString();
          

            int _idx = Convert.ToInt32(_company);

            password_cont = (from a in db.user where a.userId == userName select a.userPassword).Count();



            if (!string.IsNullOrEmpty(userName) && password_cont == 1)
            {

                password = (from a in db.user where a.userId == userName select a.userPassword).Single();

                var _user_info = (from a in db.user where a.userId == userName && a.userPassword == password && a.useYn == "Y" select a).Single();

               // var admin_yn = (from a in db.user where a.user_id == userName && a.user_password == password && a.use_yn == "Y" select a.admin_yn).Single();



                #region 데이터베이스 테이블에서 로그인 정보 확인
                    ClaimsIdentity identity = null;
                    bool isAuthenticated = false;


              
                        //Create the identity for the user
                        identity = new ClaimsIdentity(new[] {
                        new Claim(ClaimTypes.Name, userName),  }, CookieAuthenticationDefaults.AuthenticationScheme);

                        isAuthenticated = true;

                    #region 로그인 확인
                    if (isAuthenticated)
                        return GetCookies(userName, identity, _user_info.id_one);
                    #endregion
                #endregion

                return RedirectToAction("Login", "account", new { userName = userName, password = password, ReturnUrl = ReturnUrl });

            }
            else
            {
                return Redirect("/home/index");

            }




        }

        private IActionResult GetCookies(string userName, ClaimsIdentity identity, string id_one)
        {

            //세션 저장===============================================================================================
            GetSession(userName);
            //========================================================================================================
            var principal = new ClaimsPrincipal(identity);
            var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);


            #region 쿠키저장
            //쿠키저장
            try
            {

                var option = new CookieOptions()
                {
                    Path = "/",
                    HttpOnly = false,
                    IsEssential = true, //<- there
                    Expires = DateTime.Now.AddYears(1),
                };

                Response.Cookies.Append("work_userid", userName, option);
                Response.Cookies.Append("id_one", id_one, option); // 중복로그인 허용

            }
            catch
            {
                //  Response.Cookies.Delete(key); //쿠키삭제
            }
            #endregion

            History_write(userName, "/home/index", "로그인");


            // 기본 경로
            return RedirectToAction("Index", "Home");

        }

        [HttpPost]
        public IActionResult Login(MyLoginModel model, string ReturnUrl, string rememberMe)
        {

            ViewBag.hellodd_rememberMe = rememberMe;
            var sb = new StringBuilder();


            #region 아이디 정보가 없을 경우
                if (!string.IsNullOrEmpty(model.userName) && string.IsNullOrEmpty(model.password))
                {
                    ModelState.AddModelError("", "사용자 이름 또는 암호가 잘못되었습니다.");
                    sb.AppendFormat("<head>");
                    sb.AppendFormat("<meta http-equiv='Content-Type' content='text/html; charset = utf-8'>");
                    sb.AppendFormat("</head>");
                    sb.AppendFormat("<script src = '/Content/assets/js/jquery.min.js' ></script >");
                    sb.AppendFormat("<script>");
                    sb.AppendFormat("alert('사용자 이름 또는 암호가 잘못되었습니다.');");
                    sb.AppendFormat("location.href='/account/login';");
                    sb.AppendFormat("</script>");
                    Response.WriteAsync(sb.ToString());
                }
            #endregion

            #region 데이터베이스 테이블에서 로그인 정보 확인

            ClaimsIdentity identity = null;
            bool isAuthenticated = false;

            int user_check = (from a in db.user where a.userId == model.userName && a.userPassword == model.password && a.useYn == "Y" select a).Count();

            if (user_check == 1)
            {
                var _user_info = (from a in db.user where a.userId == model.userName && a.userPassword == model.password && a.useYn == "Y" select a).Single();
                //var admin_yn = (from a in db.user where a.userId == model.userName && a.userPassword == model.password && a.useYn == "Y" select a.admin_yn).Single();
                //if (admin_yn == "Y")
                //{
                //Create the identity for the user
                identity = new ClaimsIdentity(new[] {
                                        new Claim(ClaimTypes.Name, model.userName),
                                        new Claim(ClaimTypes.Role, _user_info.checkAuth.ToString())
                                    }, CookieAuthenticationDefaults.AuthenticationScheme);

                isAuthenticated = true;

                            #region 로그인 확인
                            if (isAuthenticated)
                            {
                    GetCookies(model.userName, identity, _user_info.id_one);
                    var principal = new ClaimsPrincipal(identity);
                                var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                                #region 쿠키저장
                                    //쿠키저장
                                    try
                                    {

                                        CookieOptions cookieOptions = new CookieOptions();
                                        cookieOptions.Expires = DateTime.Now.AddYears(1);
                                        if (rememberMe == "N")  // <-- 자동로그인 체크 안했을 시 
                                        {
                                            Response.Cookies.Delete("hellodd_rememberMe"); //쿠키삭제
                                        }
                                        else
                                        {
                                            HttpContext.Response.Cookies.Append("hellodd_userid", model.userName);
                                            HttpContext.Response.Cookies.Append("hellodd_rememberMe", rememberMe);
                                        }                                       
                                    }
                                    catch
                                    {

                                    }
                                #endregion


                               

                           

                                //Response.Cookies.Delete("smartfactory_btn_userid"); //쿠키삭제


                                History_write(model.userName, "/home/index", "로그인");

                                if (Url.IsLocalUrl(ReturnUrl))
                                {
                                    // 원하는 경로가 있을 경우
                                    return Redirect(ReturnUrl);
                                }
                                else
                                {
                                    // 기본 경로
                                    return Redirect("/home/index");
                                }

                            }
                            #endregion

            }else{    
                // 알람뷰 이동 후 페이지 이동 
                //return RedirectToAction("login", "home", new { msg = "아이디 또는 비밀번호를 확인해주세요.", return_url = "/account/login" });
                return RedirectToAction("Login", "account", new { msg = "N", return_url = ReturnUrl });
                #endregion
            }



            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            Response.Cookies.Delete("hellodd_userid"); //쿠키삭제

            HttpContext.Session.Clear();

            History_write(User.Identity.Name, "/home/index", "로그아웃");

            return RedirectToAction("Login");
        }

        //public IActionResult maintain_lg_check()
        //{
            
        //    CookieOptions cookieOptions = new CookieOptions();
        //    cookieOptions.Expires = DateTime.Now.AddDays(-1);

        //    // 기본 경로
        //    return Redirect("/account/login");
        //}


        #region 회원가입
        public ActionResult Register(user doc, string n , string e)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            if(user_id != null)
            {
                doc = (from a in db.user where a.userId == user_id select a).FirstOrDefault();
            }

            ViewBag.사용자이름 = n;
            ViewBag.사용자이메일 = e;

            return View(doc);
        }
        public ActionResult Register_ck(string e, string portal)
        {
            var sb = new StringBuilder();
            // 회원가입여부 체크 

            var joinCk = db.user.Where(a => a.userEmail == e && a.useYn != "N");
            sb.AppendFormat("<script>");

            if(portal == "n")
            {
                if (joinCk.Count() > 0)
                {
                    //회원가입 이미 했을때 
                    var join = joinCk.FirstOrDefault();
                    sb.AppendFormat("$('#userName',opener.document).val('" + join.userId + "');");
                    sb.AppendFormat("$('#password',opener.document).val('" + join.userPassword + "');");
                    sb.AppendFormat("$('#frm',opener.document).submit();");
                    sb.AppendFormat("self.close();");

                }
                else
                {
                    sb.AppendFormat("opener.location.href='/account/Register?e=" + e + "';");
                    sb.AppendFormat("self.close();");
                }
            }
            else
            {
                if (joinCk.Count() > 0)
                {
                    //회원가입 이미 했을때 
                    var join = joinCk.FirstOrDefault();
                    sb.AppendFormat("$('#userName').val('" + join.userId + "');");
                    sb.AppendFormat("$('#password').val('" + join.userPassword + "');");
                    sb.AppendFormat("$('#frm').submit();");

                }
                else
                {
                    sb.AppendFormat("location.href='/account/Register?e=" + e + "';");
                }
            }
           
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
        }


        public ActionResult naverCallback()
        {


            return View();
        }

        public ActionResult Register_check(string doc_it)
        {

            var sb = new StringBuilder();

            int _doc2 = (from a in db.user where a.userId == doc_it select a.userId).Count();


            if (_doc2 > 0)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#userId').attr('value' ,'') ; ");
                //sb.AppendFormat("demo.showSwal('auto-close');");
                sb.AppendFormat("$('#user_id_check').attr('value' ,'N') ;");
                sb.AppendFormat("$('#userId').css('border' ,'solid 1px red') ; ");
                sb.AppendFormat("$('#userId').focus() ; ");
                sb.AppendFormat("alert('사용 불가한 아이디입니다.');");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }
            else
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#user_id_check').attr('value' ,'Y') ;");
                sb.AppendFormat("$('#userId').css('border' ,'solid 1px green') ; ");
                sb.AppendFormat("alert('사용 가능한 아이디입니다.');");
                sb.AppendFormat("</script>");
                Response.WriteAsync(sb.ToString());
            }

            return null;
        }

        public void History_write(string user_id, string _page, string _state)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");
            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = department_name,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }

        public ActionResult Register_action(user doc, string mode_type, string idx)
        {

            string msg = "";
            string user_id = User.Identity.Name ?? "xx";
            string _msg = "";

            int new_user_index = 1;
            try
            {
                new_user_index = (from a in db.user select a.idx).Max() + 1;
            }
            catch
            {
            }




            if (mode_type=="Y") // 회원가입시 
            {
                _msg = "Y";
                msg = "회원가입이 되었습니다.";

                #region 저장
                //doc.admin_yn = "N";
                doc.useYn = "Y";
                doc.checkAuth = 1;
                doc.userAuth = "1";
                doc.userClass = 1;
                doc.writeDate = DateTime.Now;
                doc.editDate = DateTime.Now;
                doc.cStartDate = DateTime.Now;
                doc.cEndDate = DateTime.Now.AddMonths(1);
                doc.month1Free = "Y"; // 무료 1개월 사용 할수 있게 
                doc.classYn = "Y";
                db.user.Add(doc);
                db.SaveChanges(); // 실제로 저장 


               

                #endregion

                if (doc.userClass == 3) // 과학자의 경우 
                {
                    #region 과학자의 방 - 게시판 자동 생성      
                    // 공지사항 게시판  
                    var _insert1 = new BoardMenu
                    {
                        title = "공지사항",
                        BoardType_idx = 8,
                        open_yn = "Y",
                        userIdx = doc.idx,

                    };
                    //qna게시판 
                    var _insert2 = new BoardMenu
                    {
                        title = "Q&A",
                        BoardType_idx = 7,
                        open_yn = "Y",
                        userIdx = doc.idx,

                    };
                    //과학자 자료실
                    var _insert3 = new BoardMenu
                    {
                        title = "과학자 자료실",
                        BoardType_idx = 10,
                        open_yn = "Y",
                        userIdx = doc.idx,

                    };




                    db.BoardMenu.AddRange(_insert1, _insert2, _insert3);
                    db.SaveChanges();

                    #endregion

                   
                    #region 수동 업데이트 [과학자방 게시판 정보 user 테이블에 업데이트]
                    user _update =
                             (from a in db.user where a.idx  == doc.idx && a.userClass == 3 select a).Single();

                    _update.nBoardCate = _insert1.idx;
                    _update.qBoardCate = _insert2.idx;
                    _update.dBoardCate = _insert3.idx;

                    db.SaveChanges(); // 실제로 저장  
                    #endregion
                   
                }

                return Redirect("/account/login?name=" + doc.userName + "&msg=" + _msg);

            }
            else // 회원정보 수정시
            {
                msg = "정상적으로 수정 되었습니다.";
                _msg = "E";

                user _update =
                         (from a in db.user where a.userId == user_id select a).Single();

                _update.userPassword = doc.userPassword;
                _update.userName = doc.userName;
                _update.userTel = doc.userTel;
                _update.userEmail = doc.userEmail;
                _update.id_one = doc.id_one;

                db.SaveChanges(); // 실제로 저장 

                return Redirect("/Mypage/ingClass");

            }

          



        }
        #endregion


        #region 헤더 > 프로필 사진 업로드

        public async Task<ActionResult> profile_action(string userId, string photoProfile, List<IFormFile> files)
        {
            var sb = new StringBuilder();
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            #endregion

            #region 파일 아이디
            string file_id = "";


            file_id = photoProfile;

            if (string.IsNullOrEmpty(file_id))
            {

                file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();


            }
            #endregion

            #region 파일 올리기

            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);

                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = userId + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;    // 신규 파일 이름   
                    var _local_path = _targetFilePath + "/";   // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);    // 전체 경로
                    string desiredThumbPath = _local_path + "s/";   // 작은 이미지 전체 경로
                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion

                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================

                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);
                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }

                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            #region 사용자 정보 수정
            user _update =
                     (from a in db.user where a.userId == User.Identity.Name select a).Single();

            _update.photoProfile = file_id;
            db.SaveChanges(); // 실제로 저장  
            #endregion
            var fileName = db.BoardFile.Where(p => p.Md_id == file_id).OrderByDescending(p => p.id).Select(p => p.sImagePath).FirstOrDefault();
            sb.AppendFormat("<script>");
            sb.AppendFormat("$('#avatar').attr('src', '"+ fileName + "');");
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;

        }

        #endregion




        #region 아이디/비밀번호 찾기

        public IActionResult Forgotpassword(user doc, string type)
        {

            return View(doc);
        }

        public ActionResult Forgot_check(string id, string name, string tel, string email, int type)
        {

            var sb = new StringBuilder();
            sb.AppendFormat("<script>");
            if (type == 1)
            {
                int _doc1 = (from a in db.user where a.userName == name && a.useYn == "Y" select a).Count();


                if (_doc1 > 0)
                {
                    int _doc2 = (from a in db.user where a.userName == name && a.userTel == tel && a.useYn == "Y" select a).Count();

                    if (_doc2 > 0)
                    {
                        int _doc3 = (from a in db.user where a.userName == name && a.userTel == tel && a.userEmail == email && a.useYn == "Y" select a).Count();
                        if (_doc3 > 0)
                        {
                            var _doc = db.user.Where(a => a.userName == name && a.userTel == tel && a.userEmail == email && a.useYn == "Y").FirstOrDefault();
                    
                            sb.AppendFormat("location.href='/account/forgot_detail?idx=" + _doc.idx + "&type=1';");
                       
                        }
                        else
                        {
                           
                            sb.AppendFormat("alert('일치하지 않는 이메일입니다.');");
                    
                        }
                    }
                    else
                    {
                 
                        sb.AppendFormat("alert('일치하지 않는 전화번호입니다.');");
                
                    }
                }
                else
                {
                   
                    sb.AppendFormat("alert('존재하지 않는 이름입니다.');");
                

                }
            }
            else
            {

                int _doc1 = (from a in db.user where a.userId == id && a.useYn != "N" select a).Count();


                if (_doc1 > 0)
                {
                    int _doc2 = (from a in db.user where a.userId == id && a.userTel == tel && a.useYn != "N" select a).Count();

                    if (_doc2 > 0)
                    {
                        int _doc3 = (from a in db.user where a.userId == id && a.userTel == tel && a.userEmail == email && a.useYn != "N" select a).Count();
                        if (_doc3 > 0)
                        {
                            var _doc = db.user.Where(a => a.userId == id && a.userTel == tel && a.userEmail == email && a.useYn != "N").FirstOrDefault();
                       
                            sb.AppendFormat("location.href='/account/forgot_detail?idx=" + _doc.idx + "&type=2';");
                         
                        }
                        else
                        {
                 
                            sb.AppendFormat("alert('일치하지 않는 이메일입니다.');");
                        
                        }
                    }
                    else
                    {
                     
                        sb.AppendFormat("alert('일치하지 않는 전화번호입니다.');");
                   
                    }
                }
                else
                {
                    
                    sb.AppendFormat("alert('존재하지 않는 아이디입니다.');");
                   

                }
            }
            sb.AppendFormat("</script>");
            Response.WriteAsync(sb.ToString());
            return null;
        }

        public IActionResult Forgot_detail(user doc, int idx)
        {
            user data = db.user.Find(idx);
            int _doc3 = (from a in db.user where a.userName == data.userName && a.userTel == data.userTel && a.userEmail == data.userEmail && a.useYn == "Y" select a).Count();
            ViewBag.가입카운트 = _doc3;
            if (_doc3 > 1)
            {
                var data_list = db.user.Where(a => a.userName == data.userName && a.userTel == data.userTel && a.userEmail == data.userEmail && a.useYn == "Y").ToList();
                ViewBag.가입목록 = data_list;
            }

            return View(data);
        }
        public IActionResult mail_action(string user_info, string type)
        {
            var user_email = db.user.Where(a => a.userId == user_info && a.useYn != "N").Select(a => a.userEmail).FirstOrDefault();

            //아이디찾기
            if (type == "1")
            {

                mailSend(user_info, "0", type, user_email);

            }//비밀번호찾기
            else if (type == "2")
            {

                #region 임시비밀번호 발급
                string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

                char[] charArray = chars.ToCharArray();

                int numPasswd = 10;

                string newPasswd = string.Empty;

                int seed = Environment.TickCount;

                Random rd = new Random(seed);
                int tempNum = 0;


                for (int j = 0; j < numPasswd; j++)
                {
                    tempNum = rd.Next(0, charArray.Length - 1);
                    newPasswd += charArray[tempNum];
                }
                #endregion

                //임시비밀번호 변경
                user _update = (from a in db.user where a.userId == user_info && a.useYn != "N" select a).Single();

                _update.userPassword = newPasswd;

                db.SaveChanges();
                mailSend(user_info, newPasswd, type, user_email);
            }




            return Redirect("/account/forgotResult?userMail=" + user_email + "&type=" + type);

        }

        public void mailSend(string user_info, string newPasswd, string type, string user_email)
        {
            string title = "";
            if (type == "1")
            {
                title = "아이디";
            }
            else if (type == "2")
            {
                title = "비밀번호";
            }

            MailMessage message = new MailMessage();
            var contentRootPath = (string)AppDomain.CurrentDomain.GetData("ContentRootPath");
            var webRootPath = (string)AppDomain.CurrentDomain.GetData("WebRootPath");
            // 보내는이 메일 주소
            message.From = new MailAddress("hansam@hansam.org");
            // 받는이 메일 주소
            message.To.Add(new MailAddress(user_email));
            // 참조 메일 주소
            //mailMessage.CC.Add("theblueeyecom@google.com");
            // 비공개 참조 메일 주소
            //mailMessage.Bcc.Add("theblueeyecom@google.com");
            // 본문의 포맷에 따라 선택
            message.IsBodyHtml = true;
            // 제목
            message.Subject = "콘택트사이언스 " + title + " 안내 메일입니다.";
            // 본문
            if (type == "1")
            {
                message.Body = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'> " +
    " <html xmlns='http://www.w3.org/1999/xhtml'>" +
    " <head><title>콘택트사이언스" + title + " 안내 메일입니다.</title>" +
    " <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>" +
    " <meta content= 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/></head>" +
    " <body bgcolor= '#fff' leftmargin = '0' topmargin = '0' marginwidth = '0' marginheight = '0' width='100%' height='100%' style='margin:0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;font-family:sans-serif;'>" +
    " <xmeta http-equiv='Content-Type' content='text/html;charset=utf-8'>" +
    " <xmeta http-equiv='Content-Script-Type' content='text/javascript'>" +
    " <xmeta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi, minimal-ui'>" +
    " <xmeta name='apple-mobile-web-app-capable' content='yes'>" +
    " <table border='0' align='center' cellpadding='0' cellspacing = '0'  style='display:block;border: #333333;position: relative; border:1px solid #ededed;border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto; padding: 30px 0 50px 0; box-sizing: border-box;' id='container' margin: 0 auto;width: 400px;> " +
    " <tr><td style='border-collapse: collapse; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;' >" +
    " <table border='0' cellpadding = '0' cellspacing = '0' width = '100%'  style='border-collapse: collapse;  -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;margin:0px 0 30px 0' >" +
    " <tr><td style='border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;' >" +
    " <table border='0' cellpadding = '0' cellspacing = '0' width = '100%' style = 'border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto; min-height: 90px; margin:10px 0;' >" +
    " <tr><td><h3 style='padding: 10px; text-align: center;'><img src = 'http://contactsci.theblueeye.com/searchfile/password.png' style = 'border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic;  max-width: 82px;' width = '100%' height = 'auto'></h3>" +
    " <h2 style='padding-left: 10px;'><span style='margin:0 3px 0 0;color:#26C6DA'> 회원님의 아이디 </span> 가 </br >발송되었습니다. </ h2 >" +
    " <hr style='width: 98%; border: 1px solid  #dddd' ></ td ></ tr >" +
    " <tr><td style = 'padding: 0 20px; padding-bottom: 30px;' > <h4 style = 'color: #444;' > 안녕하세요.</ h4 >" +
    " <h4 style='color: #444; margin-bottom: 33px;' > 회원님의 아이디를 아래와 같이 발송해 드렸습니다.</ h4 >" +
    " <table style='width: 100%;border: 3px solid #26C6DA; border-radius: 4px;margin-top:15px'><tr><td><h4 style='text-align: center; margin: 10px 0;'><span style='color: #444;'> 아이디 :</span><span> " + user_info + " </span></h4 >" +
    " </td></tr></table></td></tr><tr><td><hr style='width: 98%; border: 1px solid  #dddd'></td></tr></table></td></tr>" +
    " <tr><td style='text-align: center;'><a href = 'http://contactsci.theblueeye.com/Account/Login'  target='_blank' >" +
    "<button style='color: #fff;background-color: #17a2b8; border-color:#17a2b8;display: inline-block;font-weight: 400; text-align: center; white-space: nowrap;vertical-align: middle;-webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; border: 1px solid transparent; padding: .375rem .75rem; " +
    "font-size: 1rem; line-height: 1.5; border-radius: .25rem; cursor: pointer; min-height: 40px;'>로그인</button></a></td></tr></table></td></tr></table ></ xmeta ></ xmeta ></ xmeta ></ xmeta ></ body ></ html > ";

            }
            else
            {
                message.Body = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'> " +
    " <html xmlns='http://www.w3.org/1999/xhtml'>" +
    " <head><title>콘택트사이언스 " + title + " 안내 메일입니다.</title>" +
    " <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>" +
    " <meta content= 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/></head>" +
    " <body bgcolor= '#fff' leftmargin = '0' topmargin = '0' marginwidth = '0' marginheight = '0' width='100%' height='100%' style='margin:0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;font-family:sans-serif;'>" +
    " <xmeta http-equiv='Content-Type' content='text/html;charset=utf-8'>" +
    " <xmeta http-equiv='Content-Script-Type' content='text/javascript'>" +
    " <xmeta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi, minimal-ui'>" +
    " <xmeta name='apple-mobile-web-app-capable' content='yes'>" +
    " <table border='0' align='center' cellpadding='0' cellspacing = '0'  style='display:block;border: #333333;position: relative; border:1px solid #ededed;border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto; padding: 30px 0 50px 0; box-sizing: border-box;' id='container'margin: 0 auto;width: 400px; >" +
    " <tr><td style='border-collapse: collapse; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;' >" +
    " <table border='0' cellpadding = '0' cellspacing = '0' width = '100%'  style='border-collapse: collapse;  -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;margin:0px 0 30px 0' >" +
    " <tr><td style='border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;' >" +
    " <table border='0' cellpadding = '0' cellspacing = '0' width = '100%' style = 'border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto; min-height: 90px; margin:10px 0;' >" +
    " <tr><td><h3 style='padding: 10px;text-align: center;'><img src = 'http://contactsci.theblueeye.com/searchfile/password.png' style = 'border: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic;  max-width: 82px;' width = '100%' height = 'auto'></h3>" +
    " <h2 style='padding-left: 10px;'><span style='margin:0 3px 0 0;color:#26C6DA'> 임시비밀번호 </span> 가 </br >발급되었습니다. </ h2 >" +
    " <hr style='width: 98%; border: 1px solid  #dddd' ></ td ></ tr >" +
    " <tr><td style = 'padding: 0 20px; padding-bottom: 30px;' > <h4 style = 'color: #444;' > 안녕하세요.</ h4 >" +
    " <h4 style='color: #444; margin-bottom: 33px;' > 회원님의 임시 비밀번호를 아래와 같이 발급해 드렸습니다.</ h4 >" +
    " <table style='width: 100%;border: 3px solid #26C6DA; border-radius: 4px;margin-top:15px'><tr><td><h4 style='text-align: center; margin: 10px 0;'><span style='color: #444;'> 임시비밀번호 :</span><span> " + newPasswd + " </span></h4 >" +
    " </td></tr></table></td></tr><tr><td><hr style='width: 98%; border: 1px solid  #dddd'></td></tr></table></td></tr>" +
    " <tr><td style='text-align: center;'><a href = 'http://contactsci.theblueeye.com/Account/Login'  target='_blank' >" +
    "<button style='color: #fff;background-color: #17a2b8; border-color:#17a2b8;display: inline-block;font-weight: 400; text-align: center; white-space: nowrap;vertical-align: middle;-webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; border: 1px solid transparent; padding: .375rem .75rem; " +
    "font-size: 1rem; line-height: 1.5; border-radius: .25rem; cursor: pointer; min-height: 40px;'>로그인</button></a></td></tr></table></td></tr></table ></ xmeta ></ xmeta ></ xmeta ></ xmeta ></ body ></ html > ";

            }
            // 메일 제목 인코딩 타입(UTF-8) 선택
            message.SubjectEncoding = Encoding.UTF8;
            // 본문 인코딩 타입(UTF-8) 선택
            message.BodyEncoding = Encoding.UTF8;
            // 파일 첨부
            //mailMessage.Attachments.Add(new Attachment(new FileStream(@"D:\test.zip", FileMode.Open, FileAccess.Read), "test.zip"));
            //string pathToFiles = MyServer.MapPath("/UploadedFiles");
            //message.Body = MyServer.MapPath("mail.cshtml");
            SmtpClient client = new SmtpClient("smtp.gmail.com", 25);

            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential("contactSci2021", "blueeye0037!");
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Send(message);
        }

        public IActionResult ForgotResult(string userMail, string type)
        {

            return View();
        }



        #endregion



        //public void sms_send(string _msg)
        //{


        //    // POST, GET 보낼 데이터 입력
        //    string strUri = "http://sms.nanuminet.com/utf8.php";
        //    StringBuilder dataParams = new StringBuilder();
        //    string _now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        //    dataParams.Append("sms_id=leeyw94&");
        //    dataParams.Append("sms_pw=blueeye0037!&");
        //    dataParams.Append("callback=070-8244-8202&");
        //    dataParams.Append("senddate=" + _now + "&");
        //    dataParams.Append("return_url=http://desco.theblueeye.com/sys/sms_end&");
        //    dataParams.Append("return_data=&");
        //    dataParams.Append("use_mms=N&");
        //    dataParams.Append("upFile=&");
        //    dataParams.Append("phone[]=010-4490-0528&");
        //    dataParams.Append("msg[]=" + _msg + "&");




        //    // 요청 String -> 요청 Byte 변환
        //    byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());
        //    /* POST */

        //    // HttpWebRequest 객체 생성, 설정

        //    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri);

        //    request.Method = "POST";    // 기본값 "GET"

        //    request.ContentType = "application/x-www-form-urlencoded";

        //    request.ContentLength = byteDataParams.Length;

        //    Stream stDataParams = request.GetRequestStream();

        //    stDataParams.Write(byteDataParams, 0, byteDataParams.Length);
        //    //core 추가 시작===================================
        //    var response = (HttpWebResponse)request.GetResponse();
        //    //core 추가 끝===================================
        //    stDataParams.Close();


        //}


        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }
    }
}