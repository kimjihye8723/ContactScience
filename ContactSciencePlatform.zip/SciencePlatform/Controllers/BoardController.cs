﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
//using static SmartFactory.Controllers.SysController;
//using SmartFactory.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ReflectionIT.Mvc.Paging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using SmartFactory.Util;
using LazZiya.ImageResize;
using SciencePlatform.Models;
using System.Net.Mail;
using System.Net;

namespace SmartFactory.Controllers
{
    public class BoardController : Controller
    {
        private readonly db_e db = new db_e();
        //private string Comname = "blueeye";
        // GET: Board

        #region 첨부파일 변수
        private IHttpContextAccessor _accessor;
        // public static string company_id = "GoodDesign";
        private readonly long _fileSizeLimit;
        private readonly string[] _permittedExtensions = { ".txt", ".pdf", ".jpg", ".png", ".zip", ".gif", ".jpeg", ".hwp" };
        private readonly string _targetFilePath;
        public static IConfigurationRoot Configuration { get; set; }
        public BoardController(IConfiguration config)
        {
            _fileSizeLimit = config.GetValue<long>("FileSizeLimit");

            // To save physical files to a path provided by configuration:
            _targetFilePath = config.GetValue<string>("StoredFilesPath");

            // To save physical files to the temporary files folder, use:
            //_targetFilePath = Path.GetTempPath();
        }
        #endregion

        public ActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Board_List(int? cate, int? typeCompany, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            ViewBag.company_idx = company_idx;
            ViewBag.user_id = user_id;
            #endregion

            #region 변수설정
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;
            ViewBag.카테고리 = cate.ToString();

            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }

            if (auth >= 8)
            {
                //게시판 종류 드롭다운==============================================================================================================================================          
                var category =
                    db.BoardMenu.Where(
                        a =>
                        a.company_idx == company_idx && a.open_yn == "Y").Select(
                            a => new { 값 = a.idx, 이름 = a.title });
                ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
                //=====================================================================================================================================================================

            }
            else
            {
                //회사별 데이터 드롭다운==============================================================================================================================================          
                var category =
                    db.BoardMenu.Where(
                        a =>
                        a.company_idx == company_idx && ((a.department_idx == department_idx || a.open_yn == "Y"))).Select(
                             a => new { 값 = a.idx, 이름 = a.title });
                ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
                //=====================================================================================================================================================================
            }

            ////======================================================================================================================================================== 
            //var company_type =
            //    db.company.Where(p => (p.company_type != null && p.use_yn == "Y" && p.idx != 4)).OrderBy(
            //        o => o.index_order).Select(c => new { 값 = c.idx, 이름 = c.company_name });
            //ViewBag.요청회사 = new SelectList(company_type.AsEnumerable(), "값", "이름");
            ////======================================================================================================================================================== 

            #endregion

            var query = db.BoardList.AsNoTracking().Where(a => a.useable != "N" && a.BM_idx == cate && a.reply == null);

            


            var model = await PagingList.CreateAsync(query, 10, page, sortExpression, "-idx");

            model.RouteValue = new RouteValueDictionary {
                { "search_all", search_all},
                { "search_all_type", search_all_type}                
            };

            if (!string.IsNullOrEmpty(search_all))
            {
               
                query = query.Where(p => p.title.Contains(search_all) || p.content.Contains(search_all) || p.writer.Contains(search_all));
             

                model = await PagingList.CreateAsync(query, 20, page, sortExpression, "-idx");

                model.RouteValue = new RouteValueDictionary {
                { "search_all", search_all},
                { "search_all_type", search_all_type}

            };

            }
            ViewBag.query_c = query.Count();
            //권한 시작==============================================================================================
            BoardAuth(null, cate, null);
            //권한 끝================================================================================================

            return View(model );

        }

        public ActionResult BoardView(int idx, int? cate, int? typeIdx, int? classIdx)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            ViewBag.company_idx = company_idx;
            ViewBag.user_id = user_id;
            #endregion

            if (idx == 0)
            {
                //0번 게시글은 임시글로써, DB에 존재하지 않는 글임
                return NotFound();
            }

            //권한 시작==============================================================================================
             BoardAuth(idx, cate, typeIdx);
            //권한 끝================================================================================================

            BoardList data = db.BoardList.Find(idx);

            #region 파일 가져오기
            //파일 가져오기=====================================================================================================================                    

            var _list = (from a in db.BoardFile where a.Md_id == data.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();

            ViewBag.이미지리스트 = _list;
            ViewBag.이미지리스트카운트 = _list.Count();

            //파일 끝============================================================================================================================ 
            #endregion

            #region 조회수 증가
          
            data.hit = data.hit + 1; ;

            db.SaveChanges(); // 실제로 저장 


            #endregion

            #region 읽은 사용자 저장

            int _readCount = (from a in db.BoardRread where a.board_idx == idx && a.user_id == User.Identity.Name select a.idx).Count();

            if (_readCount == 0)
            {

                var _insert = new BoardRread
                {
                    user_id = User.Identity.Name,
                    user_name = (from a in db.user where a.userId == User.Identity.Name select a.userName).FirstOrDefault(),
                    read_date = DateTime.Now,
                    board_idx = idx

                };

                db.BoardRread.Add(_insert);
                db.SaveChanges(); // 실제로 저장 
            }


            var _read = (from a in db.BoardRread where a.board_idx == idx  select a).ToList();

            ViewBag.읽은사람 = _read;

            #endregion

            #region 코멘트 가져오기

            IQueryable <BoardComment> _listComent = Enumerable.Empty<BoardComment>().AsQueryable();

            _listComent = db.BoardComment.Where(p => p.BD_idx == idx && p.use_yn != "D").OrderByDescending(o => o.idx);

            ViewBag.댓글 = _listComent;
            ViewBag.댓글수 = _listComent.Count();
            #endregion


            //mailSend();
            return View(data);
        }


        public async Task<JsonResult> ckeditor_fileUp()
        {
            try
            {

                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
                Configuration = builder.Build();
                string Models_photo = Configuration["user_app:file_list"];



                var uploads = Path.Combine(Models_photo, "images/vehicle-key");
                var filePath = Path.Combine(uploads, "rich-text");
                var urls = new List<string>();

                //If folder of new key is not exist, create the folder.
                if (!Directory.Exists(filePath)) Directory.CreateDirectory(filePath);

                foreach (var contentFile in Request.Form.Files)
                {
                    if (contentFile != null && contentFile.Length > 0)
                    {
                        await contentFile.CopyToAsync(new FileStream($"{filePath}\\{contentFile.FileName}", FileMode.Create));
                        urls.Add($"{HttpContext.Request.Host}/rich-text/{contentFile.FileName}");
                    }
                }

                return Json(urls);
            }
            catch (Exception e)
            {
                return Json(new { error = new { message = e.Message } });
            }

        }


        private void mailSend()
        {      

            //해당 과학자가 해당 클래스 당 QNA 게시판에 미 답변시, 메일링 추가
            var _listComent2 = db.commentsView.Where(a => a.useable != "N" && a.BM_idx ==6 && a.writeDate.AddDays(5) <= DateTime.Now && a.commentsYn == null && a.mailYn != "Y" ).ToList();
          
            ViewBag.qna코멘트 = _listComent2;
            ViewBag.qna코멘트c = _listComent2.Count();                    

            if (ViewBag.qna코멘트c > 0)
            {
                foreach (var item in _listComent2)
                {
                    MailMessage message = new MailMessage();
                    var contentRootPath = (string)AppDomain.CurrentDomain.GetData("ContentRootPath");
                    var webRootPath = (string)AppDomain.CurrentDomain.GetData("WebRootPath");
                    // 보내는이 메일 주소
                    message.From = new MailAddress("hansam@hansam.org");
                    // 받는이 메일 주소
                    message.To.Add(new MailAddress(item.userEmail));
                    // 참조 메일 주소
                    //mailMessage.CC.Add("theblueeyecom@google.com");
                    // 비공개 참조 메일 주소
                    //mailMessage.Bcc.Add("theblueeyecom@google.com");
                    // 본문의 포맷에 따라 선택
                    message.IsBodyHtml = true;
                    // 제목
                    message.Subject = "콘택트 사이언스 클래스명: [" + item.classInfoTilte + "]의 QNA게시판 과학자 답변 요청 안내 메일입니다.";
                    // 본문

                    message.Body = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'> " +
                   " <html xmlns='http://www.w3.org/1999/xhtml'>" +
                   " <head><title> 콘택트 사이언스 QnA게시판 답변 미등록 안내 메일입니다 </title>" +
                   " <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>" +
                   " <meta content= 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/></head>" +
                   " <body bgcolor= '#fff' leftmargin = '0' topmargin = '0' marginwidth = '0' marginheight = '0' width='100%' height='100%' style='margin:0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;font-family:sans-serif;'>" +
                   " <xmeta http-equiv='Content-Type' content='text/html;charset=utf-8'>" +
                   " <xmeta http-equiv='Content-Script-Type' content='text/javascript'>" +
                   " <xmeta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi, minimal-ui'>" +
                   " <xmeta name='apple-mobile-web-app-capable' content='yes'>" +
                   // 본문 내용 - 테이블 형식으로 
                   "<table border='0' align='center' cellpadding='0' cellspacing='0' width='calc((400px - 100 %) * 400)' style='border: #333333;position: relative; border:1px solid #ededed;border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto; padding: 30px 0 30px 0; box-sizing: border-box;'> " +
                   "<tr><td style='border-collapse: collapse; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;'> " +
                   "<table border='0' cellpadding='0' cellspacing='0' width='100% ' style='border-collapse: collapse; -ms-text-size-adjust: 100 %; -webkit-text-size-adjust: auto; margin: .5vh 0 .5vh 0'>" +
                   "<tr><td><h3 style = 'text-align: center; font-weight: bold;'> <img src='http://contactsci.theblueeye.com/searchfile/logo.png' style='width: 100%; max-width: 150px; height: auto;'></h3></td ></tr> " +
                   "<tr><td style='border-collapse: collapse; -ms-text-size-adjust: 100 %; -webkit-text-size- djust: auto;'>" +
                   "<table border='0' cellpadding='0' cellspacing='0' width='100%' style='border - collapse: collapse; -ms-text-size-adjust: 100 %; -webkit-text-size-adjust: auto; margin-top: 30px; '>" +
                   "<tr><td style='margin: 120px auto; '><h3 style = 'text-align: center; font-weight: bold;'> <img src='http://contactsci.theblueeye.com/searchfile/mailNotice2.png' style = 'width: 100%; max-width: 140px; height: auto;'> </h3 ></td ></tr>" +
                   "<tr><td style = 'width: 100%; padding: 10px 0;' ><h3 style = 'text-align: center; font-weight: bold;padding: 0 20px;' > 콘택트 사이언스 QnA 게시판 답변 미등록 안내 메일입니다 </ h3 ></ td > </ tr > " +
                   "<tr style='display: table;width:100%; margin:0 auto;text-align:cetner;'><td style = 'width: 2%;'></td> <td style = 'width: 96%; padding: 40px 0px; background-color:rgba(226,227,225,.3); border-radius: 5px;'><h2 style = 'text-align: center; font-weight: bold; margin: 15px 0 40px;'> 안내사항 </h2 > " +
                   "<p style='padding: 0 20px; text-align:center;'>회원님의 클래스명: [" + item.classInfoTilte + "]의 QnA 게시판에<br> [" + item.BoardList_writer + "]님이 올리신 제목[" + item.BoardList_title + "]글에 답변이 <span style='font - weight: bolder; font - size: 1.2em;'> 미등록된 상태 </span>입니다. </p>" +
                   "<p style='text-align:center; padding: 0 20px'> 답변을 달아주세요 😊</p></ td ><td style = 'width: 2%' ></ td ></ tr > " +
                   "<tr> <td style = ' padding: 40px 10px; border-radius: 5px; text-align: center;'>"+
                   "<a href = 'http://contactsci.theblueeye.com/'target='_blank'><button style = 'background-color: #6DB9F8; border-color:#6DB9F8;display: inline-block; text-align: center; font-size: 1rem; line-height: 1.5; border-radius: 8rem; cursor: pointer; color:#000;font-weight: bold; padding: 2px 12px;min-height:30px'> 콘택트 사이언스로 가기</button ></a >" +
                   "</td></tr ></table ></td ></tr></table> "+
                   // 본문내용,테이블 끝
                   "</ xmeta ></ xmeta ></ xmeta ></ xmeta ></ body ></ html > ";


                    // 메일 제목 인코딩 타입(UTF-8) 선택
                    message.SubjectEncoding = Encoding.UTF8;
                    // 본문 인코딩 타입(UTF-8) 선택
                    message.BodyEncoding = Encoding.UTF8;
                    // 파일 첨부
                    //mailMessage.Attachments.Add(new Attachment(new FileStream(@"D:\test.zip", FileMode.Open, FileAccess.Read), "test.zip"));
                    //string pathToFiles = MyServer.MapPath("/UploadedFiles");
                    //message.Body = MyServer.MapPath("mail.cshtml");
                    SmtpClient client = new SmtpClient("smtp.gmail.com", 25);

                    client.EnableSsl = true;
                    client.UseDefaultCredentials = false;
                    //구글 계정 아이디, 비밀번호
                    client.Credentials = new NetworkCredential("contactSci2021", "blueeye0037!");
                    client.Send(message);

                    //메일보냈으면 상태 변경 - 수동업데이트 
                    #region 수동 업데이트
                    BoardList _update =
                             (from a in db.BoardList where a.idx == item.BoardList_idx select a).Single();

                    _update.mailYn = "Y";
                    db.SaveChanges(); // 실제로 저장  
                    #endregion

                }

            }


        }

        public ActionResult mailSend2()
        {

            string toUser =  "newri0807@gamil.com";
            MailMessage message = new MailMessage();
            var contentRootPath = (string)AppDomain.CurrentDomain.GetData("ContentRootPath");
            var webRootPath = (string)AppDomain.CurrentDomain.GetData("WebRootPath");
            // 보내는이 메일 주소
            message.From = new MailAddress("ceo@theblueeye.com");
            // 받는이 메일 주소
           // message.To.Add(new MailAddress(item.userEmail));
            message.To.Add(new MailAddress(toUser));
            // 참조 메일 주소
            //mailMessage.CC.Add("theblueeyecom@google.com");
            // 비공개 참조 메일 주소
            //mailMessage.Bcc.Add("theblueeyecom@google.com");
            // 본문의 포맷에 따라 선택
            message.IsBodyHtml = true;
            // 제목
          //  message.Subject = "콘택트 사이언스 클래스명: [" + item.classInfoTilte + "]의 QNA게시판 과학자 답변 요청 안내 메일입니다.";
            message.Subject = "콘택트 사이언스 클래스명:  QNA게시판 과학자 답변 요청 안내 메일입니다.";
            // 본문

            message.Body = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'> " +
           " <html xmlns='http://www.w3.org/1999/xhtml'>" +
           " <head><title> 콘택트 사이언스 QnA게시판 답변 미등록 안내 메일입니다 </title>" +
           " <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>" +
           " <meta content= 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/></head>" +
           " <body bgcolor= '#fff' leftmargin = '0' topmargin = '0' marginwidth = '0' marginheight = '0' width='100%' height='100%' style='margin:0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;font-family:sans-serif;'>" +
           " <xmeta http-equiv='Content-Type' content='text/html;charset=utf-8'>" +
           " <xmeta http-equiv='Content-Script-Type' content='text/javascript'>" +
           " <xmeta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi, minimal-ui'>" +
           " <xmeta name='apple-mobile-web-app-capable' content='yes'>" +
           // 본문 내용 - 테이블 형식으로 
           "<table border='0' align='center' cellpadding='0' cellspacing='0' width='calc((400px - 100 %) * 400)' style='border: #333333;position: relative; border:1px solid #ededed;border-collapse: collapse;   -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto; padding: 30px 0 30px 0; box-sizing: border-box;'> " +
           "<tr><td style='border-collapse: collapse; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: auto;'> " +
           "<table border='0' cellpadding='0' cellspacing='0' width='100% ' style='border-collapse: collapse; -ms-text-size-adjust: 100 %; -webkit-text-size-adjust: auto; margin: .5vh 0 .5vh 0'>" +
           "<tr><td><h3 style = 'text-align: center; font-weight: bold;'> <img src='http://contactsci.theblueeye.com/searchfile/logo.png' style='width: 100%; max-width: 150px; height: auto;'></h3></td ></tr> " +
           "<tr><td style='border-collapse: collapse; -ms-text-size-adjust: 100 %; -webkit-text-size- djust: auto;'>" +
           "<table border='0' cellpadding='0' cellspacing='0' width='100%' style='border - collapse: collapse; -ms-text-size-adjust: 100 %; -webkit-text-size-adjust: auto; margin-top: 30px; '>" +
           "<tr><td style='margin: 120px auto; '><h3 style = 'text-align: center; font-weight: bold;'> <img src='http://contactsci.theblueeye.com/searchfile/mailNotice2.png' style = 'width: 100%; max-width: 140px; height: auto;'> </h3 ></td ></tr>" +
           "<tr><td style = 'width: 100%; padding: 10px 0;' ><h3 style = 'text-align: center; font-weight: bold;padding: 0 20px;' > 콘택트 사이언스 QnA 게시판 답변 미등록 안내 메일입니다 </ h3 ></ td > </ tr > " +
           "<tr style='display: table;width:100%; margin:0 auto;text-align:cetner;'><td style = 'width: 2%;'></td> <td style = 'width: 96%; padding: 40px 0px; background-color:rgba(226,227,225,.3); border-radius: 5px;'><h2 style = 'text-align: center; font-weight: bold; margin: 15px 0 40px;'> 안내사항 </h2 > " +
           "<p style='padding: 0 20px; text-align:center;'>회원님의 클래스명: [item.classInfoTilte ]의 QnA 게시판에<br> [ item.BoardList_writer ]님이 올리신 제목[item.BoardList_title ]글에 답변이 <span style='font - weight: bolder; font - size: 1.2em;'> 미등록된 상태 </span>입니다. </p>" +
           "<p style='text-align:center; padding: 0 20px'> 답변을 달아주세요 😊</p></ td ><td style = 'width: 2%' ></ td ></ tr > " +
           "<tr> <td style = ' padding: 40px 10px; border-radius: 5px; text-align: center;'>" +
           "<a href = 'http://contactsci.theblueeye.com/'target='_blank'><button style = 'background-color: #6DB9F8; border-color:#6DB9F8;display: inline-block; text-align: center; font-size: 1rem; line-height: 1.5; border-radius: 8rem; cursor: pointer; color:#000;font-weight: bold; padding: 2px 12px;min-height:30px'> 콘택트 사이언스로 가기</button ></a >" +
           "</td></tr ></table ></td ></tr></table> " +
           // 본문내용,테이블 끝
           "</ xmeta ></ xmeta ></ xmeta ></ xmeta ></ body ></ html > ";


            // 메일 제목 인코딩 타입(UTF-8) 선택
            message.SubjectEncoding = Encoding.UTF8;
            // 본문 인코딩 타입(UTF-8) 선택
            message.BodyEncoding = Encoding.UTF8;
            // 파일 첨부
            //mailMessage.Attachments.Add(new Attachment(new FileStream(@"D:\test.zip", FileMode.Open, FileAccess.Read), "test.zip"));
            //string pathToFiles = MyServer.MapPath("/UploadedFiles");
            //message.Body = MyServer.MapPath("mail.cshtml");
            SmtpClient client = new SmtpClient("smtp.gmail.com", 25);

            client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            //구글 계정 아이디, 비밀번호
            client.Credentials = new NetworkCredential("contactSci2021", "blueeye0037!");
            client.Send(message);

            ViewBag.알림 = "ok";

            return View();
        }


        [Authorize]
            public ActionResult BoardWrite(BoardList doc,int? idx, int? cate, int? typeIdx, int? classIdx, string admin)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            int user_idx = Convert.ToInt32(UserData.user_get(user_id, "user_idx"));
            #endregion

            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }

            if (typeIdx != null)
            {
                var _typeIdx = (from a in db.BoardMenu where a.BoardType_idx == typeIdx select a).FirstOrDefault();
                ViewBag.타입 = _typeIdx.BoardType_idx;
                ViewBag.타이틀 = _typeIdx.title;

                //var user_idx = db.user.Where(a => a.userId == user_id && a.useYn != "N").FirstOrDefault();
                var orderCk = db.orderClassDetail.Where(a => a.userIdx == user_idx).ToList();
                

                //if (typeIdx == 6) //후기 일반사용자
                //{
                //    var review =
                //   db.orderClassDetail.Where(p => p.useYn != "N" && p.classIdxNavigation.endDate >= DateTime.Now && p.userIdx == user_idx).Include(p => p.classIdxNavigation).OrderByDescending(o => o.writeDate)
                //   .Select(c => new { 값 = c.classIdxNavigation.rBoardCate, 이름 = c.classIdxNavigation.className + "(" + c.classIdxNavigation.startDate.ToString("yyyy-MM-dd") + "~" + c.classIdxNavigation.endDate.ToString("yyyy-MM-dd") + ")" });
                //    ViewBag.완료클래스 = new SelectList(review.AsEnumerable(), "값", "이름");
                //}
                //else if (typeIdx == 7) //QNA 일반사용자
                //{
                //    var qna =
                //db.classInfo.Where(p => p.useYn != "N").OrderByDescending(o => o.writeDate)
                //.Select(c => new { 값 = c.qBoardCate, 이름 = c.className + "(" + c.startDate.ToString("yyyy-MM-dd") + "~" + c.endDate.ToString("yyyy-MM-dd") + ")" });
                //    ViewBag.완료클래스 = new SelectList(qna.AsEnumerable(), "값", "이름");
                //}
                //else 
                if (typeIdx == 8) // 공지 과학자
                {
                    var notice =
                   db.classInfo.Where(p => p.useYn != "D" && p.managerIdxNavigation.userId == user_id).OrderByDescending(o => o.writeDate)
                   .Select(c => new { 값 = c.idx, 이름 = c.className + "(" + c.startDate.ToString("yyyy-MM-dd") + "~" + c.endDate.ToString("yyyy-MM-dd") + ")" });
                    ViewBag.완료클래스 = new SelectList(notice.AsEnumerable(), "값", "이름");
                }

            }


            if (idx != null)
            {
                //수정모드
                doc = db.BoardList.Find(idx);

                #region 첨부파일 가져오기
                var _list = (from a in db.BoardFile where a.Md_id == doc.fileId && a.use_yn != "N" select a).OrderByDescending(p => p.id).ToList();
                ViewBag.이미지리스트 = _list;
                ViewBag.이미지리스트카운트 = _list.Count(); 
                #endregion

            }
            else
            {
                ViewBag.이미지리스트 = "";
                ViewBag.이미지리스트카운트 = 0;
            }

            BoardAuth(idx, cate, typeIdx);

            return View(doc);
        }      

        [Authorize]
        public async Task<IActionResult> Board_action(BoardList doc , int? idx, string beforeP, int cate, int? typeIdx, int? classIdx, int? prev, int? productIdx, string admin, string mode_type, List<IFormFile> files, string useable, string referer)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion


            string file_id = "";
            string msg = "";
            if (doc.useable == null)
            {
                useable = "Y";
            }

            if (productIdx != null)
            {
                if (idx == null)
                {
                    msg = "S";

                    file_id = DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                    #region 저장                  
                    doc.fileId = file_id;
                    doc.useable = useable;
                    doc.writeDate = DateTime.Now;
                    doc.editDate = DateTime.Now;
                    doc.classIdx = classIdx ?? 0;
                    doc.productIdx = productIdx;
                    db.BoardList.Add(doc);
                    db.SaveChanges(); // 실제로 저장 

                    #endregion




                }
                else
                {
                    int _idx = Convert.ToInt32(idx);

                    if (mode_type == "D")
                    {
                        #region 삭제

                        msg = "D";
                        BoardList _update =
                         (from a in db.BoardList where a.idx == idx select a).Single();

                        _update.useable = "N";
                        _update.delDate = DateTime.Now;

                        db.SaveChanges(); // 실제로 저장 

                        #endregion
                    }
                    else
                    {
                        #region 수정
                        msg = "E";
                        #region 파일 아이디
                        file_id = doc.fileId;

                        if (string.IsNullOrEmpty(file_id))
                        {

                            file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                            doc.fileId = file_id;
                        }
                        #endregion

                   
                        doc.useable = useable;
                        doc.editDate = DateTime.Now;
                        doc.writeDate = DateTime.Now;
                        db.Entry(doc).State = EntityState.Modified;

                        // mainYn,commuYn  제외 업데이트=================================
                        db.Entry(doc).Property("mainYn").IsModified = false;
                        db.Entry(doc).Property("commuYn").IsModified = false;
                        //==================================================
                        db.SaveChanges();



                        #endregion
                    }
                }

            }
            else
            {
                var sciCklist = db.user.Where(a => a.userId == user_id && a.useYn != "N").FirstOrDefault();
                var sciCk = sciCklist.userClass;

                var dataroomCk = db.BoardMenu.Where(p => p.userIdx == sciCklist.idx && p.BoardType_idx == 10).FirstOrDefault();


                if (idx == null)
                {
                    msg = "S";

                    file_id = DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                    #region 저장                  
                    doc.fileId = file_id;
                    doc.writeDate = DateTime.Now;
                    doc.editDate = DateTime.Now;
                    doc.useable = useable;
                    if (dataroomCk != null)
                    {
                        doc.BM_idx = dataroomCk.idx;
                    }

                    //doc.company_idx = company_idx;
                    db.BoardList.Add(doc);
                    db.SaveChanges(); // 실제로 저장 


                    #endregion




                }
                else
                {
                    int _idx = Convert.ToInt32(idx);

                    if (mode_type == "D")
                    {
                        #region 삭제

                        msg = "D";
                        BoardList _update =
                         (from a in db.BoardList where a.idx == idx select a).Single();

                        _update.useable = "N";
                        _update.delDate = DateTime.Now;

                        db.SaveChanges(); // 실제로 저장 

                        #endregion
                    }
                    else
                    {
                        #region 수정
                        msg = "E";
                        #region 파일 아이디
                        file_id = doc.fileId;

                        if (string.IsNullOrEmpty(file_id))
                        {

                            file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();

                            doc.fileId = file_id;
                        }
                        #endregion

                        doc.useable = useable;
                        doc.editDate = DateTime.Now;
                        doc.writeDate = DateTime.Now;
                        db.Entry(doc).State = EntityState.Modified;
                        db.SaveChanges();



                        #endregion
                    }
                }

            }






            #region 파일 올리기


            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id+ DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName); 
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            //===============================================================================
            UserData history = new UserData();
            history.History_write(User.Identity.Name, "/board/boardwrite/cate=" + cate, msg);
            //==============================================================================

            //string returnUrl = "/board/board_list?cate=" + cate;

            //if (classIdx != null && typeIdx == null) 
            //{
            //    returnUrl = "/ClassSqure/classInfo?idx=" + classIdx + "&scrollT=Y&prev="+ cate;
            //}            
            //else if (productIdx != null) // 사이언스몰 > 리뷰,qna게시판 작성 후 
            //{
            //    if (cate == 8 ) // 상품리뷰
            //    {
            //        returnUrl = "/sciMall/proDetail?idx=" + productIdx + "&scrollT=Y&prev=22";

            //    }
            //    else // 상품 qna
            //    {
            //        returnUrl = "/sciMall/proDetail?idx=" + productIdx + "&scrollT=Y&prev=44";

            //    }

            //}        
            //else if (typeIdx != null)
            //{
            //    if (classIdx != null) // 클래스 광장 > 후기글 작성 후 
            //    {
            //        returnUrl = "/ClassSqure/classInfo?idx=" + classIdx;
            //    }
            //    else
            //    {
            //        returnUrl = "/board/boardAdmin?typeIdx=" + typeIdx + "&cate=" + cate;
            //    }
          
            //}else if(beforeP == "myWriting") // 일반유저 > 마이페이지> 작성한 글 확인 
            //{
            //    returnUrl = "/mypage/myWriting?prev="+cate;
            //}
            //else 
            //{              
            //    returnUrl = "Board_list?cate=" + cate;
            //}


            string param = "&";

            if (referer != "")
            {
                if (!referer.Contains("?"))
                {
                    param = "?";
                }
            
            }               

            if (prev != null) // 사이언스몰 > qna, 리뷰 게시판 작성완료시
            {

                referer = referer + param + "prev=" + prev + "&msg=" + msg;
            }
            else
            {
                if (classIdx != null && typeIdx == null) // 클래스 상세페이지 >qna 작성완료 시 
                {
                    referer = referer + param + "scrollT=Y&prev=" + prev + "&msg=" + msg;
                }
                else // 참여과학자 > qna 작성시 
                {
                    referer = referer + param + "msg=" + msg;
                }
            }
            
            return Redirect(referer);

        }


        //비회원 로그인
        public async Task<ActionResult> non_member_login(string non_name, string non_password, int idx, int cate)
        {

            var sb = new StringBuilder();



            var list = (from a in db.BoardList where a.idx == idx && a.writer == non_name && a.password == non_password select a).FirstOrDefault();

            string password = "xxz@@";

            if (list != null)
            {
                password = list.password;
            }



            if (non_password == password)
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("$('#none_edit').css('display' ,'block') ; ");
                sb.AppendFormat("alert('비회원 로그인 하셨습니다. ') ;");
                sb.AppendFormat("$('#writer').val('" + non_name + "') ; ");
                sb.AppendFormat("$('.comment_view').css('display' ,'block') ; ");
                sb.AppendFormat("$('.secret').css('display' ,'block') ; ");
                sb.AppendFormat("$('.secret-span').css('display' ,'none') ; ");
                sb.AppendFormat("$('.non_form').css('display' ,'none') ; ");
                sb.AppendFormat("</script>");
                await Response.WriteAsync(sb.ToString());
            }
            else
            {
                sb.AppendFormat("<script>");
                sb.AppendFormat("alert('이름 또는 비밀번호가 일치하지 않습니다. 다시 시도해 주세요 ') ;");
                sb.AppendFormat("$('#non_name').val('') ; ");

                sb.AppendFormat("$('#non_password').val('') ; ");
                sb.AppendFormat("$('.comment_view').css('display' ,'none') ; ");
                sb.AppendFormat("</script>");
                await Response.WriteAsync(sb.ToString());
            }




            return null;
        }



        [HttpPost]
        public async Task<IActionResult> BoardImageUpload(string CKEditorFuncNum, IFormFile upload)
        {

            #region 파일 올리기

            string user_id = User.Identity.Name;
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");




            var formFileContent =
                await FileHelpers
                    .ProcessFormFile<IFormFile>(
                        upload, ModelState, _permittedExtensions,
                        _fileSizeLimit);



            // 변수 =========================================================================================================================
            string only = DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                           
            var _fileName = only + Path.GetFileName(upload.FileName);     // 신규 파일 이름                    
            var _local_path = _targetFilePath + company_id + "/";            // 신규 파일 경로
            var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로

            string ImagePath = Models_photo + company_id + "/" + _fileName;
          

          

            //경로에 폴더가 없으면 만들어준다.=============================================
            var dInfo = new DirectoryInfo(_local_path);

            if (!dInfo.Exists)
            {
                dInfo.Create();
            }

            //=================================================================================



            using (var fileStream = System.IO.File.Create(filePath))
            {
                await fileStream.WriteAsync(formFileContent);

            }

          

            var sb = new StringBuilder();
            sb.AppendFormat("<script>");
            sb.AppendFormat("window.parent.CKEDITOR.tools.callFunction('" + CKEditorFuncNum +   "', '" + ImagePath +  "', 'OK'); ");
            sb.AppendFormat("history.go(-1)");
            sb.AppendFormat("</script>");
            await  Response.WriteAsync(sb.ToString());


            #endregion

            return null;

         }

        public ActionResult del_set_check(BoardList doc, int file_idx)
        {

            BoardList _updateContent =
                    (from a in db.BoardList where a.idx == doc.idx select a).Single();

            _updateContent.title = doc.title;
            _updateContent.content = doc.content;
            _updateContent.editDate = DateTime.Now;         

            db.SaveChanges(); // 실제로 저장 

            #region 삭제

            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();
            _update.use_yn = "N";           

            db.SaveChanges(); // 실제로 저장 

            #endregion                       

            return Redirect("/board/BoardWrite?cate="+doc.BM_idx+"&idx="+ doc.idx);
        }


        #region 첨부파일 삭제 처리
        /// <summary>
        /// 드래그 첨부파일 삭제
        /// </summary>
        /// <param name="file_idx">고유값</param>
        /// <param name="url">리턴 경로</param>
        /// <returns></returns>
        public ActionResult del_file(int file_idx, string url)
        {


            #region 파일 상태 변경


            BoardFile _update =
             (from a in db.BoardFile where a.id == file_idx select a).Single();

            _update.use_yn = "N";

            db.SaveChanges(); // 수정 

            #endregion


            return Redirect(url);
        }

        /// <summary>
        /// 리스트 첨부파일 삭제
        /// </summary>
        /// <param name="doc_it"></param>
        /// <returns></returns>
        public ActionResult file_set_del(int doc_it) //디자인 담당자 정보 Load 
        {
            var sb = new StringBuilder();




            #region 수동 업데이트
            try
            {
                BoardFile _update = (from a in db.BoardFile where a.id == doc_it select a).Single();

                _update.use_yn = "N";

                db.SaveChanges(); // 실제로 저장  


                sb.AppendFormat("<script>");

                sb.AppendFormat("$('#f_" + doc_it + "').css('display' ,'none');");

                sb.AppendFormat("alert('삭제되었습니다.') ;");

                sb.AppendFormat("</script>");


            }
            catch
            {

                sb.AppendFormat("<script>");

                sb.AppendFormat("alert('다시 시도해주세요.') ;");

                sb.AppendFormat("</script>");
            }
            #endregion






            Response.WriteAsync(sb.ToString());


            return null;
        } 
        #endregion

        public IActionResult GetDownload(string link, string file_name)
        {
            var net = new System.Net.WebClient();
            var data = net.DownloadData(link);
            var content = new System.IO.MemoryStream(data);
            var contentType = "application/force-download";
           
            return File(content, contentType, file_name);
        }

        public void ResizeImage(string _path, IFormFile uploadedFile, string file_name, int desiredWidth, int desiredHeight)
        {
            string webroot = _path;
            try
            {
                if (uploadedFile.Length > 0)
                {
                    using (var stream = uploadedFile.OpenReadStream())
                    {
                        var uploadedImage = System.Drawing.Image.FromStream(stream);

                        //decide how to scale dimensions
                        if (desiredHeight == 0 && desiredWidth > 0)
                        {
                            var img = ImageResize.ScaleByWidth(uploadedImage, desiredWidth); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else if (desiredWidth == 0 && desiredHeight > 0)
                        {
                            var img = ImageResize.ScaleByHeight(uploadedImage, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                        else
                        {
                            var img = ImageResize.Scale(uploadedImage, desiredWidth, desiredHeight); // returns System.Drawing.Image file
                            img.SaveAs(Path.Combine(webroot, file_name));
                        }
                    }
                }
            }
            catch { }
            return;
        }

        public ActionResult BoardComment_action(BoardComment doc,string BD_idx, string cate, string mode_type, int? c_idx, int? typeIdx)
        {
            int idx = 0;
           
            string msg = "";
          
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            if (c_idx ==null)
            {
                #region 저장

                doc.write_date = DateTime.Now;
                doc.writer = User.Identity.Name;
                doc.edit_date = DateTime.Now;
                doc.use_yn = "Y";              
                db.BoardComment.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {               

                if (mode_type == "D")
                {
                    #region 삭제

                    BoardComment doc_del = db.BoardComment.Single(x => x.idx == c_idx);
                    db.BoardComment.Remove(doc_del);
                    db.SaveChanges();

                    msg = Util.msg.msg_del;

                    #endregion
                }

                else if (mode_type == "E")
                {
                    #region 임시 삭제 / 상태 변환 업데이트

                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == c_idx select a).Single();
                    _update.edit_date = DateTime.Now;
                    _update.use_yn = "D";
                    _update.writer = User.Identity.Name;                 

                    db.SaveChanges(); // 실제로 저장 


                    msg = Util.msg.msg_disable;

                    #endregion
                }
                else
                {
                    #region 수정


                    BoardComment _update =
                        (from a in db.BoardComment where a.idx == idx select a).Single();
                 
                    _update.edit_date = DateTime.Now;                   
                    _update.memo = doc.memo;


                    db.SaveChanges(); // 실제로 저장 



                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }
            string url = "/board/boardview?typeIdx="+ typeIdx+"&cate=" + cate +"&idx=" + BD_idx ;

            return Redirect(url);
                
        }

        [Authorize]
        public ActionResult board_set(BoardMenu doc, int? idx)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            #region Select Box
            //======================================================================================================================================================== 
            var Code_company =
                db.company.Where(p => p.useYn != "N" && p.idx == company_idx).OrderBy(o => o.indexOrder).Select(
                    c => new { 값 = c.idx, 이름 = c.companyName });
            ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
            //========================================================================================================================================================           

            //========================================================================================================================================================
            var _department = db.department.Where(p => p.company_idx == company_idx && p.use_yn != "N").OrderBy(P => P.index_order).Select(c => new { 값 = c.idx, 이름 = c.department_name });
            ViewBag.부서 = new SelectList(_department.AsEnumerable(), "값", "이름");
            //========================================================================================================================================================

            //========================================================================================================================================================
            var BoardCode = db.BoardCode.Where(p => p.use_yn != "N").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            ViewBag.게시판코드 = new SelectList(BoardCode.AsEnumerable(), "값", "이름");
            //======================================================================================================================================================== 
            #endregion

            if (idx != null)
            {
              
                doc = db.BoardMenu.Single(x => x.idx == idx);
            }

            return View(doc);
        }

        [Authorize]
        public ActionResult board_set_list()
        {          

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            IQueryable<BoardMenu> _list = Enumerable.Empty<BoardMenu>().AsQueryable();

            if (auth >= 7)
            {
                _list = db.BoardMenu.Where(p=> p.open_yn == "Y" && p.company_idx == company_idx).OrderBy(o => o.idx);
            }
            else
            {
                _list = db.BoardMenu.Where(p => p.department_idx == department_idx && p.open_yn =="Y").OrderBy(o => o.idx);
            }

            return View(_list.ToList());
        }

        public ActionResult board_set_action(BoardMenu doc, int? idx, string mode_type)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            string msg = "";        

            if (doc.open_yn == "on")
            {
                doc.open_yn = "Y";
            }
            else
            {
                doc.open_yn = "N";
            }

            if (idx == null)
            {
                #region 저장

              

                db.BoardMenu.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {              

                if (mode_type == "D")
                {
                    #region 삭제

                 

                    BoardMenu _update =
                      (from a in db.BoardMenu where a.idx == idx select a).Single();
                    _update.open_yn = "N";
                  

                    db.SaveChanges(); // 실제로 저장 



                    #endregion
                }
                else
                {
                    #region 수정

                   
                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();

                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }

            return Redirect("/board/board_set_list");
         
        }



        // 과학자 로그인시 - 마이페이지 관련 게시판 
        public async Task<IActionResult> BoardAdmin(int? cate, int? typeIdx, int? classIdx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            int department_idx = Convert.ToInt32(UserData.user_get(user_id, "department_idx"));
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            int user_class = Convert.ToInt32(UserData.user_get(user_id, "user_class"));
            int user_idx = Convert.ToInt32(UserData.user_get(user_id, "user_idx"));
            ViewBag.company_idx = company_idx;
            ViewBag.user_id = user_id ?? "";
            #endregion

            #region 변수설정
            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;
            ViewBag.카테고리 = cate.ToString();

            var _type = (from a in db.BoardMenu where a.idx == cate select a).FirstOrDefault();

            if (_type != null)
            {
                ViewBag.타입 = _type.BoardType_idx;
                ViewBag.타이틀 = _type.title;
            }
            else
            {
                ViewBag.타입 = 1;
                ViewBag.타이틀 = "";
            }

            //게시판 종류 드롭다운==============================================================================================================================================          
            var category =
                db.classInfo.Where(a => a.useYn == "Y").Select(a => new { 값 = a.idx, 이름 = a.className });
            ViewBag.category = new SelectList(category.AsEnumerable(), "값", "이름");
            //==================================================================================================================================================================

            #endregion

            //var _query = db.BoardList.Include(p=>p.classIdxNavigation.managerIdxNavigation).Include(p => p.classIdxNavigation).Include(p=>p.BM_idxNavigation).Where(a => a.useable != "N" && a.BM_idxNavigation.BoardType_idx == typeIdx).OrderByDescending(a => a.writeDate).AsNoTracking(); 

            ////user_class :: 등급3 : => 과학자 
            //if (user_class == 3 )
            //{
            //    _query = _query.Where(a => a.classIdxNavigation.managerIdxNavigation.userId == user_id);
            //    //공지사항
            //    var n_list = db.v_class_board.Where(a => a.userId == user_id && a.BM_idx == 5).ToList();
            //}

            var _query = db.v_class_board.Where(a=>a.useable != "N").OrderByDescending(a => a.writeDate).AsNoTracking();

            if (cate == 5 )// 공지사항 
            {
               _query = _query.Where(a => a.userId == user_id && a.BM_idx == 5);
            }
            else if(cate == 6) // QNA
            {
                _query = _query.Where(a => a.userId == user_id && a.BM_idx == 6 && a.mainYn == "Y");
            }
            else if(cate == 7){ // 후기
                _query = _query.Where(a => a.userId == user_id && a.BM_idx == 7);
            }



            //if (classIdx != null)
            //{
            //    _query = _query.Where(a => a.BM_idxNavigation.classIdx == classIdx);
            //}


            var model = await PagingList.CreateAsync(_query, 10, page, sortExpression, "-idx");


            if (!string.IsNullOrEmpty(search_all))
            {
                _query = _query.Where(p =>  p.title.Contains(search_all) || p.Expr1.Contains(search_all) || p.content.Contains(search_all) || p.className.Contains(search_all) || p.writer.Contains(search_all));


                model = await PagingList.CreateAsync(_query, 30, page, sortExpression, "-idx");
            }
            
               
            ViewBag.query_c = _query.Count();



            //권한 시작==============================================================================================
            BoardAuth(null, cate, typeIdx);
            //권한 끝================================================================================================

            return View(model);

        }

        private void BoardAuth(int? idx, int? cate, int? typeIdx)
        {
            #region 권한

            ViewBag.권한 = "";
            ViewBag.부서 = "";
            ViewBag.관리자 = "";
            ViewBag.코멘트 = "N";
            ViewBag.파일 = "N";
            ViewBag.후기 = "N";
            ViewBag.등록 = "Y";
            string user_id = "";
            
            string board_type = (from a in db.BoardMenu where a.idx == cate select a.BoardType_idxNavigation.gubun).FirstOrDefault();
            int board_code = (from a in db.BoardMenu where a.idx == cate select a.BoardType_idxNavigation.code_id).FirstOrDefault();
            if(typeIdx != null)
            {
                board_type = (from a in db.BoardCode where a.code_id == typeIdx select a.gubun).FirstOrDefault();
                board_code = (from a in db.BoardCode where a.code_id == typeIdx select a.code_id).FirstOrDefault();
            }

            foreach (var item in board_type.Split(","))
            {
                if (item == "file")
                {
                    ViewBag.파일 = "Y";
                }
                if (item == "replay" || item == "qna")
                {
                    ViewBag.코멘트 = "Y";

                    if(board_code == 1)
                    {
                        ViewBag.코멘트 = "N";
                        ViewBag.등록 = "N";

                    }
                }
                if (item == "review")
                {
                    ViewBag.후기 = "Y";
                    ViewBag.파일 = "Y";
                }
            }

            int _auth_department = 0;
            if (User.Identity.IsAuthenticated)
            {
                //로그인 했을 경우

                user_id = User.Identity.Name;

                _auth_department = (from a in db.user where a.userId == user_id select a.checkAuth).FirstOrDefault();

                if (_auth_department >= 8)
                {
                    ViewBag.권한 = "E";
                    ViewBag.관리자 = "Y";

                }

                if (idx != null)
                {
                    string _auth_writer = (from a in db.BoardList where a.idx == idx select a.writer).FirstOrDefault() ?? "";
                    
                    if (user_id == _auth_writer)
                    {
                        ViewBag.권한 = "E";
                    }

                }

                ViewBag.로그인 = "Y";
            }

            else
            {
                ViewBag.타입 = "normal";
       
                ViewBag.권한 = "G";
                
            }

            #endregion
        }













        public class UserData
        {
            public static string user_get(string user_id, string what)
            {

                db_e db = new db_e();

                string company_id = "BlueEye";
                string company_name = "BlueEye";
                string user_name = "";
                int department_idx = 0;
                int company_idx = 0;
                string department_name = "";
                int auth = 0; //초기 :0
                string user_auth = "";
                string position_idx = "0";
                string company_type = "0";
                int user_idx = 0;
                int user_class = 0;

                var _list = (from a in db.user where a.userId == user_id select a).FirstOrDefault();

                if (_list != null)
                {
                    //company_id = _list.company_idxNavigation.company_id;
                    //company_name = _list.company_idxNavigation.company_name;
                    //company_idx = _list.company_idxNavigation.idx;
                    //department_name = _list.department_idxNavigation.department_name;
                    user_name = _list.userName;
                    //department_idx = _list.department_idx;
                    auth = _list.checkAuth; //최고 권한 관리자 :9 , 회사별 권한 관리자 : 8 , 부서장 : 7
                    user_auth = _list.userAuth; //페이지 권한 
                    //position_idx = _list.code_position_idx.ToString();
                    //company_type = _list.company_idxNavigation.company_type.ToString();
                    user_idx = _list.idx;
                    user_class = _list.userClass;

                }

                string str = "";

                if (what == "user_id")
                {
                    str = user_id;
                }
                else if (what == "user_name")
                {
                    str = user_name;
                }
                else if (what == "company_id")
                {
                    str = company_id;
                }
                else if (what == "company_idx")
                {
                    str = company_idx.ToString();
                }
                else if (what == "company_name")
                {
                    str = company_name;
                }
                else if (what == "department_idx")
                {
                    str = department_idx.ToString();
                }
                else if (what == "department_name")
                {
                    str = department_name;
                }
                else if (what == "auth")
                {
                    str = auth.ToString();
                }
                else if (what == "user_auth")
                {
                    str = user_auth.ToString();
                }
                else if (what == "position_idx")
                {
                    str = position_idx.ToString();
                }
                else if (what == "company_type")
                {
                    str = company_type.ToString();
                }
                else if (what == "user_idx")
                {
                    str = user_idx.ToString();
                }
                else if (what == "user_class")
                {
                    str = user_class.ToString();
                }
                return str;

            }

            public void History_write(string user_id, string _page, string _state)
            {
                db_e db = new db_e();

                string user_name = UserData.user_get(user_id, "user_name");
                string department_id = UserData.user_get(user_id, "department_id");
                string department_name = UserData.user_get(user_id, "department_name");
                string company_id = UserData.user_get(user_id, "company_id");
                string company_name = UserData.user_get(user_id, "company_name");
                string auth = UserData.user_get(user_id, "auth");

                if (_state == "S")
                {
                    _state = "저장";

                }
                else if (_state == "D")
                {
                    _state = "삭제";
                }
                else
                {
                    _state = "수정";
                }


                var _insert = new history
                {
                    user_id = user_id,
                    company_id = company_id,
                    department_id = department_id,
                    user_ip = "",
                    pre_page = "",
                    connect_agent = company_name,
                    connect_host = auth,
                    connect_path = user_name,
                    memo = department_name,
                    connect_date = DateTime.Now,
                    state = _state,
                    page = _page
                };

                db.history.Add(_insert);
                db.SaveChanges(); // 실제로 저장 


            }
        }

        #region 사용자 개인 정보 수정

        public ActionResult user_info(user doc)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            //#region Select Box
            ////========================================================================================================================================================
            //var _code_nationality = db.code_nationality.Where(p => p.use_yn == "Y").OrderBy(P => P.index_order).Select(c => new { 값 = c.code_id, 이름 = c.code_name });
            //ViewBag.언어 = new SelectList(_code_nationality.AsEnumerable(), "값", "이름");

            ////========================================================================================================================================================

            ////========================================================================================================================================================
            //var _department = db.department.Where(p => p.company_idx == company_idx && p.use_yn != "N").OrderBy(P => P.index_order).Select(c => new { 값 = c.idx, 이름 = c.department_name });
            //ViewBag.부서 = new SelectList(_department.AsEnumerable(), "값", "이름");

            ////======================================================================================================================================================== 
            //#endregion

            doc = db.user.Single(x => x.userId == user_id);

            #region 이미지 찾기


            var _list = (from a in db.BoardFile where a.Md_id == doc.photoProfile && a.use_yn != "N" select a).OrderBy(p => p.use_yn).ThenByDescending(p => p.id).ToList();

            ViewBag.이미지리스트 = _list;
            ViewBag.이미지리스트카운트 = _list.Count();
            #endregion

            return View(doc);
        }

        [HttpPost]
        public async Task<ActionResult> userinfo_action(user doc, List<IFormFile> files)
        {

            //==================================================================
            UserData UserData = new UserData();
            //===================================================================

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            string department_idx = UserData.user_get(user_id, "department_idx");
            string auth = UserData.user_get(user_id, "auth");
            #endregion

            #region 파일 아이디
            string file_id = "";


            file_id = doc.photoProfile;

            if (string.IsNullOrEmpty(file_id))
            {

                file_id = user_id + DateTime.Now.ToShortDateString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();


            }
            #endregion

            #region 파일 올리기

            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];

            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);

                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = doc.userId + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;    // 신규 파일 이름   
                    var _local_path = _targetFilePath + company_id + "/";   // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);    // 전체 경로
                    string desiredThumbPath = _local_path + "s/";   // 작은 이미지 전체 경로
                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion

                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================

                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);
                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }

                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }


            #endregion

            #region 사용자 정보 수정
            user _update =
                     (from a in db.user where a.userId == User.Identity.Name select a).Single();

            _update.userTel = doc.userTel;
            _update.userPassword = doc.userPassword;
            _update.editDate = DateTime.Now;
            //update.main_bg_color = doc.main_bg_color;
            //_update.language = doc.language;
            _update.userEmail = doc.userEmail;
            _update.photoProfile = file_id;


            db.SaveChanges(); // 실제로 저장  
            #endregion

            UserData.History_write(User.Identity.Name, "/sys/user_info", "수정");

            return Redirect("/sys/user_info");

        }
        #endregion

        #region 기록 히스토리
        /// <summary>
        /// 
        /// </summary>
        /// <param name="user_id">아이디</param>
        /// <param name="_page">해당 페이지</param>
        /// <param name="_state">처리상태(입력,수정,삭제)</param>
        /// 

        #endregion

        #region 리스트 첨부파일 설정

        [Authorize]
        public ActionResult file_set(file_management doc, int? idx)
        {

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            string position_idx = UserData.user_get(user_id, "position_idx");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.회사고유번호 = company_idx;

            if (auth >= 9)
            {
                //======================================================================================================================================================== 
                var Code_company =
                    db.company.Where(p => p.useYn == "Y").OrderBy(o => o.indexOrder).Select(
                        c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

                //======================================================================================================================================================== 
                var Code_auth =
                    db.CategoryMenus.Where(p => p.company_id == company_id && p.step_dept == 2).OrderBy(o => o.step_auth)
                        .Select(c => new { 값 = c.step_auth, 이름 = c.step_name });
                ViewBag.권한 = new SelectList(Code_auth.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 
            }
            else
            {
                //======================================================================================================================================================== 
                var Code_company =
                    db.company.Where(p => p.idx == company_idx).OrderBy(
                        o => o.indexOrder).Select(c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 
            }


            //======================================================================================================================================================== 
            var file_menu =
                db.file_menu.Where(p => p.company_idx == company_idx).OrderBy(
                    o => o.file_menu_name).Select(c => new { 값 = c.file_menu_id, 이름 = c.file_menu_name });
            ViewBag.파일분류 = new SelectList(file_menu.AsEnumerable(), "값", "이름");
            //========================================================================================================================================================

            if (idx != null)
            {

                doc = db.file_management.Single(x => x.idx == idx);
            }

            return View(doc);
        }

        [Authorize]
        public ActionResult file_set_list(string gubun_idx, string search_all_type, string search_all, string sortExpression = "-idx", int page = 1)
        {
            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int position_idx = Convert.ToInt32(UserData.user_get(user_id, "position_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            ViewBag.search_all_type = search_all_type;
            ViewBag.search_all = search_all;
            ViewBag.sortExpression = sortExpression;




            IOrderedQueryable<file_management> _list = db.file_management.Include(p => p.code_doc_idx).OrderByDescending(p => p.idx);

            if (auth < 9)
            {

                //======================================================================================================================================================== 
                var Code_company = db.company.Where(p => p.useYn == "Y" && p.idx == company_idx).OrderBy(o => o.indexOrder).Select(
                        c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

                _list = _list.Where(p => p.company_idx == company_idx).OrderBy(p => p.company_idx);
            }
            else
            {
                //======================================================================================================================================================== 
                var Code_company = db.company.Where(p => p.useYn == "Y").OrderBy(o => o.indexOrder).Select(
                        c => new { 값 = c.idx, 이름 = c.companyName });
                ViewBag.회사 = new SelectList(Code_company.AsEnumerable(), "값", "이름");
                //======================================================================================================================================================== 

            }

            if (!string.IsNullOrEmpty(gubun_idx))
            {
                int gubun_idx_int = 0;

                try
                {
                    gubun_idx_int = Convert.ToInt32(gubun_idx);
                }
                catch
                { }

                _list = _list.Where(p => p.company_idx == gubun_idx_int).OrderByDescending(p => p.idx);

            }
            else
            {
                _list = _list.Where(p => p.company_idx == company_idx).OrderByDescending(p => p.idx);
            }

            return View(_list.ToList());
        }

        public ActionResult file_set_action(file_management doc, string mode_type, int? idx, string gubun_idx)
        {

            string msg = "";

            #region 기본 사용자 정보
            string user_id = User.Identity.Name;
            string company_id = UserData.user_get(user_id, "company_id");
            int company_idx = Convert.ToInt32(UserData.user_get(user_id, "company_idx"));
            int auth = Convert.ToInt32(UserData.user_get(user_id, "auth"));
            #endregion

            if (doc.use_yn == "on")
            {
                doc.use_yn = "Y";
            }
            else
            {
                doc.use_yn = "N";
            }


            if (idx == null)
            {
                #region 저장




                db.file_management.Add(doc);
                db.SaveChanges(); // 실제로 저장 


                msg = Util.msg.msg_insert;

                #endregion
            }
            else
            {

                if (mode_type == "D")
                {
                    #region 삭제

                    file_management _update =
                      (from a in db.file_management where a.idx == idx select a).Single();
                    _update.use_yn = "D";


                    db.SaveChanges(); // 실제로 저장 

                    msg = Util.msg.msg_del;
                    return Redirect("/sys/file_set_list");

                    #endregion
                }
                else
                {
                    #region 수정

                    db.Entry(doc).State = EntityState.Modified;
                    db.SaveChanges();

                    msg = Util.msg.msg_edit;

                    #endregion
                }
            }
            return Redirect("/sys/file_set_list");

        }

        #endregion

        private async Task fileUpload(List<IFormFile> files, string user_id, string file_id)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            string Models_photo = Configuration["user_app:file_list_url"];
            string company_id = UserData.user_get(user_id, "company_id");


            int s = 1;
            foreach (var formFile in files)
            {
                double file_size = formFile.Length;
                if (file_size < _fileSizeLimit)
                {

                    var formFileContent =
                        await FileHelpers
                            .ProcessFormFile<IFormFile>(
                                formFile, ModelState, _permittedExtensions,
                                _fileSizeLimit);



                    #region 변수
                    // 변수 =========================================================================================================================
                    string only = user_id + DateTime.Today.ToShortDateString().Replace("-", "") + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString();
                    //  var trustedFileNameForFileStorage = Path.GetRandomFileName();   //랜덤이름                      

                    string file_ex = ""; // 확장자

                    try { file_ex = Path.GetFileName(formFile.FileName).Split('.').Last(); }
                    catch
                    {

                    }
                    var _fileName = only + "." + file_ex;     // 신규 파일 이름   



                    var _local_path = _targetFilePath + company_id + "/";           // 신규 파일 경로
                    var filePath = Path.Combine(_local_path, _fileName);            // 전체 경로
                    string desiredThumbPath = _local_path + "s/";                   // 작은 이미지 전체 경로

                    string ore_fileName = Path.GetFileName(formFile.FileName);
                    #endregion




                    //경로에 폴더가 없으면 만들어준다.=============================================
                    var dInfo = new DirectoryInfo(_local_path);
                    var dInfo_s = new DirectoryInfo(desiredThumbPath);
                    if (!dInfo.Exists)
                    {
                        dInfo.Create();
                    }
                    if (!dInfo_s.Exists)
                    {
                        dInfo_s.Create();
                    }
                    //=================================================================================



                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        await fileStream.WriteAsync(formFileContent);

                    }

                    if (get_word.img_check(file_ex) == "img")
                    {
                        // 세로 기준
                        ResizeImage(desiredThumbPath, formFile, _fileName, 300, 0);
                    }



                    var _insert = new BoardFile()
                    {
                        Md_id = file_id,
                        ImagePath = Models_photo + company_id + "/" + _fileName,
                        fileName = ore_fileName,
                        use_yn = "Y",
                        file_ex = file_ex,
                        file_size = file_size,
                        r_date = DateTime.Now,
                        write_id = user_id,
                        sImagePath = Models_photo + company_id + "/s/" + _fileName,
                    };

                    db.BoardFile.Add(_insert);
                    db.SaveChanges();

                }

                s++;
            }
        }
        public void History_write(string user_id, string _page, string _state, string memo)
        {
            db_e db = new db_e();

            string user_name = UserData.user_get(user_id, "user_name");

            string department_id = UserData.user_get(user_id, "department_id");
            string department_name = UserData.user_get(user_id, "department_name");
            string company_id = UserData.user_get(user_id, "company_id");
            string company_name = UserData.user_get(user_id, "company_name");
            string auth = UserData.user_get(user_id, "auth");
            string _ip = Request.HttpContext.Connection.RemoteIpAddress.ToString();


            var _insert = new history
            {
                user_id = user_id,
                company_id = company_id,
                department_id = department_id,
                user_ip = _ip,
                pre_page = "",
                connect_agent = company_name,
                connect_host = auth,
                connect_path = user_name,
                memo = memo,
                connect_date = DateTime.Now,
                state = _state,
                page = _page
            };

            db.history.Add(_insert);
            db.SaveChanges(); // 실제로 저장 


        }
    }
}