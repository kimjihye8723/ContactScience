﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Net.Http.Headers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;


namespace SmartFactory.Util
{
    public static class FileHelpers
    {
        // IsValidFileExtensionAndSignature 메서드의 특정 문자를 확인해야하는 경우 /// _allowedCharacterByteArray 필드에 문자를 제공합니다.

        private static readonly byte[] _allowedChars = { };
        // 더 많은 파일 서명은 파일 서명 데이터베이스 (https://www.filesignatures.net/) 및 추가하려는 파일 형식에 대한 공식 사양을 참조한다.

        private static readonly Dictionary<string, List<byte[]>> _fileSignature = new Dictionary<string, List<byte[]>>
        {
            { ".gif", new List<byte[]> { new byte[] { 0x47, 0x49, 0x46, 0x38 } } },
            { ".png", new List<byte[]> { new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A } } },
            { ".jpeg", new List<byte[]>
                {
                    new byte[] { 0xFF, 0xD8, 0xFF, 0xE0 },
                    new byte[] { 0xFF, 0xD8, 0xFF, 0xE2 },
                    new byte[] { 0xFF, 0xD8, 0xFF, 0xE3 },
                }
            },
            { ".jpg", new List<byte[]>
                {
                    new byte[] { 0xFF, 0xD8, 0xFF, 0xE0 },
                    new byte[] { 0xFF, 0xD8, 0xFF, 0xE1 },
                    new byte[] { 0xFF, 0xD8, 0xFF, 0xE8 },
                }
            },
            { ".zip", new List<byte[]>
                {
                    new byte[] { 0x50, 0x4B, 0x03, 0x04 },
                    new byte[] { 0x50, 0x4B, 0x4C, 0x49, 0x54, 0x45 },
                    new byte[] { 0x50, 0x4B, 0x53, 0x70, 0x58 },
                    new byte[] { 0x50, 0x4B, 0x05, 0x06 },
                    new byte[] { 0x50, 0x4B, 0x07, 0x08 },
                    new byte[] { 0x57, 0x69, 0x6E, 0x5A, 0x69, 0x70 },
                }
            },
            { ".ppt", new List<byte[]> { new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 } } },
            { ".pptx", new List<byte[]>
                {
                    new byte[] { 0x50, 0x4B, 0x03, 0x04 },
                    new byte[] { 0x50, 0x4B, 0x05, 0x06 },
                    new byte[] { 0x50, 0x4B, 0x07, 0x08 },
                }
            },
            { ".psd", new List<byte[]> { new byte[] { 0x38, 0x42, 0x50, 0x53 } } },
        };


        // 경고! // 다음 파일 처리 방법에서는 파일의 내용이 검사되지 않는다. 
        // 대부분의 프로덕션 시나리오에서 바이러스 백신/멀웨어 방지 스캐너 API는 
        // 사용자나 다른 시스템에서 파일을 사용할 수 있도록 하기 전에 파일에 사용된다. 
        // 자세한 정보는 이 샘플 앱과 함께 제공되는 주제를 참조한다.



        public static async Task<byte[]> ProcessFormFile<T>(IFormFile formFile,
            ModelStateDictionary modelState, string[] permittedExtensions,
            long sizeLimit)
        {
            var fieldDisplayName = string.Empty;


        // 리플렉션을 사용하여 이 IFormFile과 연결된 모델 속성의 표시 이름을 가져온다. 
        // 표시 이름을 찾을 수 없는 경우 오류 메시지에 표시 이름이 표시되지 않는다.

            MemberInfo property =
                typeof(T).GetProperty(
                    formFile.Name.Substring(formFile.Name.IndexOf(".",
                    StringComparison.Ordinal) + 1));


            if (property != null)
            {
                if (property.GetCustomAttribute(typeof(DisplayAttribute)) is
                    DisplayAttribute displayAttribute)
                {
                    fieldDisplayName = $"{displayAttribute.Name} ";
                }
            }


        // 클라이언트가 보낸 파일 이름을 신뢰하지 않는다. // 파일 이름을 표시하려면 값을 HTML로 인코딩한다.
            var trustedFileNameForDisplay = WebUtility.HtmlEncode(formFile.FileName);






        // 파일 길이를 확인한다. // 이 검사는 내용으로 BOM만 있는 파일을 포착하지 않는다.
            if (formFile.Length == 0)
            {
                modelState.AddModelError(formFile.Name,
                    $"{fieldDisplayName}({trustedFileNameForDisplay}) is empty.");


                return new byte[0];
            }

            if (formFile.Length > sizeLimit)
            {
                // 크기 200mb 이하
                var megabyteSizeLimit = sizeLimit / 1048576;
                modelState.AddModelError(formFile.Name,
                    $"{fieldDisplayName}({trustedFileNameForDisplay}) exceeds " +
                    $"{megabyteSizeLimit:N1} MB.");


                return new byte[0];
            }


            try
            {
                using (var memoryStream = new MemoryStream())
                {
                    await formFile.CopyToAsync(memoryStream);


                // 파일의 유일한 내용이 BOM이었고 // BOM을 제거한 후 내용이 실제로 비어있는 경우 내용 길이를 확인한다.

                    if (memoryStream.Length == 0)
                    {
                        modelState.AddModelError(formFile.Name,
                            $"{fieldDisplayName}({trustedFileNameForDisplay}) is empty.");
                    }

                    return memoryStream.ToArray();
                    //if (!IsValidFileExtensionAndSignature(
                    //    formFile.FileName, memoryStream, permittedExtensions))
                    //{
                    //    modelState.AddModelError(formFile.Name,
                    //        $"{fieldDisplayName}({trustedFileNameForDisplay}) file " +
                    //        "type isn't permitted or the file's signature " +
                    //        "doesn't match the file's extension.");
                    //}
                    //else
                    //{
                    //    return memoryStream.ToArray();
                    //}
                }
            }
            catch (Exception ex)
            {
                modelState.AddModelError(formFile.Name,
                    $"{fieldDisplayName}({trustedFileNameForDisplay}) upload failed. " +
                    $"Please contact the Help Desk for support. Error: {ex.HResult}");
                // Log the exception 
            }


            return new byte[0];
        }


        public static async Task<byte[]> ProcessStreamedFile(
            MultipartSection section, ContentDispositionHeaderValue contentDisposition,
            ModelStateDictionary modelState, string[] permittedExtensions, long sizeLimit)
        {
            try
            {
                using (var memoryStream = new MemoryStream())
                {
                    await section.Body.CopyToAsync(memoryStream);


                // 파일이 비어 있거나 크기 제한을 초과하는지 확인한다.

                    if (memoryStream.Length == 0)
                    {
                        modelState.AddModelError("File", "The file is empty.");
                    }
                    else if (memoryStream.Length > sizeLimit)
                    {
                        var megabyteSizeLimit = sizeLimit / 1048576;
                        modelState.AddModelError("File",
                        $"The file exceeds {megabyteSizeLimit:N1} MB.");
                    }
                    else if (!IsValidFileExtensionAndSignature(
                        contentDisposition.FileName.Value, memoryStream,
                        permittedExtensions))
                    {
                        modelState.AddModelError("File",
                            "The file type isn't permitted or the file's " +
                            "signature doesn't match the file's extension.");
                    }
                    else
                    {
                        return memoryStream.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                modelState.AddModelError("File",
                    "The upload failed. Please contact the Help Desk " +
                    $" for support. Error: {ex.HResult}");
                // Log the exception 
            }


            return new byte[0];
        }

        internal static Task ProcessFormFile<T>(T formFile, ModelStateDictionary modelState, object permittedExtensions, double fileSizeLimit)
        {
            throw new NotImplementedException();
        }

        private static bool IsValidFileExtensionAndSignature(string fileName, Stream data, string[] permittedExtensions)
        {
            if (string.IsNullOrEmpty(fileName) || data == null || data.Length == 0)
            {
                return false;
            }


            var ext = Path.GetExtension(fileName).ToLowerInvariant();


            if (string.IsNullOrEmpty(ext) || !permittedExtensions.Contains(ext))
            {
                return false;
            }


            data.Position = 0;


            using (var reader = new BinaryReader(data))
            {
                if (ext.Equals(".txt") || ext.Equals(".csv") || ext.Equals(".prn"))
                {
                    if (_allowedChars.Length == 0)
                    {
                        // Limits characters to ASCII encoding. 
                        for (var i = 0; i < data.Length; i++)
                        {
                            if (reader.ReadByte() > sbyte.MaxValue)
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        // Limits characters to ASCII encoding and 
                        // values of the _allowedChars array. 
                        for (var i = 0; i < data.Length; i++)
                        {
                            var b = reader.ReadByte();
                            if (b > sbyte.MaxValue ||
                                !_allowedChars.Contains(b))
                            {
                                return false;
                            }
                        }
                    }


                    return true;
                }

                // _fileSignatureDictionary에 서명이 제공되지 않은 파일을 허용해야 하는 경우 
                // 다음 코드 블록의 주석 처리를 제거한다. 
                // 시스템에서 허용하려는 모든 파일 형식에 대해 가능한 경우 
                // 파일에 대한 파일 서명을 추가하고 파일 서명 검사를 수행하는 것이 좋다. 
                //if (!_fileSignature.ContainsKey(ext))
                //{
                //    return true;
                //}


                // 파일 서명 확인 
                // -------------- 
                // _fileSignatureDictionary에 제공된 파일 서명을 사용하여 
                // 다음 코드는 입력 콘텐츠의 파일 서명을 테스트한다.


                var signatures = _fileSignature[ext];
                var headerBytes = reader.ReadBytes(signatures.Max(m => m.Length));


                return signatures.Any(signature =>
                    headerBytes.Take(signature.Length).SequenceEqual(signature));
            }
        }
    }

}
