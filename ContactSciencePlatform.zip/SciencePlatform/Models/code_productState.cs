﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class code_productState
    {
        public code_productState()
        {
            productInfo = new HashSet<productInfo>();
        }

        [Key]
        public int idx { get; set; }
        [StringLength(150)]
        public string codeName { get; set; }
        public int indexOrder { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }

        [InverseProperty("stateIdxNavigation")]
        public virtual ICollection<productInfo> productInfo { get; set; }
    }
}
