﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class company
    {
        public company()
        {
            department = new HashSet<department>();
            user = new HashSet<user>();
        }

        [Key]
        public int idx { get; set; }
        [StringLength(50)]
        public string companyId { get; set; }
        [Required]
        [StringLength(150)]
        public string companyName { get; set; }
        [StringLength(50)]
        public string nationality { get; set; }
        [StringLength(50)]
        public string businessNum { get; set; }
        public string address { get; set; }
        public string fileId { get; set; }
        [StringLength(50)]
        public string tel { get; set; }
        [StringLength(50)]
        public string email { get; set; }
        public int codeCompanyIdx { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        public int? indexOrder { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [StringLength(50)]
        public string writer { get; set; }

        [ForeignKey(nameof(codeCompanyIdx))]
        [InverseProperty(nameof(code_company.company))]
        public virtual code_company codeCompanyIdxNavigation { get; set; }
        [InverseProperty("company_idxNavigation")]
        public virtual ICollection<department> department { get; set; }
        [InverseProperty("companyIdxNavigation")]
        public virtual ICollection<user> user { get; set; }
    }
}
