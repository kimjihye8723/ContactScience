﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class code_state
    {
        [Key]
        public int idx { get; set; }
        [StringLength(50)]
        public string codeName { get; set; }
        public int indexOrder { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
    }
}
