﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class file_management
    {
        [Key]
        public int idx { get; set; }
        public int code_doc_idx { get; set; }
        [StringLength(50)]
        public string title { get; set; }
        public string memo { get; set; }
        [StringLength(1)]
        public string use_yn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime write_date { get; set; }
        public int company_idx { get; set; }
        public int index_order { get; set; }
    }
}
