﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class user_general
    {
        [Key]
        public int idx { get; set; }
        [StringLength(50)]
        public string user_id { get; set; }
        [Required]
        [StringLength(50)]
        public string user_password { get; set; }
        [Required]
        [StringLength(10)]
        public string user_name { get; set; }
        [Required]
        [StringLength(50)]
        public string user_email { get; set; }
        [Required]
        [StringLength(50)]
        public string tel { get; set; }
        [StringLength(150)]
        public string address { get; set; }
        public int? state_idx { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Required]
        [StringLength(1)]
        public string use_yn { get; set; }
        public int? code_test { get; set; }
        [StringLength(150)]
        public string file_id { get; set; }
    }
}
