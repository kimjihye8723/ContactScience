﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class productRefund
    {
        [Key]
        public int idx { get; set; }
        public int orderIdx { get; set; }
        public int userIdx { get; set; }
        [StringLength(250)]
        public string userName { get; set; }
        [StringLength(250)]
        public string userId { get; set; }
        public int paymentIdx { get; set; }
        public int? optionIdx { get; set; }
        [StringLength(350)]
        public string optionInfo { get; set; }
        public int price { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime completeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime startDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime endDate { get; set; }
        public int? state { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        public int refundType { get; set; }
        [StringLength(50)]
        public string refundCode { get; set; }
        public int? productIdx { get; set; }

        [ForeignKey(nameof(orderIdx))]
        [InverseProperty(nameof(orderProduct.productRefund))]
        public virtual orderProduct orderIdxNavigation { get; set; }
        [ForeignKey(nameof(paymentIdx))]
        [InverseProperty(nameof(productPayment.productRefund))]
        public virtual productPayment paymentIdxNavigation { get; set; }
        [ForeignKey(nameof(productIdx))]
        [InverseProperty(nameof(productInfo.productRefund))]
        public virtual productInfo productIdxNavigation { get; set; }
    }
}
