﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class BoardList
    {
        public BoardList()
        {
            BoardComment = new HashSet<BoardComment>();
            BoardRread = new HashSet<BoardRread>();
        }

        [Key]
        public int idx { get; set; }
        public int BM_idx { get; set; }
        [Required]
        [StringLength(250)]
        public string title { get; set; }
        [Column(TypeName = "ntext")]
        public string content { get; set; }
        [StringLength(200)]
        public string writer { get; set; }
        [StringLength(200)]
        public string password { get; set; }
        public int hit { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? delDate { get; set; }
        [StringLength(2)]
        public string useable { get; set; }
        [StringLength(50)]
        public string fileId { get; set; }
        [StringLength(50)]
        public string reply { get; set; }
        public int classIdx { get; set; }
        [StringLength(1)]
        public string mailYn { get; set; }
        public int? productIdx { get; set; }
        [StringLength(1)]
        public string mainYn { get; set; }
        [StringLength(1)]
        public string commuYn { get; set; }

        [ForeignKey(nameof(BM_idx))]
        [InverseProperty(nameof(BoardMenu.BoardList))]
        public virtual BoardMenu BM_idxNavigation { get; set; }
        [ForeignKey(nameof(classIdx))]
        [InverseProperty(nameof(classInfo.BoardList))]
        public virtual classInfo classIdxNavigation { get; set; }
        [ForeignKey(nameof(productIdx))]
        [InverseProperty(nameof(productInfo.BoardList))]
        public virtual productInfo productIdxNavigation { get; set; }
        [InverseProperty("BD_idxNavigation")]
        public virtual ICollection<BoardComment> BoardComment { get; set; }
        [InverseProperty("board_idxNavigation")]
        public virtual ICollection<BoardRread> BoardRread { get; set; }
    }
}
