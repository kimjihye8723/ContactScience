﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class deliverState
    {
        [Key]
        public int idx { get; set; }
        public int? deliverNum { get; set; }
        public string deliverLink { get; set; }
        public int state { get; set; }
    }
}
