﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class productCart
    {
        [Key]
        public int idx { get; set; }
        public int productIdx { get; set; }
        public int? userIdx { get; set; }
        public int optionIdx { get; set; }
        public int qty { get; set; }
        public int price { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }

        [ForeignKey(nameof(optionIdx))]
        [InverseProperty(nameof(codeOption.productCart))]
        public virtual codeOption optionIdxNavigation { get; set; }
        [ForeignKey(nameof(productIdx))]
        [InverseProperty(nameof(productInfo.productCart))]
        public virtual productInfo productIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.productCart))]
        public virtual user userIdxNavigation { get; set; }
    }
}
