﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class db_e : DbContext
    {
        public db_e()
        {
        }

        public db_e(DbContextOptions<db_e> options)
            : base(options)
        {
        }

        public virtual DbSet<BoardCode> BoardCode { get; set; }
        public virtual DbSet<BoardComment> BoardComment { get; set; }
        public virtual DbSet<BoardFile> BoardFile { get; set; }
        public virtual DbSet<BoardList> BoardList { get; set; }
        public virtual DbSet<BoardMenu> BoardMenu { get; set; }
        public virtual DbSet<BoardRread> BoardRread { get; set; }
        public virtual DbSet<CategoryMenus> CategoryMenus { get; set; }
        public virtual DbSet<ViewClass> ViewClass { get; set; }
        public virtual DbSet<ViewClassInfo> ViewClassInfo { get; set; }
        public virtual DbSet<calendar> calendar { get; set; }
        public virtual DbSet<classCart> classCart { get; set; }
        public virtual DbSet<classContents> classContents { get; set; }
        public virtual DbSet<classFavorite> classFavorite { get; set; }
        public virtual DbSet<classInfo> classInfo { get; set; }
        public virtual DbSet<classPayment> classPayment { get; set; }
        public virtual DbSet<classPlan> classPlan { get; set; }
        public virtual DbSet<classReview> classReview { get; set; }
        public virtual DbSet<classSurvey> classSurvey { get; set; }
        public virtual DbSet<codeOption> codeOption { get; set; }
        public virtual DbSet<code_classAges> code_classAges { get; set; }
        public virtual DbSet<code_classCategory> code_classCategory { get; set; }
        public virtual DbSet<code_classPlace> code_classPlace { get; set; }
        public virtual DbSet<code_company> code_company { get; set; }
        public virtual DbSet<code_nationality> code_nationality { get; set; }
        public virtual DbSet<code_productCategory> code_productCategory { get; set; }
        public virtual DbSet<code_productState> code_productState { get; set; }
        public virtual DbSet<code_scienceCategory> code_scienceCategory { get; set; }
        public virtual DbSet<code_shopinfo> code_shopinfo { get; set; }
        public virtual DbSet<code_state> code_state { get; set; }
        public virtual DbSet<code_userCategory> code_userCategory { get; set; }
        public virtual DbSet<commentsView> commentsView { get; set; }
        public virtual DbSet<company> company { get; set; }
        public virtual DbSet<deliverInfo> deliverInfo { get; set; }
        public virtual DbSet<deliveryList> deliveryList { get; set; }
        public virtual DbSet<department> department { get; set; }
        public virtual DbSet<file_list> file_list { get; set; }
        public virtual DbSet<file_management> file_management { get; set; }
        public virtual DbSet<file_menu> file_menu { get; set; }
        public virtual DbSet<history> history { get; set; }
        public virtual DbSet<language> language { get; set; }
        public virtual DbSet<orderClass> orderClass { get; set; }
        public virtual DbSet<orderClassDetail> orderClassDetail { get; set; }
        public virtual DbSet<orderProduct> orderProduct { get; set; }
        public virtual DbSet<orderProductDetail> orderProductDetail { get; set; }
        public virtual DbSet<payapp_library> payapp_library { get; set; }
        public virtual DbSet<payment_payapp> payment_payapp { get; set; }
        public virtual DbSet<productCart> productCart { get; set; }
        public virtual DbSet<productInfo> productInfo { get; set; }
        public virtual DbSet<productPayment> productPayment { get; set; }
        public virtual DbSet<productReclaim> productReclaim { get; set; }
        public virtual DbSet<productRefund> productRefund { get; set; }
        public virtual DbSet<productReturn> productReturn { get; set; }
        public virtual DbSet<productReturnDelivery> productReturnDelivery { get; set; }
        public virtual DbSet<productReview> productReview { get; set; }
        public virtual DbSet<registClass> registClass { get; set; }
        public virtual DbSet<sendHistory> sendHistory { get; set; }
        public virtual DbSet<user> user { get; set; }
        public virtual DbSet<v_class_board> v_class_board { get; set; }
        public virtual DbSet<v_mail> v_mail { get; set; }
        public virtual DbSet<v_review> v_review { get; set; }
        public virtual DbSet<v_sms> v_sms { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=tcp:180.210.34.49,1433;Initial Catalog=HelloddScience;Persist Security Info=True;User ID=blueeye01;Password=rensoft0037!;MultipleActiveResultSets=True;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Korean_Wansung_CI_AS");

            modelBuilder.Entity<BoardCode>(entity =>
            {
                entity.Property(e => e.board_auth).IsUnicode(false);

                entity.Property(e => e.code_name)
                    .IsUnicode(false)
                    .HasComment("중류");

                entity.Property(e => e.gubun).IsUnicode(false);

                entity.Property(e => e.use_yn).IsUnicode(false);
            });

            modelBuilder.Entity<BoardComment>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_bbs_comment");

                entity.Property(e => e.edit_date).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.step).HasDefaultValueSql("((1))");

                entity.Property(e => e.use_yn).IsUnicode(false);

                entity.Property(e => e.user_ip).IsUnicode(false);

                entity.Property(e => e.write_date).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.writer).IsUnicode(false);

                entity.HasOne(d => d.BD_idxNavigation)
                    .WithMany(p => p.BoardComment)
                    .HasForeignKey(d => d.BD_idx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BoardComment_Board");
            });

            modelBuilder.Entity<BoardFile>(entity =>
            {
                entity.Property(e => e.ImagePath).IsUnicode(false);

                entity.Property(e => e.Md_id)
                    .IsUnicode(false)
                    .HasComment("파일 고유 키");

                entity.Property(e => e.fileName).IsUnicode(false);

                entity.Property(e => e.file_ex).IsUnicode(false);

                entity.Property(e => e.memo).IsUnicode(false);

                entity.Property(e => e.r_date).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.sImagePath).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.use_yn).IsUnicode(false);

                entity.Property(e => e.write_id).IsUnicode(false);
            });

            modelBuilder.Entity<BoardList>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_Board");

                entity.Property(e => e.BM_idx).HasComment("게시판 메뉴 인덱스");

                entity.Property(e => e.commuYn)
                    .IsUnicode(false)
                    .HasComment("커뮤니티 > qna,공지사항 > 메인등록 --- 승인 : Y / 메인등록 X : NULL");

                entity.Property(e => e.delDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("삭제일");

                entity.Property(e => e.editDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("수정일");

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.mailYn)
                    .IsUnicode(false)
                    .HasComment("qna 게시판 답변 미등록시 메일발송 여부 ");

                entity.Property(e => e.mainYn)
                    .IsUnicode(false)
                    .HasComment("클래스 >qna,후기 > 메인 등록 --- 승인 : Y / 승인안되면 : Null");

                entity.Property(e => e.password).IsUnicode(false);

                entity.Property(e => e.productIdx).HasComment("사이언스몰 상품 idx");

                entity.Property(e => e.reply).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.useable)
                    .IsUnicode(false)
                    .HasDefaultValueSql("((1))")
                    .HasComment("게시글 사용 여부 (Y/N)");

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.writer).IsUnicode(false);

                entity.HasOne(d => d.BM_idxNavigation)
                    .WithMany(p => p.BoardList)
                    .HasForeignKey(d => d.BM_idx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BoardList_BoardMenu");

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.BoardList)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BoardList_classInfo");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.BoardList)
                    .HasForeignKey(d => d.productIdx)
                    .HasConstraintName("FK_BoardList_productInfo");
            });

            modelBuilder.Entity<BoardMenu>(entity =>
            {
                entity.Property(e => e.idx).ValueGeneratedNever();

                entity.Property(e => e.BoardType_idx).HasComment("게시판 종류");

                entity.Property(e => e.index_order).HasDefaultValueSql("((999))");

                entity.Property(e => e.open_yn).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.url).IsUnicode(false);

                entity.HasOne(d => d.BoardType_idxNavigation)
                    .WithMany(p => p.BoardMenu)
                    .HasForeignKey(d => d.BoardType_idx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BoardMenu_BoardCode");

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.BoardMenu)
                    .HasForeignKey(d => d.classIdx)
                    .HasConstraintName("FK_BoardMenu_classInfo");
            });

            modelBuilder.Entity<BoardRread>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_board_read");

                entity.Property(e => e.user_id).IsUnicode(false);

                entity.Property(e => e.user_name).IsUnicode(false);

                entity.HasOne(d => d.board_idxNavigation)
                    .WithMany(p => p.BoardRread)
                    .HasForeignKey(d => d.board_idx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BoardRread_Board");
            });

            modelBuilder.Entity<CategoryMenus>(entity =>
            {
                entity.Property(e => e.company_id).IsUnicode(false);

                entity.Property(e => e.step_auth).IsUnicode(false);

                entity.Property(e => e.step_dept).HasDefaultValueSql("((1))");

                entity.Property(e => e.step_icon).IsUnicode(false);

                entity.Property(e => e.step_index)
                    .IsUnicode(false)
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.step_name).IsUnicode(false);

                entity.Property(e => e.step_orderby).HasDefaultValueSql("((9))");

                entity.Property(e => e.step_url1).IsUnicode(false);

                entity.Property(e => e.step_url2).IsUnicode(false);

                entity.Property(e => e.step_writedate).HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ViewClass>(entity =>
            {
                entity.ToView("ViewClass");

                entity.Property(e => e.boardYn).IsUnicode(false);

                entity.Property(e => e.classYn).IsUnicode(false);

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.photoProfile).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.userId).IsUnicode(false);

                entity.Property(e => e.userYn).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);
            });

            modelBuilder.Entity<ViewClassInfo>(entity =>
            {
                entity.ToView("ViewClassInfo");

                entity.Property(e => e.Expr1).IsUnicode(false);

                entity.Property(e => e.classAges).IsUnicode(false);

                entity.Property(e => e.classCate).IsUnicode(false);

                entity.Property(e => e.className).IsUnicode(false);

                entity.Property(e => e.classPlace).IsUnicode(false);

                entity.Property(e => e.companyId).IsUnicode(false);

                entity.Property(e => e.description).IsUnicode(false);

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.scienceCate).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userEmail).IsUnicode(false);

                entity.Property(e => e.userName).IsUnicode(false);
            });

            modelBuilder.Entity<calendar>(entity =>
            {
                entity.Property(e => e.idx).ValueGeneratedNever();

                entity.Property(e => e.end_date)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("종료일");

                entity.Property(e => e.gubun_type)
                    .IsUnicode(false)
                    .HasComment("달성 여부 (Y/N)");

                entity.Property(e => e.memo).IsUnicode(false);

                entity.Property(e => e.start_date)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("시작일");

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.use_yn)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('Y')")
                    .HasComment("사용여부");

                entity.Property(e => e.user_id).IsUnicode(false);

                entity.Property(e => e.write_date)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("작성일");
            });

            modelBuilder.Entity<classCart>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_classApply");

                entity.Property(e => e.delDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.classCart)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classCart_classInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.classCart)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classCart_user");
            });

            modelBuilder.Entity<classContents>(entity =>
            {
                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.mainYn).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.classContents)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classContents_classContents");
            });

            modelBuilder.Entity<classFavorite>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_favoriteClass");

                entity.Property(e => e.alarmYn)
                    .IsUnicode(false)
                    .HasComment("Y:알람설정, N:안함");

                entity.Property(e => e.delDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.classFavorite)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classFavorite_classInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.classFavorite)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classFavorite_user");
            });

            modelBuilder.Entity<classInfo>(entity =>
            {
                entity.Property(e => e.category).HasComment("카테고리 분류");

                entity.Property(e => e.className).IsUnicode(false);

                entity.Property(e => e.classType).HasComment("정기/비정기 구분");

                entity.Property(e => e.description).IsUnicode(false);

                entity.Property(e => e.endDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.limitCount).HasComment("클래스별 접수인원 제한 - 관리자권한 ");

                entity.Property(e => e.openLink).HasComment("오픈시 링크");

                entity.Property(e => e.period).HasComment("정기 클래스의 경우 반복 주기");

                entity.Property(e => e.scienceCate).HasComment("과학분야 분류");

                entity.Property(e => e.searchInfo).IsUnicode(false);

                entity.Property(e => e.startDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.state).HasComment("1: 접수예정(다음달 클래스)/ 2: 가능(이번달 클래스)/ 3: 마감 구분");

                entity.Property(e => e.surveyLink).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.useYn)
                    .IsUnicode(false)
                    .HasComment("Y: 노출 O / N: 노출X / D:삭제");

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.ageNavigation)
                    .WithMany(p => p.classInfo)
                    .HasForeignKey(d => d.age)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classInfo_code_classAges");

                entity.HasOne(d => d.categoryNavigation)
                    .WithMany(p => p.classInfo)
                    .HasForeignKey(d => d.category)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classInfo_code_classCategory");

                entity.HasOne(d => d.managerIdxNavigation)
                    .WithMany(p => p.classInfo)
                    .HasForeignKey(d => d.managerIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classInfo_user");

                entity.HasOne(d => d.placeNavigation)
                    .WithMany(p => p.classInfo)
                    .HasForeignKey(d => d.place)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classInfo_code_classPlace");

                entity.HasOne(d => d.scienceCateNavigation)
                    .WithMany(p => p.classInfo)
                    .HasForeignKey(d => d.scienceCate)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classInfo_code_scienceCategory");
            });

            modelBuilder.Entity<classPayment>(entity =>
            {
                entity.Property(e => e.amount_taxable).HasComment("과세 공급가액");

                entity.Property(e => e.amount_taxfree).HasComment("	면세 공급가액");

                entity.Property(e => e.amount_vat).HasComment("부가세");

                entity.Property(e => e.canceldate)
                    .IsUnicode(false)
                    .HasComment("취소일시");

                entity.Property(e => e.cancelmemo)
                    .IsUnicode(false)
                    .HasComment("취소메모");

                entity.Property(e => e.card_name).IsUnicode(false);

                entity.Property(e => e.csturl)
                    .IsUnicode(false)
                    .HasComment("신용카드 결제시 매출전표 URL");

                entity.Property(e => e.linkkey).IsUnicode(false);

                entity.Property(e => e.linkval).IsUnicode(false);

                entity.Property(e => e.mul_no).HasComment("결제요청번호(결제 취소 시 사용)");

                entity.Property(e => e.naverpay)
                    .IsUnicode(false)
                    .HasComment("네이버결제 구분 방법 (네이버페이 결제시만 제공)");

                entity.Property(e => e.naverpoint).HasComment("네이버 포인트 결제시 금액 (네이버페이 결제시만 제공)");

                entity.Property(e => e.orig_mul_no).HasComment("원거래 결제요청번호(부분취소일 경우 값이 있음)");

                entity.Property(e => e.orig_price).HasComment("	원거래 결제요청금액(부분취소일 경우 값이 있음)");

                entity.Property(e => e.pay_date)
                    .IsUnicode(false)
                    .HasComment("결제 승인 일시");

                entity.Property(e => e.pay_state).HasComment("결제요청 상태(1:요청, 4:결제완료, 8,16,32:요청취소, 9,64:승인취소, 10:결제대기, 70,71:부분취소)");

                entity.Property(e => e.pay_type).HasComment("결제 수단(1:신용카드, 2:휴대폰, 3:해외결제, 4:대면결제, 6:계좌이체, 7:가상계좌, 15:카카오페이, 16:네이버페이, 17:결제회원)");

                entity.Property(e => e.payurl)
                    .IsUnicode(false)
                    .HasComment("결제페이지 주소");

                entity.Property(e => e.recvphone).IsUnicode(false);

                entity.Property(e => e.reqdate)
                    .IsUnicode(false)
                    .HasComment("결제요청 일시");

                entity.Property(e => e.var1).IsUnicode(false);

                entity.Property(e => e.var2).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);
            });

            modelBuilder.Entity<classPlan>(entity =>
            {
                entity.Property(e => e.planPlace).IsUnicode(false);

                entity.Property(e => e.planTitle).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.classPlan)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classPlan_classInfo");
            });

            modelBuilder.Entity<classReview>(entity =>
            {
                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.classReview)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classReview_classInfo");
            });

            modelBuilder.Entity<classSurvey>(entity =>
            {
                entity.Property(e => e.link).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.classSurvey)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classSurvey_classInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.classSurvey)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_classSurvey_user");
            });

            modelBuilder.Entity<codeOption>(entity =>
            {
                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.codeOption)
                    .HasForeignKey(d => d.productIdx)
                    .HasConstraintName("FK_codeOption_productInfo");
            });

            modelBuilder.Entity<code_classAges>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_code_classAge");

                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasDefaultValueSql("((999))");

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_classCategory>(entity =>
            {
                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasDefaultValueSql("((999))");

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_classPlace>(entity =>
            {
                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasDefaultValueSql("((999))");

                entity.Property(e => e.placeType).HasComment("1: 온라인 2: 오프라인");

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_company>(entity =>
            {
                entity.Property(e => e.code_name).IsUnicode(false);

                entity.Property(e => e.gubun).IsUnicode(false);

                entity.Property(e => e.use_yn).IsUnicode(false);
            });

            modelBuilder.Entity<code_nationality>(entity =>
            {
                entity.HasKey(e => e.code_id)
                    .HasName("PK_code_1");

                entity.Property(e => e.code_id).IsUnicode(false);

                entity.Property(e => e.gubun).IsUnicode(false);

                entity.Property(e => e.use_yn).IsUnicode(false);

                entity.Property(e => e.write_date).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.writer_id).IsUnicode(false);
            });

            modelBuilder.Entity<code_productCategory>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_code_shopCategory");

                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasDefaultValueSql("((999))");

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_productState>(entity =>
            {
                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_scienceCategory>(entity =>
            {
                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasDefaultValueSql("((999))");

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_shopinfo>(entity =>
            {
                entity.Property(e => e.indexOrder).HasDefaultValueSql("((999))");

                entity.Property(e => e.shopName).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_state>(entity =>
            {
                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<code_userCategory>(entity =>
            {
                entity.Property(e => e.idx).HasComment("회원 구분");

                entity.Property(e => e.codeName).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);
            });

            modelBuilder.Entity<commentsView>(entity =>
            {
                entity.ToView("commentsView");

                entity.Property(e => e.BoardList_title).IsUnicode(false);

                entity.Property(e => e.BoardList_writer).IsUnicode(false);

                entity.Property(e => e.classInfoTilte).IsUnicode(false);

                entity.Property(e => e.classYn).IsUnicode(false);

                entity.Property(e => e.commentsWriter).IsUnicode(false);

                entity.Property(e => e.commentsYn).IsUnicode(false);

                entity.Property(e => e.mailYn).IsUnicode(false);

                entity.Property(e => e.useable).IsUnicode(false);

                entity.Property(e => e.userEmail).IsUnicode(false);

                entity.Property(e => e.userId).IsUnicode(false);
            });

            modelBuilder.Entity<company>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_company_1");

                entity.Property(e => e.address).IsUnicode(false);

                entity.Property(e => e.businessNum).IsUnicode(false);

                entity.Property(e => e.companyId)
                    .IsUnicode(false)
                    .HasComment("회사 아이디");

                entity.Property(e => e.companyName)
                    .IsUnicode(false)
                    .HasComment("회사명");

                entity.Property(e => e.editDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.email).IsUnicode(false);

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasDefaultValueSql("((99))");

                entity.Property(e => e.nationality)
                    .IsUnicode(false)
                    .HasComment("국적 코드");

                entity.Property(e => e.tel).IsUnicode(false);

                entity.Property(e => e.useYn)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('Y')");

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.writer).IsUnicode(false);

                entity.HasOne(d => d.codeCompanyIdxNavigation)
                    .WithMany(p => p.company)
                    .HasForeignKey(d => d.codeCompanyIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_company_code_company");
            });

            modelBuilder.Entity<deliverInfo>(entity =>
            {
                entity.Property(e => e.deliverLink)
                    .IsUnicode(false)
                    .HasComment("배송확인 링크");

                entity.Property(e => e.deliverNum)
                    .IsUnicode(false)
                    .HasComment("송장번호");

                entity.Property(e => e.deliveryName)
                    .IsUnicode(false)
                    .HasComment("택배사 이름");

                entity.Property(e => e.mainYn).IsUnicode(false);

                entity.Property(e => e.orderIdx)
                    .HasDefaultValueSql("((0))")
                    .HasComment("주문번호");

                entity.Property(e => e.request)
                    .IsUnicode(false)
                    .HasComment("요청사항");

                entity.Property(e => e.state).HasComment("배송상태 - 1:배송대기 / 2: 배송중 / 3: 배송완료");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userAddr).IsUnicode(false);

                entity.Property(e => e.userName).IsUnicode(false);

                entity.Property(e => e.userTel).IsUnicode(false);

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.deliverInfoorderIdxNavigation)
                    .HasForeignKey(d => d.orderIdx)
                    .HasConstraintName("FK_deliverInfo_orderProduct");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.deliverInfouserIdxNavigation)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_deliverInfo_user");
            });

            modelBuilder.Entity<deliveryList>(entity =>
            {
                entity.Property(e => e.addrDetail).IsUnicode(false);

                entity.Property(e => e.mainYn).IsUnicode(false);

                entity.Property(e => e.request)
                    .IsUnicode(false)
                    .HasComment("요청사항");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userAddr).IsUnicode(false);

                entity.Property(e => e.userName).IsUnicode(false);

                entity.Property(e => e.userTel).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.zipNo).IsUnicode(false);

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.deliveryList)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_deliveryList_user");
            });

            modelBuilder.Entity<department>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_department_1");

                entity.Property(e => e.idx).ValueGeneratedNever();

                entity.Property(e => e.department_auth)
                    .IsUnicode(false)
                    .HasComment("부서 권한");

                entity.Property(e => e.department_name)
                    .IsUnicode(false)
                    .HasComment("부서명");

                entity.Property(e => e.index_order).HasDefaultValueSql("((99))");

                entity.Property(e => e.use_yn)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('Y')");

                entity.Property(e => e.write_date).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.company_idxNavigation)
                    .WithMany(p => p.department)
                    .HasForeignKey(d => d.company_idx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_department_company");
            });

            modelBuilder.Entity<file_list>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_file_list_1");

                entity.Property(e => e.file_idx)
                    .IsUnicode(false)
                    .HasComment("대상 idx");

                entity.Property(e => e.file_menu_id)
                    .HasDefaultValueSql("((0))")
                    .HasComment("파일 메뉴");

                entity.Property(e => e.file_name)
                    .IsUnicode(false)
                    .HasComment("파일 이름");

                entity.Property(e => e.file_pre_name)
                    .IsUnicode(false)
                    .HasComment("파일 원본 이름");

                entity.Property(e => e.file_size).HasComment("파일 크기");

                entity.Property(e => e.file_type)
                    .IsUnicode(false)
                    .HasComment("파일 형식");

                entity.Property(e => e.hit).HasComment("조회수");

                entity.Property(e => e.write_date)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("등록일");

                entity.HasOne(d => d.file_menu)
                    .WithMany(p => p.file_list)
                    .HasForeignKey(d => d.file_menu_id)
                    .HasConstraintName("FK_file_list_file_menu");
            });

            modelBuilder.Entity<file_management>(entity =>
            {
                entity.Property(e => e.index_order).HasDefaultValueSql("((99))");

                entity.Property(e => e.memo).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.use_yn).IsUnicode(false);

                entity.Property(e => e.write_date).HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<file_menu>(entity =>
            {
                entity.Property(e => e.company_idx).HasDefaultValueSql("((0))");

                entity.Property(e => e.file_menu_name).IsUnicode(false);

                entity.Property(e => e.gubun).HasDefaultValueSql("((0))");

                entity.Property(e => e.use_yn).IsUnicode(false);

                entity.Property(e => e.write_date).HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<history>(entity =>
            {
                entity.Property(e => e.company_id).IsUnicode(false);

                entity.Property(e => e.connect_agent).IsUnicode(false);

                entity.Property(e => e.connect_date).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.connect_host).IsUnicode(false);

                entity.Property(e => e.connect_path).IsUnicode(false);

                entity.Property(e => e.department_id).IsUnicode(false);

                entity.Property(e => e.memo).IsUnicode(false);

                entity.Property(e => e.page).IsUnicode(false);

                entity.Property(e => e.pre_page).IsUnicode(false);

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.user_id).IsUnicode(false);

                entity.Property(e => e.user_ip).IsUnicode(false);
            });

            modelBuilder.Entity<language>(entity =>
            {
                entity.Property(e => e.code_name).IsUnicode(false);

                entity.Property(e => e.english).IsUnicode(false);

                entity.Property(e => e.idx).ValueGeneratedOnAdd();

                entity.Property(e => e.korea).IsUnicode(false);
            });

            modelBuilder.Entity<orderClass>(entity =>
            {
                entity.Property(e => e.cartInfo).IsUnicode(false);

                entity.Property(e => e.orderCode).IsUnicode(false);

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.orderClass)
                    .HasForeignKey(d => d.userIdx)
                    .HasConstraintName("FK_orderClass_user");
            });

            modelBuilder.Entity<orderClassDetail>(entity =>
            {
                entity.Property(e => e.alarmBellYn)
                    .IsUnicode(false)
                    .HasComment("마이페이지- 진행중인 클래스 알람 on/off");

                entity.Property(e => e.alarmCheck).IsUnicode(false);

                entity.Property(e => e.classIdx).HasComment("productInfo");

                entity.Property(e => e.delDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("Y :진행 / E :이수/종료");

                entity.Property(e => e.editDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.orderIdx).HasComment("주문 orderProduct");

                entity.Property(e => e.smsYn)
                    .IsUnicode(false)
                    .HasComment("sms 발송여부 Y/N");

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userIdx).HasComment("user");

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.classIdxNavigation)
                    .WithMany(p => p.orderClassDetail)
                    .HasForeignKey(d => d.classIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderClassDetail_classInfo");

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.orderClassDetail)
                    .HasForeignKey(d => d.orderIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderClassDetail_orderClass");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.orderClassDetail)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderClassDetail_user");
            });

            modelBuilder.Entity<orderProduct>(entity =>
            {
                entity.Property(e => e.cartInfo).IsUnicode(false);

                entity.Property(e => e.orderCode)
                    .IsUnicode(false)
                    .HasComment("productPayment > var2 ");

                entity.Property(e => e.state)
                    .HasDefaultValueSql("((0))")
                    .HasComment("1: 구매완료 / 2: 구매취소 ");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.deliveryIdxNavigation)
                    .WithMany(p => p.orderProduct)
                    .HasForeignKey(d => d.deliveryIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderProduct_deliveryList");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.orderProduct)
                    .HasForeignKey(d => d.userIdx)
                    .HasConstraintName("FK_orderProduct_user");
            });

            modelBuilder.Entity<orderProductDetail>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_orderDetail");

                entity.Property(e => e.orderIdx).HasComment("주문 orderProduct");

                entity.Property(e => e.productIdx).HasComment("productInfo");

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userIdx).HasComment("user");

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.orderProductDetail)
                    .HasForeignKey(d => d.orderIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderProductDetail_orderProduct");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.orderProductDetail)
                    .HasForeignKey(d => d.productIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderProductDetail_productInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.orderProductDetail)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_orderProductDetail_user");
            });

            modelBuilder.Entity<payapp_library>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_payapp_library_1");

                entity.Property(e => e.amount_taxable).HasComment("과세 공급가액");

                entity.Property(e => e.amount_taxfree).HasComment("	면세 공급가액");

                entity.Property(e => e.amount_vat).HasComment("부가세");

                entity.Property(e => e.canceldate)
                    .IsUnicode(false)
                    .HasComment("취소일시");

                entity.Property(e => e.cancelmemo)
                    .IsUnicode(false)
                    .HasComment("취소메모");

                entity.Property(e => e.card_name).IsUnicode(false);

                entity.Property(e => e.csturl)
                    .IsUnicode(false)
                    .HasComment("신용카드 결제시 매출전표 URL");

                entity.Property(e => e.goodname)
                    .IsUnicode(false)
                    .HasComment("정기결제 상품명");

                entity.Property(e => e.goodprice).HasComment("정기 결제 요청 금액");

                entity.Property(e => e.linkkey).IsUnicode(false);

                entity.Property(e => e.linkval).IsUnicode(false);

                entity.Property(e => e.mul_no).HasComment("결제요청번호(결제 취소 시 사용)");

                entity.Property(e => e.naverpay)
                    .IsUnicode(false)
                    .HasComment("네이버결제 구분 방법 (네이버페이 결제시만 제공)");

                entity.Property(e => e.naverpoint).HasComment("네이버 포인트 결제시 금액 (네이버페이 결제시만 제공)");

                entity.Property(e => e.orig_mul_no).HasComment("원거래 결제요청번호(부분취소일 경우 값이 있음)");

                entity.Property(e => e.orig_price).HasComment("	원거래 결제요청금액(부분취소일 경우 값이 있음)");

                entity.Property(e => e.pay_date)
                    .IsUnicode(false)
                    .HasComment("결제 승인 일시");

                entity.Property(e => e.pay_state).HasComment("결제요청 상태(1:요청, 4:결제완료, 8,16,32:요청취소, 9,64:승인취소, 10:결제대기, 70,71:부분취소)");

                entity.Property(e => e.pay_type).HasComment("결제 수단(1:신용카드, 2:휴대폰, 3:해외결제, 4:대면결제, 6:계좌이체, 7:가상계좌, 15:카카오페이, 16:네이버페이, 17:결제회원)");

                entity.Property(e => e.payurl)
                    .IsUnicode(false)
                    .HasComment("결제페이지 주소");

                entity.Property(e => e.rebillCycleType)
                    .IsUnicode(false)
                    .HasComment("정기결제 주기 구분 (Month,Week,Day)");

                entity.Property(e => e.rebillExpire)
                    .IsUnicode(false)
                    .HasComment("정기결제 만료일 (yyyy-mm-dd)");

                entity.Property(e => e.rebill_no)
                    .IsUnicode(false)
                    .HasComment("정기 결제 요청번호");

                entity.Property(e => e.recvphone).IsUnicode(false);

                entity.Property(e => e.reqdate)
                    .IsUnicode(false)
                    .HasComment("결제요청 일시");

                entity.Property(e => e.var1).IsUnicode(false);

                entity.Property(e => e.var2).IsUnicode(false);
            });

            modelBuilder.Entity<payment_payapp>(entity =>
            {
                entity.Property(e => e.addcomm)
                    .HasDefaultValueSql("((0))")
                    .HasComment("정기결제 이용료 부담");

                entity.Property(e => e.amount_taxable).HasComment("과세 공급가액");

                entity.Property(e => e.amount_taxfree).HasComment("	면세 공급가액");

                entity.Property(e => e.amount_vat).HasComment("부가세");

                entity.Property(e => e.canceldate)
                    .IsUnicode(false)
                    .HasComment("취소일시");

                entity.Property(e => e.cancelmemo)
                    .IsUnicode(false)
                    .HasComment("취소메모");

                entity.Property(e => e.card_name).IsUnicode(false);

                entity.Property(e => e.cmd)
                    .IsUnicode(false)
                    .HasComment("	정기결제요청 : rebillRegist");

                entity.Property(e => e.csturl)
                    .IsUnicode(false)
                    .HasComment("신용카드 결제시 매출전표 URL");

                entity.Property(e => e.endDate).HasComment("결제 승인 일시");

                entity.Property(e => e.goodname)
                    .IsUnicode(false)
                    .HasComment("정기결제 상품명");

                entity.Property(e => e.goodprice).HasComment("정기 결제 요청 금액");

                entity.Property(e => e.linkkey).IsUnicode(false);

                entity.Property(e => e.linkval).IsUnicode(false);

                entity.Property(e => e.mul_no).HasComment("결제요청번호(결제 취소 시 사용)");

                entity.Property(e => e.naverpay)
                    .IsUnicode(false)
                    .HasComment("네이버결제 구분 방법 (네이버페이 결제시만 제공)");

                entity.Property(e => e.naverpoint).HasComment("네이버 포인트 결제시 금액 (네이버페이 결제시만 제공)");

                entity.Property(e => e.orig_mul_no).HasComment("원거래 결제요청번호(부분취소일 경우 값이 있음)");

                entity.Property(e => e.orig_price).HasComment("	원거래 결제요청금액(부분취소일 경우 값이 있음)");

                entity.Property(e => e.payGubun).HasComment("1: 한달 단기 결제 / 2: 한달 정기 결제 / 3: 1년 정기결제");

                entity.Property(e => e.pay_date)
                    .IsUnicode(false)
                    .HasComment("결제 승인 일시");

                entity.Property(e => e.pay_state).HasComment("결제요청 상태(1:요청, 4:결제완료, 8,16,32:요청취소, 9,64:승인취소, 10:결제대기, 70,71:부분취소)");

                entity.Property(e => e.pay_type).HasComment("결제 수단(1:신용카드, 2:휴대폰, 3:해외결제, 4:대면결제, 6:계좌이체, 7:가상계좌, 15:카카오페이, 16:네이버페이, 17:결제회원)");

                entity.Property(e => e.payurl)
                    .IsUnicode(false)
                    .HasComment("결제페이지 주소");

                entity.Property(e => e.rebillCycleType)
                    .IsUnicode(false)
                    .HasComment("정기결제 주기 구분 (Month,Week,Day)");

                entity.Property(e => e.rebillExpire)
                    .IsUnicode(false)
                    .HasComment("정기결제 만료일 (yyyy-mm-dd)");

                entity.Property(e => e.rebill_no)
                    .IsUnicode(false)
                    .HasComment("정기 결제 요청번호");

                entity.Property(e => e.recvphone).IsUnicode(false);

                entity.Property(e => e.reqdate)
                    .IsUnicode(false)
                    .HasComment("결제요청 일시");

                entity.Property(e => e.startDate).HasComment("결제 승인 일시");

                entity.Property(e => e.userid)
                    .IsUnicode(false)
                    .HasComment("판매자 회원 아이디");

                entity.Property(e => e.var1).IsUnicode(false);

                entity.Property(e => e.var2).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);
            });

            modelBuilder.Entity<productCart>(entity =>
            {
                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.optionIdxNavigation)
                    .WithMany(p => p.productCart)
                    .HasForeignKey(d => d.optionIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productCart_codeOption");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.productCart)
                    .HasForeignKey(d => d.productIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productCart_productInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.productCart)
                    .HasForeignKey(d => d.userIdx)
                    .HasConstraintName("FK_productCart_user");
            });

            modelBuilder.Entity<productInfo>(entity =>
            {
                entity.Property(e => e.category).HasComment("1: All / 2: 실험키트 / 3:코딩교구 / 4: 수학교구/ 5:과학굿즈 / 6: 콘텐츠");

                entity.Property(e => e.description).IsUnicode(false);

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.indexOrder).HasComment("정렬순서");

                entity.Property(e => e.mainYn)
                    .IsUnicode(false)
                    .HasComment("B: 베스트상품 / N: 신상품 / R: 추천상품");

                entity.Property(e => e.optionIdx).HasDefaultValueSql("((0))");

                entity.Property(e => e.productName).IsUnicode(false);

                entity.Property(e => e.returnInfo)
                    .IsUnicode(false)
                    .HasComment("반품/교환 정보");

                entity.Property(e => e.shopIdx).HasComment("판매처");

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.uploadGubun).HasComment("1: best인기상품 / 2: 신상품 / 3: 추천상품");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.categoryNavigation)
                    .WithMany(p => p.productInfo)
                    .HasForeignKey(d => d.category)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productInfo_code_productCategory");

                entity.HasOne(d => d.optionIdxNavigation)
                    .WithMany(p => p.productInfo)
                    .HasForeignKey(d => d.optionIdx)
                    .HasConstraintName("FK_productInfo_codeOption");

                entity.HasOne(d => d.shopIdxNavigation)
                    .WithMany(p => p.productInfo)
                    .HasForeignKey(d => d.shopIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productInfo_code_shopinfo");

                entity.HasOne(d => d.stateIdxNavigation)
                    .WithMany(p => p.productInfo)
                    .HasForeignKey(d => d.stateIdx)
                    .HasConstraintName("FK_productInfo_code_productState");
            });

            modelBuilder.Entity<productPayment>(entity =>
            {
                entity.Property(e => e.addcomm)
                    .HasDefaultValueSql("((0))")
                    .HasComment("정기결제 이용료 부담");

                entity.Property(e => e.amount_taxable).HasComment("과세 공급가액");

                entity.Property(e => e.amount_taxfree).HasComment("	면세 공급가액");

                entity.Property(e => e.amount_vat).HasComment("부가세");

                entity.Property(e => e.canceldate)
                    .IsUnicode(false)
                    .HasComment("취소일시");

                entity.Property(e => e.cancelmemo)
                    .IsUnicode(false)
                    .HasComment("취소메모");

                entity.Property(e => e.card_name).IsUnicode(false);

                entity.Property(e => e.cmd)
                    .IsUnicode(false)
                    .HasComment("	정기결제요청 : rebillRegist");

                entity.Property(e => e.csturl)
                    .IsUnicode(false)
                    .HasComment("신용카드 결제시 매출전표 URL");

                entity.Property(e => e.endDate).HasComment("결제 승인 일시");

                entity.Property(e => e.goodname)
                    .IsUnicode(false)
                    .HasComment("정기결제 상품명");

                entity.Property(e => e.goodprice).HasComment("정기 결제 요청 금액");

                entity.Property(e => e.linkkey).IsUnicode(false);

                entity.Property(e => e.linkval).IsUnicode(false);

                entity.Property(e => e.mul_no).HasComment("결제요청번호(결제 취소 시 사용)");

                entity.Property(e => e.naverpay)
                    .IsUnicode(false)
                    .HasComment("네이버결제 구분 방법 (네이버페이 결제시만 제공)");

                entity.Property(e => e.naverpoint).HasComment("네이버 포인트 결제시 금액 (네이버페이 결제시만 제공)");

                entity.Property(e => e.orig_mul_no).HasComment("원거래 결제요청번호(부분취소일 경우 값이 있음)");

                entity.Property(e => e.orig_price).HasComment("	원거래 결제요청금액(부분취소일 경우 값이 있음)");

                entity.Property(e => e.payGubun).HasComment("1: 한달 단기 결제 / 2: 한달 정기 결제 / 3: 1년 정기결제");

                entity.Property(e => e.pay_date)
                    .IsUnicode(false)
                    .HasComment("결제 승인 일시");

                entity.Property(e => e.pay_state).HasComment("결제요청 상태(1:요청, 4:결제완료, 8,16,32:요청취소, 9,64:승인취소, 10:결제대기, 70,71:부분취소)");

                entity.Property(e => e.pay_type).HasComment("결제 수단(1:신용카드, 2:휴대폰, 3:해외결제, 4:대면결제, 6:계좌이체, 7:가상계좌, 15:카카오페이, 16:네이버페이, 17:결제회원)");

                entity.Property(e => e.payurl)
                    .IsUnicode(false)
                    .HasComment("결제페이지 주소");

                entity.Property(e => e.rebillCycleType)
                    .IsUnicode(false)
                    .HasComment("정기결제 주기 구분 (Month,Week,Day)");

                entity.Property(e => e.rebillExpire)
                    .IsUnicode(false)
                    .HasComment("정기결제 만료일 (yyyy-mm-dd)");

                entity.Property(e => e.rebill_no)
                    .IsUnicode(false)
                    .HasComment("정기 결제 요청번호");

                entity.Property(e => e.recvphone).IsUnicode(false);

                entity.Property(e => e.reqdate)
                    .IsUnicode(false)
                    .HasComment("결제요청 일시");

                entity.Property(e => e.startDate).HasComment("결제 승인 일시");

                entity.Property(e => e.userid)
                    .IsUnicode(false)
                    .HasComment("판매자 회원 아이디");

                entity.Property(e => e.var1).IsUnicode(false);

                entity.Property(e => e.var2).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);
            });

            modelBuilder.Entity<productReclaim>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_reclaimDelivery");

                entity.Property(e => e.completeDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("교환완료일");

                entity.Property(e => e.delDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.deliverCompany1).IsUnicode(false);

                entity.Property(e => e.deliverCompany2).IsUnicode(false);

                entity.Property(e => e.deliverNum1)
                    .IsUnicode(false)
                    .HasComment("회수송장 ");

                entity.Property(e => e.deliverNum2)
                    .IsUnicode(false)
                    .HasComment("교환송장");

                entity.Property(e => e.editDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.endDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("교환예정일");

                entity.Property(e => e.optionIdx).HasComment("");

                entity.Property(e => e.optionInfo)
                    .IsUnicode(false)
                    .HasComment("옵션 상세 정보");

                entity.Property(e => e.orderIdx).HasComment("주문정보");

                entity.Property(e => e.reclaimUser)
                    .IsUnicode(false)
                    .HasComment("교환인");

                entity.Property(e => e.recliamNum).HasComment("교환번호 : r로 시작 ");

                entity.Property(e => e.startDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("교환예정일");

                entity.Property(e => e.state).HasComment("배송상태 - 1:배송대기 / 2: 배송중 / 3: 배송완료");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userAddr).IsUnicode(false);

                entity.Property(e => e.userIdx).HasComment("구매자 정보");

                entity.Property(e => e.userTel).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.optionIdxNavigation)
                    .WithMany(p => p.productReclaimoptionIdxNavigation)
                    .HasForeignKey(d => d.optionIdx)
                    .HasConstraintName("FK_productReclaim_orderProduct");

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.productReclaimorderIdxNavigation)
                    .HasForeignKey(d => d.orderIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReclaim_orderProduct1");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.productReclaim)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReclaim_user");
            });

            modelBuilder.Entity<productRefund>(entity =>
            {
                entity.Property(e => e.completeDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("교환완료일");

                entity.Property(e => e.delDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.editDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.endDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("교환예정일");

                entity.Property(e => e.optionInfo)
                    .IsUnicode(false)
                    .HasComment("옵션 상세 정보");

                entity.Property(e => e.orderIdx).HasComment("주문정보");

                entity.Property(e => e.productIdx).HasComment("상품정보");

                entity.Property(e => e.refundCode)
                    .IsUnicode(false)
                    .HasComment("주문코드");

                entity.Property(e => e.refundType).HasComment("환불수단");

                entity.Property(e => e.startDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("교환예정일");

                entity.Property(e => e.state).HasComment("반품상태 - 1:환불대기 / 2: 환불&반품검수중 / 3: 환불완료");

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userId).IsUnicode(false);

                entity.Property(e => e.userName).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.productRefund)
                    .HasForeignKey(d => d.orderIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productRefund_orderProduct");

                entity.HasOne(d => d.paymentIdxNavigation)
                    .WithMany(p => p.productRefund)
                    .HasForeignKey(d => d.paymentIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productRefund_productPayment");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.productRefund)
                    .HasForeignKey(d => d.productIdx)
                    .HasConstraintName("FK_productRefund_productInfo");
            });

            modelBuilder.Entity<productReturn>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_returnProduct");

                entity.Property(e => e.completeDate).HasComment("교환완료일");

                entity.Property(e => e.deliverIdx).HasComment("교환 배송정보");

                entity.Property(e => e.endDate).HasComment("교환예정일");

                entity.Property(e => e.reclaimIdx).HasComment("상품 회수정보");

                entity.Property(e => e.returnCode).IsUnicode(false);

                entity.Property(e => e.startDate).HasComment("교환예정일");

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.productReturn)
                    .HasForeignKey(d => d.orderIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReturn_orderProduct");

                entity.HasOne(d => d.paymentIdxNavigation)
                    .WithMany(p => p.productReturn)
                    .HasForeignKey(d => d.paymentIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReturn_productPayment");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.productReturn)
                    .HasForeignKey(d => d.productIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReturn_productInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.productReturn)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReturn_user");
            });

            modelBuilder.Entity<productReturnDelivery>(entity =>
            {
                entity.HasKey(e => e.idx)
                    .HasName("PK_returnDelivery");

                entity.Property(e => e.deliverCompany).IsUnicode(false);

                entity.Property(e => e.deliverNum).IsUnicode(false);

                entity.Property(e => e.reclaimUser).IsUnicode(false);

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.Property(e => e.userAddr).IsUnicode(false);

                entity.Property(e => e.userTel).IsUnicode(false);

                entity.HasOne(d => d.productReturnIdxNavigation)
                    .WithMany(p => p.productReturnDelivery)
                    .HasForeignKey(d => d.productReturnIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReturnDelivery_productReturn");
            });

            modelBuilder.Entity<productReview>(entity =>
            {
                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.useYn).IsUnicode(false);

                entity.HasOne(d => d.orderIdxNavigation)
                    .WithMany(p => p.productReview)
                    .HasForeignKey(d => d.orderIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReview_orderProduct");

                entity.HasOne(d => d.productIdxNavigation)
                    .WithMany(p => p.productReview)
                    .HasForeignKey(d => d.productIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReview_productInfo");

                entity.HasOne(d => d.userIdxNavigation)
                    .WithMany(p => p.productReview)
                    .HasForeignKey(d => d.userIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_productReview_user");
            });

            modelBuilder.Entity<sendHistory>(entity =>
            {
                entity.Property(e => e.gubun)
                    .IsUnicode(false)
                    .HasComment("email / sms");

                entity.Property(e => e.memo).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.user_id).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<user>(entity =>
            {
                entity.Property(e => e.cEndDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("클래스 결제 기간 마지막날");

                entity.Property(e => e.cStartDate)
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("클래스 결제 기간 첫날");

                entity.Property(e => e.checkAuth).HasDefaultValueSql("((1))");

                entity.Property(e => e.classYn)
                    .IsUnicode(false)
                    .HasComment("클래스결제여부 ");

                entity.Property(e => e.companyId)
                    .IsUnicode(false)
                    .HasComment("회사 아이디");

                entity.Property(e => e.departmentIdx).HasComment("부서 아이디");

                entity.Property(e => e.editDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.id_one)
                    .IsUnicode(false)
                    .HasComment("중복 로그인 방지");

                entity.Property(e => e.id_save)
                    .IsUnicode(false)
                    .HasComment("아이디 저장");

                entity.Property(e => e.main_bg_color)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('red')");

                entity.Property(e => e.month1Free)
                    .IsUnicode(false)
                    .HasComment("한달무료_사용여부 - 회원가입시 : Y ,무료 1개월 끝난 계정 : C, 결제 계정 : N");

                entity.Property(e => e.now_ip).IsUnicode(false);

                entity.Property(e => e.photoProfile).IsUnicode(false);

                entity.Property(e => e.sms_send)
                    .IsUnicode(false)
                    .HasComment("sms 문자 발송 여부 ");

                entity.Property(e => e.useYn)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('Y')");

                entity.Property(e => e.userAuth)
                    .IsUnicode(false)
                    .HasComment("사용자 권한");

                entity.Property(e => e.userClass).HasComment("");

                entity.Property(e => e.userEmail).IsUnicode(false);

                entity.Property(e => e.userId)
                    .IsUnicode(false)
                    .HasComment("사용자 아이디");

                entity.Property(e => e.userName)
                    .IsUnicode(false)
                    .HasComment("사용자 명");

                entity.Property(e => e.userPassword).IsUnicode(false);

                entity.Property(e => e.userTel).IsUnicode(false);

                entity.Property(e => e.writeDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.writer).IsUnicode(false);

                entity.HasOne(d => d.companyIdxNavigation)
                    .WithMany(p => p.user)
                    .HasForeignKey(d => d.companyIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_user_company");

                entity.HasOne(d => d.departmentIdxNavigation)
                    .WithMany(p => p.user)
                    .HasForeignKey(d => d.departmentIdx)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_user_department");
            });

            modelBuilder.Entity<v_class_board>(entity =>
            {
                entity.ToView("v_class_board");

                entity.Property(e => e.Expr1).IsUnicode(false);

                entity.Property(e => e.className).IsUnicode(false);

                entity.Property(e => e.commuYn).IsUnicode(false);

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.mainYn).IsUnicode(false);

                entity.Property(e => e.reply).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.useable).IsUnicode(false);

                entity.Property(e => e.userId).IsUnicode(false);

                entity.Property(e => e.userName).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);
            });

            modelBuilder.Entity<v_mail>(entity =>
            {
                entity.ToView("v_mail");

                entity.Property(e => e.BoardList_title).IsUnicode(false);

                entity.Property(e => e.BoardList_writer).IsUnicode(false);

                entity.Property(e => e.classInfoTilte).IsUnicode(false);

                entity.Property(e => e.classYn).IsUnicode(false);

                entity.Property(e => e.commentsWriter).IsUnicode(false);

                entity.Property(e => e.commentsYn).IsUnicode(false);

                entity.Property(e => e.mailYn).IsUnicode(false);

                entity.Property(e => e.useable).IsUnicode(false);

                entity.Property(e => e.userEmail).IsUnicode(false);

                entity.Property(e => e.userId).IsUnicode(false);
            });

            modelBuilder.Entity<v_review>(entity =>
            {
                entity.ToView("v_review");

                entity.Property(e => e.boardYn).IsUnicode(false);

                entity.Property(e => e.classYn).IsUnicode(false);

                entity.Property(e => e.fileId).IsUnicode(false);

                entity.Property(e => e.mainYn).IsUnicode(false);

                entity.Property(e => e.photoProfile).IsUnicode(false);

                entity.Property(e => e.title).IsUnicode(false);

                entity.Property(e => e.userYn).IsUnicode(false);

                entity.Property(e => e.writer).IsUnicode(false);
            });

            modelBuilder.Entity<v_sms>(entity =>
            {
                entity.ToView("v_sms");

                entity.Property(e => e.alarmBellYn).IsUnicode(false);

                entity.Property(e => e.alarmCheck).IsUnicode(false);

                entity.Property(e => e.className).IsUnicode(false);

                entity.Property(e => e.clsss_yn).IsUnicode(false);

                entity.Property(e => e.order_useryn).IsUnicode(false);

                entity.Property(e => e.smsYn).IsUnicode(false);

                entity.Property(e => e.state).IsUnicode(false);

                entity.Property(e => e.userEmail).IsUnicode(false);

                entity.Property(e => e.userId).IsUnicode(false);

                entity.Property(e => e.userName).IsUnicode(false);

                entity.Property(e => e.userTel).IsUnicode(false);

                entity.Property(e => e.user_yn).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
