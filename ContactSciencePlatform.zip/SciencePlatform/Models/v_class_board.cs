﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    [Keyless]
    public partial class v_class_board
    {
        public int idx { get; set; }
        public int BM_idx { get; set; }
        [Required]
        [StringLength(50)]
        public string title { get; set; }
        public int BoardType_idx { get; set; }
        [Required]
        [StringLength(250)]
        public string Expr1 { get; set; }
        [StringLength(200)]
        public string writer { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        public int hit { get; set; }
        [StringLength(2)]
        public string useable { get; set; }
        [StringLength(50)]
        public string fileId { get; set; }
        [StringLength(50)]
        public string reply { get; set; }
        public int classIdx { get; set; }
        [Column(TypeName = "ntext")]
        public string content { get; set; }
        [StringLength(150)]
        public string className { get; set; }
        [StringLength(50)]
        public string userId { get; set; }
        [StringLength(50)]
        public string userName { get; set; }
        public int Expr2 { get; set; }
        [StringLength(1)]
        public string mainYn { get; set; }
        [StringLength(1)]
        public string commuYn { get; set; }
    }
}
