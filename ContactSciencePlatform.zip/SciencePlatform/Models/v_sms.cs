﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    [Keyless]
    public partial class v_sms
    {
        public int user_idx { get; set; }
        [StringLength(50)]
        public string userTel { get; set; }
        [StringLength(150)]
        public string userEmail { get; set; }
        [Required]
        [StringLength(50)]
        public string userName { get; set; }
        [StringLength(1)]
        public string user_yn { get; set; }
        [StringLength(150)]
        public string className { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime startDate { get; set; }
        public int class_idx { get; set; }
        [StringLength(1)]
        public string order_useryn { get; set; }
        [StringLength(1)]
        public string clsss_yn { get; set; }
        [StringLength(1)]
        public string alarmBellYn { get; set; }
        [StringLength(1)]
        public string alarmCheck { get; set; }
        [StringLength(1)]
        public string state { get; set; }
        [StringLength(1)]
        public string smsYn { get; set; }
        public int order_idx { get; set; }
        [Required]
        [StringLength(50)]
        public string userId { get; set; }
    }
}
