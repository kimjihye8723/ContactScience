﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class orderClassDetail
    {
        [Key]
        public int idx { get; set; }
        public int orderIdx { get; set; }
        public int classIdx { get; set; }
        public int userIdx { get; set; }
        public int price { get; set; }
        public int qty { get; set; }
        [StringLength(1)]
        public string state { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime editDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime delDate { get; set; }
        [StringLength(1)]
        public string alarmBellYn { get; set; }
        [StringLength(1)]
        public string alarmCheck { get; set; }
        [StringLength(1)]
        public string smsYn { get; set; }

        [ForeignKey(nameof(classIdx))]
        [InverseProperty(nameof(classInfo.orderClassDetail))]
        public virtual classInfo classIdxNavigation { get; set; }
        [ForeignKey(nameof(orderIdx))]
        [InverseProperty(nameof(orderClass.orderClassDetail))]
        public virtual orderClass orderIdxNavigation { get; set; }
        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.orderClassDetail))]
        public virtual user userIdxNavigation { get; set; }
    }
}
