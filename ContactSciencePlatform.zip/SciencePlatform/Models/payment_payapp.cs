﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class payment_payapp
    {
        [Key]
        public int idx { get; set; }
        [Required]
        [StringLength(50)]
        public string writer { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        public string linkkey { get; set; }
        public string linkval { get; set; }
        [StringLength(50)]
        public string recvphone { get; set; }
        public string reqdate { get; set; }
        public string pay_date { get; set; }
        public int pay_type { get; set; }
        public int pay_state { get; set; }
        public string var1 { get; set; }
        public string var2 { get; set; }
        public int mul_no { get; set; }
        public string csturl { get; set; }
        public int orig_mul_no { get; set; }
        public int orig_price { get; set; }
        public int amount_taxable { get; set; }
        public int amount_taxfree { get; set; }
        public int amount_vat { get; set; }
        public int naverpoint { get; set; }
        public string naverpay { get; set; }
        public string canceldate { get; set; }
        public string cancelmemo { get; set; }
        [StringLength(300)]
        public string card_name { get; set; }
        public string payurl { get; set; }
        public int payGubun { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime startDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime endDate { get; set; }
        public string cmd { get; set; }
        public string userid { get; set; }
        public string goodname { get; set; }
        public int goodprice { get; set; }
        public int? addcomm { get; set; }
        public string rebillCycleType { get; set; }
        public string rebillExpire { get; set; }
        public int price { get; set; }
        public string rebill_no { get; set; }
    }
}
