﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace SciencePlatform.Models
{
    public partial class deliveryList
    {
        public deliveryList()
        {
            orderProduct = new HashSet<orderProduct>();
        }

        [Key]
        public int idx { get; set; }
        public int userIdx { get; set; }
        [StringLength(50)]
        public string userName { get; set; }
        [StringLength(50)]
        public string userTel { get; set; }
        public string userAddr { get; set; }
        public string addrDetail { get; set; }
        public string request { get; set; }
        [StringLength(1)]
        public string mainYn { get; set; }
        public int indexOrder { get; set; }
        [StringLength(1)]
        public string useYn { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime writeDate { get; set; }
        [StringLength(50)]
        public string zipNo { get; set; }

        [ForeignKey(nameof(userIdx))]
        [InverseProperty(nameof(user.deliveryList))]
        public virtual user userIdxNavigation { get; set; }
        [InverseProperty("deliveryIdxNavigation")]
        public virtual ICollection<orderProduct> orderProduct { get; set; }
    }
}
